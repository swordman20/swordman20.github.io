/**
 * @author: xiaomei
 * @date: 2018.6.27
 * @description 门店详情
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery'
], function (doT,flyMobile,jquery,common){

    var params={"param":735};

    var vm = window.vm = fly({
        data:{
            textFollow: "关注"
        },
        event:{},
        page:{
            //关注
            clickCarFollow:function(e){
                var params={
                    "param":{
                        "status":0,
                        "supplierAddress":"芜湖美度汽车贸易有限公司",
                        "supplierId":"575",
                        "supplierName":"芜湖"
                    }
                },
                _this=$(e.currentTarget);

                if(_this.hasClass('active')){
                    params.param.status = 0
                }else{
                    params.param.status = 1;
                }
                $.ajax({
                    headers: {'Authorization':tokenValue},
                    type:'post',
                    url:serverApiUrl+'crm/api/user/attention',
                    async:false,
                    contentType:'application/json',
                    data:JSON.stringify(params),
                    dataType:"json",
                    success:function(res){
                        if(params.param.status==0){
                            common.toast("取消关注成功");
                            _this.removeClass('active');
                            vm.data.set('textFollow', '关注');
                        }else{
                            common.toast("关注成功");
                            _this.addClass('active');
                            vm.data.set('textFollow', '已关注');
                        }
                    },
                    error:function(e){
                        common.toast(e.message);
                    }
                });
            },

            //免费咨询
            clickFreeConsult:function(){
                window.location.href=localhostUrl+"goAppoint/goAppoint.html";
            }
        }
    });

    var dao = {
        //门店详情
        getTotalCar:function(){
            $.ajax({
                headers: {'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'car/api/source/listBySupplier',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(res){
                    if(res.data.list.length>0){
                        var requestTmpl = doT.template($('#storeListTemple').text());
                        $('.js-store-list').append(requestTmpl(res.data.list));
                    }else{
                        $('.js-empty').show();
                    }
                },
                error:function(e){
                    common.toast(e.message);
                }
            });
        }
    };

    dao.getTotalCar();

    fly.bind(document.body, vm);
});