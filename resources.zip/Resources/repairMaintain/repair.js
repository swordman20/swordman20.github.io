/**
 * @author: xiaomei
 * @date: 2018.11.07
 * @description 维修保养
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll',
    'pullToRefresh'
], function (doT,flyMobile,jquery,common,iscroll,pullToRefresh){
    var pageSize = 10,
        currentPageNo = 1,
        upPermit = 0,

        headerNav=$('.js-nav'),
        headerNavBg=$('.js-nav-bg'),
        headerNavBg1=$('.js-nav-bg1'),
        menuList=$('.js-all-select'),
        menuList1=$('.js-study-select'),

        repairCont=$('.js-repair-list');

    var params={
        "orderBy":"",
        "orderDir":"",
        "pageNo":0,
        "pageSize":10,
        "param":{
            "categoryId":"service",
            "goodsCategory":"",
        }
    };


    var vm = window.vm = fly({
        data:{},
        event: {
            pullToDo:function(){
                //初始化上拉下拉操作
                refresher.init({
                    id: "wrapper",
                    pullDownAction: vm.event.reloadNew,
                    pullUpAction: vm.event.loadMore
                });
            },
            loadMore:function(){
                if (upPermit === 0){
                    //上拉加载
                    currentPageNo++;
                    params.pageNo = currentPageNo;
                    flyMobile.data({
                        source:'repairMaintain',
                        action:'',
                        actionType: '4',
                        path:'goods/service/list',
                        args:params,
                        callback: true
                    }).done(function (res){
                        if (res.statusCode == 200){
                            if(res.data.rows.length>0){
                                var requestTemple = doT.template($('#repairListTemple').text());
                                repairCont.append(requestTemple(res.data.rows));

                                if (res.data.rows.length < pageSize) {
                                    upPermit = 1;
                                    refresher.onResherCompeted();
                                }
                                wrapper.refresh();
                            } else {
                                refresher.onResherCompeted();
                                wrapper.refresh();
                            }
                        }else{
                            vm.page.errorCont(res);
                        }
                    });
                }else{
                    refresher.onResherCompeted();
                    wrapper.refresh();
                }
            },
            reloadNew:function(){
                //下拉刷新
                currentPageNo = 1;
                params.pageNo = currentPageNo;
                upPermit = 0;
                flyMobile.data({
                    source:'repairMaintain',
                    action:'',
                    actionType:'4',
                    path:'goods/service/list',
                    args:params,
                    callback: true
                }).done(function (res) {
                    if (res.statusCode == 200){
                        if(res.data.rows.length>0){
                            var requestTemple = doT.template($('#repairListTemple').text());
                            repairCont.html('').append(requestTemple(res.data.rows));
                            if(res.data.rows.length < pageSize) {
                                refresher.onResherCompeted();
                                upPermit = 1;
                            }
                            wrapper.refresh();
                        }else{
                            vm.page.emptyData();
                        }
                    }else{
                        vm.page.errorCont(res);
                    }
                });
            }
        },
        page:{
            // 头部导航
            headerScreen: function(e){
                var index = $(this).index();
                $(this).addClass('active').siblings().removeClass('active');
                switch(index){
                    case 0:
                        headerNavBg.toggle();
                        menuList.slideToggle('slow');
                        headerNavBg1.hide();
                        menuList1.slideUp('slow');
                        break;
                    case 1:
                        headerNavBg1.toggle();
                        menuList1.slideToggle('slow');
                        menuList.slideUp('slow');
                        headerNavBg.hide();
                        break;
                }
            },

            //错误提示
            errorCont:function(res){
                $('.js-error').show().find('p').text(res.message);
                refresher.onErrorCompeted();
                $('.pullUpLabel').text('');
                vm.event.pullToDo();
            },

            //空数据
            emptyData:function(){
                $('.js-empty').show();
                refresher.onEmptyCompeted();
                wrapper.refresh();
                $('.pullUpLabel').text('');
            },

            //全部分类
            sortAll:function(e){
                var _this=$(e.currentTarget);
                params.param.goodsCategory=_this.attr('data-type');
                params.orderBy="";
                params.orderDir="";
                _this.addClass('cur').siblings().removeClass('cur');
                headerNavBg.hide();
                menuList.slideUp('slow');
                dao.getPosData();
            },

            //综合分类
            sortColligate:function(e){
                var _this=$(e.currentTarget);
                params.param.goodsCategory="";
                params.orderBy=_this.attr('data-type');
                params.orderDir=_this.attr('data-order');
                _this.addClass('cur').siblings().removeClass('cur');
                headerNavBg1.hide();
                menuList1.slideUp('slow');
                dao.getPosData();
            },

            //商品详情
            repairDetail:function(e){

            }

        }
    });
    var dao = {
        getPosData:function(){
            $.ajax({
                type:'post',
                url:serverApiUrl+'goods/service/list',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(obj){
                    if(obj.data.rows.length>0) {
                        var requestTemple = doT.template($('#repairListTemple').text());
                        repairCont.html('').append(requestTemple(obj.data.rows));
                        if (obj.data.rows.length < pageSize) {
                            refresher.onResherCompeted();
                            upPermit = 1;
                        } else {
                            refresher.onInitCompeted();
                        }
                        vm.event.pullToDo();
                    }else {
                        $('.js-empty').show();
                        refresher.onEmptyCompeted();
                        wrapper.refresh();
                        $('.pullUpLabel').text('');
                    }
                },
                error:function(e){}
            });
        }
    };

    headerNav.on('click', 'li', vm.page.headerScreen);
    menuList.on('click', 'dd', vm.page.sortAll);
    menuList1.on('click', 'dd', vm.page.sortColligate);
    repairCont.on('click', 'li', vm.page.repairDetail);

    dao.getPosData();

    fly.bind(document.body, vm);
});