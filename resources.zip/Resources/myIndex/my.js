/**
 * @author: xiaomei
 * @date: 2018.6.7
 * @description 主页
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'serverUrl',
    'jquery'
], function (doT, flyMobile, jquery, common,serverUrl) {
    var id = "";
    // 获取用户信息
    window.getUserData = function(res){
        res = res.message;
        res = JSON.parse(res);
        if (res != undefined && res.statusCode == 200 && !(res.data === null)) {
             $('.user-name').text(res.data.name);
             $('.user-pic').attr('src', res.data.picUrl);
             id = res.data.id;
        }
    };

    //获取数量
    window.getfavCountData = function(res){
        res = res.message;
        res = JSON.parse(res);
        if (res.statusCode == 200){
            vm.data.set('collection', res.data.favCount || 0);
            vm.data.set('history', res.data.browseCount || 0);
            vm.data.set('appointment', res.data.reserveCount || 0);
        }
    };

    //获取头像
    window.getHeadImageUrl=function(res){
        $('.js-user-pic').attr('src',res);
    };

    var vm = window.vm = fly({
        data: {
            userName: "设计个独特名称吧",
            collection:0,
            history:0,
            appointment:0
        },
        event:{},
        page: {
            // 点击头像更换头像
            jumplogin: function () {
                flyMobile.data({
                    source:'myIndex',
                    action:'uploadHeadImage',
                    actionType:'3',
                    callback:false
                });
            },

            //我的收藏
            jumpCollect:function(){
                flyMobile.data({
                    source:'myCollect',
                    action:'myCollect',
                    actionType: '1',
                    callback:false
                });
            },

            //浏览列表
            jumpBrowse:function(){
                flyMobile.data({
                    source: 'browseHistory',
                    action: 'browseHistory',
                    actionType: '1',
                    callback: false
                });
            },

            //预约记录
            jumpAppoint:function(){
                flyMobile.data({
                    source: 'appointRecord',
                    action: 'appointRecord',
                    actionType: '1',
                    callback: false
                });
            },

            // 我的订单
            jumpOrderList:function(){
                flyMobile.data({
                    source: 'orderList',
                    action: 'orderList',
                    actionType: '1',
                    callback:false
                });
            },

            // 分期页面
            jumpStages:function(){
                flyMobile.data({
                    source:'myStages',
                    action:'myStages',
                    actionType:'1',
                    callback:false
                });
            },

            //我的卡劵
            jumpVoucherList:function(){
                flyMobile.data({
                    source: 'voucherList',
                    action: 'voucherList',
                    actionType: '1',
                    callback: false
                });
            },

            // 帮你选车
            jumpDialogue:function(){
                flyMobile.data({
                    source: 'myIndex',
                    action: 'http://m.haochedaojia.net/html/information-dialogue.html',
                    actionType: '2',
                    callback:false
                });
            },

            // 车辆估价
            jumpEvaluation:function(){
                flyMobile.data({
                    source: 'myIndex',
                    action: 'http://m.haochedaojia.net/html/car-evaluation-search.html',
                    actionType: '2',
                    callback: false
                });
            },

            //违章查询
            jumpPeccancy:function(){
                flyMobile.data({
                    source: 'myIndex',
                    action: 'http://m.haochedaojia.net/html/car-search.html',
                    actionType: '2',
                    callback: false
                });
            },

            // 分享有礼
            jumpShareGift:function(){
                flyMobile.data({
                    source:'shareGift',
                    action:'shareGift',
                    actionType: '1',
                    callback: false
                });
            },

            // 金融试算
            jumpFinancialTrial:function(){
                flyMobile.data({
                    source: 'myIndex',
                    action: 'financial-trial',
                    actionType: '1',
                    callback: false
                });
            },

            // 关于好车
            jumpAboutUs:function(){
                flyMobile.data({
                    source:'aboutGoodCar',
                    action:'aboutGoodCar',
                    actionType:'1',
                    callback:false
                });
            },

            // 车辆管理
            jumpUploadList:function(){
                flyMobile.data({
                    source: 'carManage',
                    action: 'carManage',
                    actionType: '1',
                    callback: false
                });
            },

            // 预约管理
            jumpAppointManage:function(){
                flyMobile.data({
                    source: 'appointAdmin',
                    action: 'appointAdmin',
                    actionType: '1',
                    callback: false
                });
            },

            // 收藏管理
            jumpCollectManage:function(){
                flyMobile.data({
                    source: 'collectManage',
                    action: 'collectManage',
                    actionType: '1',
                    callback: false
                });
            },

            // 联系客服
            jumpCustomer:function(){
                flyMobile.data({
                    source: 'myIndex',
                    action: 'jumpCustomer',
                    actionType: '3',
                    callback: false
                });
            },

            // 帮助与反馈
            jumpFeedback:function(){
                flyMobile.data({
                    source: 'helpSupport',
                    action: 'helpSupport',
                    actionType: '1',
                    callback: false
                });
            },

            // 设置
            jumpSetInfor: function () {
                flyMobile.data({
                     source: 'myIndex',
                    action: 'jumpsetInfor',
                    actionType: '3',
                    callback: false
                });
            },

            // 退出登录
            jumpExitLogon:function(){
                flyMobile.data({
                    source: 'myIndex',
                    action: 'jumpSet',
                    actionType: '3',
                    callback: false
                });
            }
        }
    });
    fly.bind(document.body, vm);
});
