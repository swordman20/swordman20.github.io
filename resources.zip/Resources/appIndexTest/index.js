/**
 * @author: xiaomei
 * @date: 2018.6.21
 * @description 首页
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll'
], function (doT, flyMobile, jquery, common,iscroll){
    var headerCont=$('.js-header');

    //头部滚动
    $(window).scroll(function(){
        var scroll_top=$(window).scrollTop();
        if(scroll_top>=100){
            headerCont.addClass('header-bg');
        }else{
            headerCont.removeClass('header-bg');
        }
    });

    //获取数据
    var params=[{"getPageData":{
            "action":"banner",
            "url":"third/api/banner/queryBannerList",
            "params":"{\"param\":\"banner\"}"
        }},{"getPageData":{
            "action":"selectedCar",
            "url":"goods/car/source/list",
            "params":"{\"orderBy\":\"upDate\",\"orderDir\":\"desc\",\"pageNo\":0,\"pageSize\":10,\"param\":{\"isFeatured\":1}}"
        }},{"getPageData":{
            "action":"selectedCar",
            "url":"goods/car/source/list",
            "params":"{\"orderBy\":\"upDate\",\"orderDir\":\"desc\",\"pageNo\":0,\"pageSize\":10,\"param\":{\"isQuality\":1}}"
        }},{"getPageData":{
            "action":"selectedCar",
            "url":"crm/api/problem/findProblems",
            "params":"{\"param\":\"home\"}"
        }}];

    flyMobile.data({
        args:params[0],
        callback:true
    }).done(function(obj){
        console.log(obj);
        obj=JSON.parse(obj);
        if(obj.statusCode == 200){
            var requestTmpl = doT.template($('#homeBannerTemple').text());
            $('.js-banner-list').html('').append(requestTmpl(obj.data));
            var bannerSwiper = new Swiper('.js-banner',{
                loop:true,
                autoplay:3000,
                speed:50
            });
            //禁止播放
            if (obj.data.length < 2) {
                bannerSwiper.autoplay=false;
            }
        }
    });

    flyMobile.data({
        args:params[1],
        callback:true
    }).done(function(obj){
        console.log(obj);
        obj=JSON.parse(obj);
        var requestTmpl = doT.template($('#newCarTemple').text()),
            objData=obj.data.rows;
        if (obj.statusCode == 200){
            $('.js-week-list').html('').append(requestTmpl(objData.slice(0,4)));
        }
    });

    flyMobile.data({
        args:params[2],
        callback:true
    }).done(function(obj){
        console.log(obj);
        obj=JSON.parse(obj);
        var requestTmpl = doT.template($('#newCarTemple').text()),
            resJson = obj.data.rows;
        if (obj.statusCode == 200){
            $('.js-second-car').html('').append(requestTmpl(resJson.slice(0,4)));
        }
    });

    flyMobile.data({
        args:params[3],
        callback:true
    }).done(function(obj){
        console.log(obj);
        obj=JSON.parse(obj);
        var requestTmpl = doT.template($('#questionTemple').text());
        if (obj.statusCode == 200){
            $('.js-question-list').html('').append(requestTmpl(obj.data));
        }
    });

    var vm = window.vm = fly({
        data:{},
        event:{},
        page:{
            //搜索
            jumpIndexSearch:function(){
                flyMobile.data({
                    source: 'indexSearch',
                    action: 'indexSearch',
                    actionType: '1',
                    callback:false
                });
            },

            //新车团购
            jumpNewCarList: function(e){
                var params={"source":"appIndexTest/appIndexTest.html",
                        "uri":"newCarList/newCarList.html",
                        "params":{}
                };
                flyMobile.data({
                    args:params,
                    callback:false
                })

            },

            //新车筛选
            jumpParameterNewList:function(){
                var typeCont = $(this).data('type'),
                    sortCont=$(this).data('order');
                var params={
                    typeCont:typeCont,
                    orderDir:sortCont
                };
                flyMobile.data({
                    source:'appIndex',
                    action:'jumpNewCarList',
                    args:params,
                    actionType:'3',
                    callback:false
                });
            },

            // 优选二手车
            jumpSecondCarList: function (e) {
                var params={"source":"appIndexTest/appIndexTest.html",
                    "uri":"secondCarList/secondCarList.html",
                    "params":{}
                };
                flyMobile.data({
                    args:params,
                    callback:false
                })
            },

            //车主服务
            jumpCarService: function(e){
                flyMobile.data({
                    source: 'carService',
                    action: 'carService',
                    actionType: '1',
                    callback: false
                });
            },

            // 领劵中心
            jumpVoucherCenter: function(e){
                flyMobile.data({
                    source: 'voucherCenter',
                    action: 'voucherCenter',
                    actionType: '1',
                    callback: false
                });
            },

            // 帮助与支持
            jumpQuestionList: function(e){
                flyMobile.data({
                    source:'helpSupport',
                    action:'helpSupport',
                    actionType:'1',
                    callback:false
                });
            },

            // 新车详情页
            jumpCarDetail: function (e){
                var id = $(this).data('id');
                var params={
                    id:id
                };
                flyMobile.data({
                    source: 'newCarListDetail',
                    action: 'newCarListDetail',
                    actionType: '1',
                    args:params,
                    callback: false
                });
            },

            // 二手车详情页
            jumpCarSecondDetail: function (e){
                var id = $(this).data('id');
                var params={
                    id:id
                };
                flyMobile.data({
                    source: 'secondCarListDetail',
                    action: 'secondCarListDetail',
                    actionType: '1',
                    args:params,
                    callback: false
                });
            },

            // 跳转到合肥区域页面
            jumpAreaSelect: function(e){
                var area = $(e.currentTarget).data('id');
                flyMobile.data({
                    source:'appIndex',
                    action:'jumpAreaSelect',
                    actionType:'3',
                    args:area,
                    callback:false
                });
            },

            // 跳转到车辆搜索页面
            jumpCarSearch: function(e){
                flyMobile.data({
                    source: 'carSearch',
                    action: 'carSearch',
                    actionType: '1',
                    callback: false
                });
            },

            //好车问答效果
            goodCarQuestion:function(){
                $(this).siblings('p').slideToggle('slow');
                $(this).parent('li').find('p').slideUp();
                if($(this).find('span').hasClass('cur')){
                    $(this).find('span').removeClass('cur');
                }else{
                    $(this).find('span').addClass('cur');
                }
            }
        }
    });

    $('.js-question-list').on('click','li .js-question',vm.page.goodCarQuestion);

    fly.bind(document.body, vm);
});