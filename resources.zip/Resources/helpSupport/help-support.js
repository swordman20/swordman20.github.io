/**
 * @author: xiaomei
 * @date: 2018.6.20
 * @description 帮助和支持
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery'
], function (doT, flyMobile, jquery,common) {
    var supportStyle=$('.js-support-list'),
        supportNav=$('.js-support-nav');

    var vm = window.vm = fly({
        page: {
            // 切换tabs
            clickTabs: function (e) {
                var typeValue = $(e.currentTarget).data('type'),
                    buyItem=$('.js-buy-item'),
                    costItem=$('.js-cost-item'),
                    useItem=$('.js-use-item');
                $(this).addClass('cur').siblings('li').removeClass('cur');
                switch(typeValue){
                    case 1:
                        buyItem.removeClass('hide');
                        costItem.addClass('hide');
                        useItem.addClass('hide');
                        break;
                    // 跳转到品牌
                    case 2:
                        buyItem.addClass('hide');
                        costItem.removeClass('hide');
                        useItem.addClass('hide');
                        break;
                    case 3:
                        buyItem.addClass('hide');
                        costItem.addClass('hide');
                        useItem.removeClass('hide');
                        break;
                }
            },

            //好车问答效果
            goodCarQuestion:function(){
                $(this).siblings('p').slideToggle('slow');
            }
        }
    });

    var dao={
        //好车问答列表
        getQuestionData:function(){
            var params={"param":"mine"};
            $.ajax({
                headers: {'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'crm/api/problem/findProblems',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(res){
                    if (res.statusCode == 200){
                        var requestTmpl = doT.template($('#questionTemple1').text());
                        supportStyle.append(requestTmpl(res.data));
                    }else{
                        common.toast("帮助与支持:"+res.message, '', '', '');
                    }
                },
                error:function(e){
                    common.hideToast();
                }
            });
        }
    };

    dao.getQuestionData();
    supportStyle.on('click','li .js-question',vm.page.goodCarQuestion);
    supportNav.on('click','li',vm.page.clickTabs);

    fly.bind(document.body, vm);
});