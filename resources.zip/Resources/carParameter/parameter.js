/**
 * @author: xiaomei
 * @date: 2018.6.20
 * @description 参数配置
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery'
], function (doT,flyMobile, jquery,common){

    var params={"param":'60'};

    var vm = window.vm = fly({
        data:{}
    });

    var dao = {
        //基本参数
        getTotalCarInfo: function(){
           common.showToast();
            $.ajax({
                headers: {'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'car/api/source/detail',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(res){
                    common.hideToast();
                    var configData = res.data.basicMapConfig,arry = [];
                    for (var i in configData) {
                        var obj = [];
                        if(i=="基本参数" || i=="车身"){
                            for(var j in configData[i]){
                                obj.push({name:j, text:configData[i][j]});
                            }
                            arry.push({key:i, value: obj});
                        }
                    }

                    var configDataTmpl = doT.template($('#basicParameterTemple').text());
                    $('.js-basic').append(configDataTmpl(arry[0].value));
                    $('.js-car-body').append(configDataTmpl(arry[1].value));
                },
                error:function(e){
                    common.hideToast();
                    common.toast(e.message);
                }
            });
        }
    };

    dao.getTotalCarInfo();

    fly.bind(document.body, vm);
});