/**
 * @author: xiaomei
 * @date: 2018.6.8
 * @description 车辆描述
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'serverUrl',
    'jquery'
], function (doT, flyMobile, jquery,serverUrl) {

    var vm = window.vm = fly({
        data: {
            carDescribe: "" //车辆描述
        }
    });
    var dao = {
        /**
         * [获取用户id ]
         */
        getCollectionData: function(type){
            flyMobile.data({
                source: 'upload-car-des',
                action: 'id',
                actionType: '3',
                callback: true
            }).done(function (res) {
                res = JSON.parse(res);
                if(res.data){
                    getUploadData(res.data);
                }else {

                }
            });
        },
        /**
         * [车辆列表 ]
         */
        getUploadData: function(id){
            // flyMobile.data({
            //     source: 'my',
            //     action: 'collectionData',
            //     actionType: '4',
            //     path: 'car/api/source/getBasicDetail',
            //     args: {"param":id},
            //     callback: true
            // }).done(function (res) {
            //     res = JSON.parse(res);
                res = { 
                    data: {
                    carDescription: "车辆描述车辆描述车辆描述车辆描述车辆描述车辆描述车辆描述车辆描述车辆描述车辆描述车辆描述车辆描述车辆描述车辆描述车辆描述车辆描述车辆描述",
                    }
                };
                if (res != undefined && res.statusCode == 200 && !(res.data === null)) {
                    vm.data.set('carDescribe', res.data.carDescription);
                }
            // }); 
        }
    };
    var init = function () {
        dao.getUploadData();
    };
    init();
    fly.bind(document.body, vm);
});