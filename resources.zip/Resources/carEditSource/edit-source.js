/**
 * @author: xiaomei
 * @date: 2018.9.25
 * @description 车辆编辑
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll'
], function (doT, flyMobile, jquery, common,iscroll){
    // 筛选条件
    var carClickNum=false,params={'param':"257"};

    var bgColor=$('.js-select-bg'),
        bgColorOne=$('.js-select-bg-one'),
        bombBg=$('.js-rank-bg'),

        carDealer=$('.js-car-dealer'),
        carTypeName=$('.js-car-type'),
        selectCarColor=$('.js-sure-color'),
        proInfo=$('.js-p-info'),

        selectColorList=$('.js-select-cont'),
        proList=$('.js-p-list'),
        selectCar=$('.js-select-car'),
        proType=$('.js-t-list'),
        carSystem=$('.js-car-system'),
        carType=$('.js-s-car-type'),

        procedureInfoCont=$(".js-procedure-info"),
        selectAllCar=$('.js-all-car'),
        carSystemDetail=$('.js-system-car');

    //获取参数
    window.getParams = function(res){
        params.param=res.param;
        dao.getUploadData();
    };

    //获取车辆照片
    window.getImgCar=function(res){
        $('.js-car-pic').find('img').attr('src',res);
    };

    //获取证件照片
    window.getImgZj=function(res){
        $('.js-paper-pic').find('img').attr('src',res);
    };

    //获取其他照片
    window.getImgElse=function(res){
        $('.js-else-pic').find('img').attr('src',res);
    };

    //获取照片个数
    window.getImgCount=function(res){
        res = JSON.parse(res);
        $('.js-car-num').html(res.carCount);
        $('.js-paper-num').html(res.zjCount);
        $('.js-else-num').html(res.elseCount);
    };

    var vm = window.vm = fly({
        data: {},
        event:{},
        page: {
            // 新增图片
            jumpPic: function(e){
                flyMobile.data({
                    source:'',
                    action:'jumpUploadPhoto',
                    actionType:'3',
                    args:'',
                    callback:false
                });
            },

            // 车商
            jumpCarName:function(){
                selectCar.addClass('p-show');
                bombBg.show();
                flyMobile.data({
                    source:'carAddSource',
                    action:'',
                    actionType:'4',
                    path:'crm/api/supplier/listAll',
                    callback:true
                }).done(function (res){
                    if(res.statusCode == 200){
                        if(res.data.length>0){
                            var requestTmpl = doT.template($('#selectCarTemple').text());
                            if(carClickNum==false){
                                $('.js-select-car-cont').append(requestTmpl(res.data));
                            }
                        }else{
                            $('.js-no').removeClass('hide');
                        }
                    }else{
                        common.toast(res.message);
                    }
                });
            },

            //确定车行
            selectCarLine:function(){
                var carLineData=$(this).attr('data-type'),
                    carLineId=$(this).attr('data-id');
                $(this).addClass('active').siblings().removeClass('active');
                setTimeout(function(){
                    selectCar.removeClass('p-show');
                    bombBg.hide();
                    carDealer.attr('data-id',carLineId).html(carLineData);
                },500);
                carClickNum=true;
            },

            //关闭车商
            closeCar:function(){
                selectCar.removeClass('p-show');
                carClickNum=true;
                bombBg.hide();
            },

            //选择车辆名称
            selectCarName:function(){
                var params={"param":""};
                proType.addClass('p-show');
                common.showToast();
                $("body").addClass('over-hidden');
                flyMobile.data({
                    source:'carAddSource',
                    action:'',
                    actionType:'4',
                    path:'car/api/brand/listByLetter',
                    args:params,
                    callback:true
                }).done(function (res){
                    if(res.statusCode == 200){
                        var requestTmpl = doT.template($('#selectCarTypeTemple').text());
                        selectAllCar.append(requestTmpl(res.data));
                    }else{
                        common.toast(res.message);
                    }
                });
            },

            //选择车系
            jumpCarSystemName:function(e){
                var _thisId=$(e.currentTarget).attr('data-id'),
                    params={"param":_thisId};
                carTypeName.attr('data-line',_thisId);
                carTypeName.attr('data-one',$(e.currentTarget).attr('data-name'));
                $(e.currentTarget).addClass('active').siblings('li').removeClass('active');
                $(e.currentTarget).parent().siblings().find('li').removeClass('active');
                carSystem.addClass('p-show');
                proType.addClass('no-scroll');
                bgColor.show();
                flyMobile.data({
                    source:'carSelectName',
                    action:'',
                    actionType:'4',
                    args:params,
                    path:'car/api/series/list',
                    callback:true
                }).done(function (res){
                    if(res.statusCode == 200){
                        var requestTmpl = doT.template($('#carSystemTemple').text());
                        carSystemDetail.html('').append(requestTmpl(res.data));
                    }else{
                        common.toast(res.message);
                    }
                });
            },

            //关闭车系
            closeCarSystem:function(){
                carSystem.removeClass('p-show');
                proType.removeClass('no-scroll');
                bgColor.hide();
            },

            //选择车型
            jumpCarType:function(e){
                var _thisId=$(e.currentTarget).attr('data-id'),
                    params={"param":_thisId};
                carTypeName.attr('data-type',_thisId);
                carTypeName.attr('data-two',$(e.currentTarget).attr('data-name'));
                $(e.currentTarget).addClass('active').siblings('li').removeClass('active');
                carType.addClass('p-show');
                carSystem.addClass('no-scroll');
                bgColorOne.show();
                flyMobile.data({
                    source:'carSelectName',
                    action:'',
                    actionType:'4',
                    args:params,
                    path:'car/api/model/listByYear',
                    callback:true
                }).done(function (res){
                    if(res.statusCode == 200){
                        var requestTmpl = doT.template($('#carTypeTemple').text());
                        carType.html('').append(requestTmpl(res.data));
                    }else{
                        common.toast(res.message);
                    }
                });
            },

            //关闭车型
            closeCarTypeSelect:function(){
                bgColorOne.hide();
                carType.removeClass('p-show');
                carSystem.removeClass('no-scroll');
            },

            //确认车型
            jumpSureCarType:function(e){
                vm.page.closeCarType();
                vm.page.closeCarSystem();
                vm.page.closeCarTypeSelect();
                carTypeName.html($(e.currentTarget).attr('data-name'));
                carTypeName.attr('data-label',$(e.currentTarget).attr('data-label'));
                carTypeName.attr('data-three',$(e.currentTarget).attr('data-name'));
            },

            //关闭车辆名称
            closeCarType:function(){
                proType.removeClass('p-show');
                $("body").removeClass('over-hidden');
            },

            //选择颜色
            clickColor:function(){
                bombBg.show();
                selectColorList.addClass('show-color');
            },

            //确定颜色
            clickSelectColor:function(){
                var colorValue=$(this).attr('data-color');
                $(this).addClass('cur').siblings().removeClass('cur');
                setTimeout(function(){
                    bombBg.hide();
                    selectColorList.removeClass('show-color');
                    selectCarColor.html(colorValue);
                },500);
            },

            //关闭颜色选择
            closeColor:function(){
                bombBg.hide();
                selectColorList.removeClass('show-color');
            },

            //手续信息
            jumpProcedures: function(){
                bombBg.show();
                proList.addClass('p-show');
            },

            //关闭手续信息选择
            clickCancel:function(){
                proList.removeClass('p-show');
                bombBg.hide();
            },

            //确定手续信息
            clickSure:function(){
                var allSelect=true;
                procedureInfoCont.find("input").each(function(){
                    var dataLabel=$(this).attr('data-label');
                    if(!$.trim($('input:radio[name='+dataLabel+']:checked').val())){
                        common.toast('请选择'+dataLabel);
                        allSelect=false;
                    }
                });

                if(allSelect==true){
                    var infoData=procedureInfoCont.serializeArray(),
                        infoDataJson = JSON.stringify(infoData);
                    proInfo.attr('data-type',infoDataJson);
                    proInfo.html('手续信息已选择');
                    proList.removeClass('p-show');
                    bombBg.hide();
                }
            },

            // 提交
            clickSubmit: function (){
                if(!$.trim($("input[name='vin']").val())){
                    common.toast('VIN不能为空');
                }else if(carDealer.html()=="请选择车商名称"){
                    common.toast('车商不能为空');
                }else if(carTypeName.html()=="请选择车辆名称"){
                    common.toast('车辆名称不能为空');
                }else if(!$.trim($("input[name='sellPrice']").val())){
                    common.toast('车辆价格不能为空');
                }else if(selectCarColor.html() =='请选择车辆颜色'){
                    common.toast('车辆颜色不能为空');
                }else if(!$.trim($("input[name='kilometers']").val())){
                    common.toast('公里数不能为空');
                }else if($("input[name='firstOnCard']").val() =='请选择日期'){
                    common.toast('初次上牌不能为空');
                }else if(proInfo.html() =='请选择手续信息'){
                    common.toast('手续信息不能为空');
                }else if(!$.trim($(".js-car-describe").val())){
                    common.toast('描述不能为空');
                }else if($('.js-car-num').html()=="0"){
                    common.toast('请选择车辆照');
                }else if($('.js-paper-num').html()=="0"){
                    common.toast('请选择证件照');
                }else if($('.js-else-num').html()=="0"){
                    common.toast('请选择其他照');
                }else{
                    var params={
                        carCategory:2,
                        kilometers:$("input[name='kilometers']").val(),
                        sourceName:carTypeName.html(),
                        sellPrice:$("input[name='sellPrice']").val(),
                        vin:$("input[name='vin']").val(),
                        color: selectCarColor.html(),
                        firstOnCard:$("input[name='firstOnCard']").val(),
                        formalities:proInfo.attr('data-type'),
                        carDealer:carDealer.html(),
                        supplierId:carDealer.attr('data-id'),
                        ownerDescription:$(".js-car-describe").val(),
                        brandId:carTypeName.attr('data-line'),
                        seriesId:carTypeName.attr('data-type'),
                        modelId:carTypeName.attr('data-label'),
                        brandName:carTypeName.attr('data-one'),
                        seriesName:carTypeName.attr('data-two'),
                        modelName:carTypeName.attr('data-three')
                    };
                    flyMobile.data({
                        source:'',
                        action:'',
                        actionType:'5',
                        args:params,
                        callback:false
                    });
                }
            }
        }
    });
    var dao = {
        getDateWidget: function() {
            var calendarym = new LCalendar();
            calendarym.init({
                'trigger': '#lcalendar',
                'type': 'ym',
                'minDate': '1900-01',
                'maxDate': new Date().getFullYear() + '-' + (new Date().getMonth() + 1),
                'callback': function(){}
            }); 
        },

        //车辆详情
        getUploadData: function(){
            common.showToast();
            $.ajax({
                headers:{'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'car/api/source/getBasicDetail',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(res){
                    common.hideToast();
                    $('.js-edit1').val(res.data.vin);
                    $('.js-car-dealer').html(res.data.supplierName);
                    $('.js-car-type').html(res.data.sourceName);
                    $('.js-edit2').val(res.data.sellPrice);
                    $('.js-sure-color').html(res.data.color);
                    $('.js-edit3').val(res.data.kilometers);
                    $('#lcalendar').val(res.data.firstOnCard.substring(0,7));
                    $('.js-p-info').html('已选择');
                    $('.js-car-describe').val(res.data.ownerDescription);

                    //获取上传图片信息
                    var upLoadPic=res.data.attachInfoList,fullPhoto=[],cerPhoto=[],otherPhoto=[];
                    for(var i=0;i<upLoadPic.length;i++){
                        if(upLoadPic[i].attachType=="1"){
                            fullPhoto.push(upLoadPic[i])
                        }else if(upLoadPic[i].attachType=="2"){
                            cerPhoto.push(upLoadPic[i])
                        }else{
                            otherPhoto.push(upLoadPic[i])
                        }
                    }
                    $('.js-car-num').html(fullPhoto.length);
                    $('.js-paper-num').html(cerPhoto.length);
                    $('.js-else-num').html(otherPhoto.length);
                    $('.js-car-pic').find('img').attr('src',fullPhoto[0].fileUrl);
                    $('.js-paper-pic').find('img').attr('src',cerPhoto[0].fileUrl);
                    $('.js-else-pic').find('img').attr('src',otherPhoto[0].fileUrl);


                    proInfo.attr('data-type',JSON.stringify(res.data.formalitiesMap));

                    //手续信息
                    var requestTmpl = doT.template($('#formalitiesTemple').text());
                    $('.js-procedure-info').append(requestTmpl(res.data.formalitiesMap));
                }
            });
        }
    };
    var addEvent = function(){
        selectColorList.on('click','li',vm.page.clickSelectColor);
        $('.js-select-car-cont').on('click','li',vm.page.selectCarLine);
        selectAllCar.on('click','.js-all-item',vm.page.jumpCarSystemName);
        carSystemDetail.on('click','li.js-system',vm.page.jumpCarType);
        carType.on('click','.js-type-item',vm.page.jumpSureCarType);
    };

    dao.getUploadData();

    dao.getDateWidget();
    addEvent();

    fly.bind(document.body, vm);
});
