/**
 * @author: xiaomei
 * @date: 2018.11.12
 * @description 首页
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll'
], function (doT, flyMobile, jquery, common,iscroll){
    var headerCont=$('.js-header');

    //头部滚动
    $(window).scroll(function(){
        var scroll_top=$(window).scrollTop();
        if(scroll_top>=100){
            headerCont.addClass('header-bg');
        }else{
            headerCont.removeClass('header-bg');
        }
    });

    //获取轮播图
    window.getAdvertising = function(res){
        res = JSON.parse(res);
        if (res.statusCode == 200) {
            var requestTmpl = doT.template($('#homeBannerTemple').text());
            $('.js-banner-list').html('').append(requestTmpl(res.data));
            var bannerSwiper = new Swiper('.js-banner',{
                loop:true,
                autoplay:5000,
                speed:80
            });
            //禁止播放
            if (res.data.length < 2) {
                bannerSwiper.autoplay=false;
            }
        }
    };

    //维保精选服务
    window.getGoodsData=function(res){
        res = JSON.parse(res);
        var requestTmpl = doT.template($('#repairTemple').text()),
            resData=res.data.rows;
        if (res.statusCode == 200){
            $('.js-service-list').html('').append(requestTmpl(resData.slice(0,4)));
        }
    };

    //获取城市
    window.getCityName=function(obj){
        if(typeof obj == "undefined" || obj == null || obj == ""){
            $('.js-header-address').html('定位失败')
        }else{
            $('.js-header-address').html(obj);
        }
    };

    var vm = window.vm = fly({
        data:{},
        event:{},
        page:{
            //搜索
            searchDetail:function(){
                var params={"searchCarType":0};
                flyMobile.data({
                    source: 'indexSearch',
                    action: 'indexSearch',
                    actionType: '1',
                    args:params,
                    callback:false
                });
            },

            //新车
            carNewList:function(e){
                flyMobile.data({
                    source:'newCarList',
                    action:'newCarList',
                    actionType:'1',
                    callback:false
                });
            },

            //二手车
            carSecondList: function (e) {
                flyMobile.data({
                    source:'secondCarList',
                    action:'secondCarList',
                    actionType:'1',
                    callback:false
                });
            },

            //汽车维修
            repairList:function(e){
                flyMobile.data({
                    source:'repairMaintain',
                    action:'repairMaintain',
                    actionType:'1',
                    callback:false
                });
            },

            //领劵中心
            voucherCenterList: function(e){
                flyMobile.data({
                    source: 'voucherCenter',
                    action: 'voucherCenter',
                    actionType: '1',
                    callback: false
                });
            },

            //选择城市
            jumpAreaSelect: function(){
                flyMobile.data({
                    source:'appIndex',
                    action:'citySelect',
                    actionType:'3',
                    callback:false
                });
            },

            //汽车维修详情页
            repairListDetail:function(e){
                var _this=$(e.currentTarget),
                    params={"goodsId":_this.attr('data-id')};
                flyMobile.data({
                    source:'goodsDetail',
                    action:'goodsDetail',
                    actionType:'1',
                    args:params,
                    callback:false
                })
            }

        }
    });

    $('.js-service-list').on('click','li',vm.page.repairListDetail);

    fly.bind(document.body, vm);

});