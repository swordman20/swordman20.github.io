/**
 * @author: xiaomei
 * @date: 2018.6.11
 * @description 车辆管理列表页
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'lazyLoad',
    'serverUrl',
    'jquery',
    'iscroll',
    'pullToRefresh'
], function (doT, flyMobile, jquery, common,lazyLoad, serverUrl, iscroll, pullToRefresh) {
    var pageSize = 10,
        currentPageNo = 1,
        upPermit = 0,
        clickCarLine=0,
        clickCarBrand=0;

    var carDetailNav=$('.js-car-nav'),
        carScreen=$('.js-screen'),
        carListDetail=$('.js-car-detail'),
        carRankBg=$('.js-rank-bg'),
        carLineBg=$('.js-line-bg'),
        carBrandBg=$('.js-brand-bg'),
        carScreenBg=$('.js-screen-bg'),
        carSort=$('.js-nav-drop'),
        carLineCont=$('.js-car-line'),
        carBrandCont=$('.js-car-brand'),
        saveScreen=$('.js-save-screen');

    // 筛选条件
    var params={
        "orderBy":"",
        "orderDir":"",
        "pageNo":1,
        "pageSize":10,
        "param":{
            "sellStatus":"",
            "status":"",
            "isSold":"",
            "supplierId":"",
            "brandId":"",
            "beginSellPrice":"",
            "endSellPrice":"",
            "beginKilometers":"",
            "endKilometers":""
        }
    };

    var vm = window.vm = fly({
        data:{},
        event: {
            pulltoDo: function() {
                //初始化上拉下拉操作
                refresher.init({
                    id: "wrapper",
                    pullDownAction: vm.event.reloadNew,
                    pullUpAction: vm.event.loadMore
                });
            },
            loadMore: function() {
                if (upPermit === 0) {
                    //上拉加载
                    currentPageNo++;
                    params.pageNo = currentPageNo;
                    $.ajax({
                        headers: {'Authorization':tokenValue},
                        type:'post',
                        url:serverApiUrl+'car/api/source/auditList',
                        async:false,
                        contentType:'application/json',
                        data:JSON.stringify(params),
                        dataType:"json",
                        success:function(res){
                            if(res.data.rows.length>0){
                                var requestTmpl = doT.template($('#uploadListTemple').text());
                                carListDetail.append(requestTmpl(res.data.rows));
                                if (res.data.rows.length < pageSize) {
                                    upPermit=1;
                                    refresher.onResherCompeted();
                                }
                                wrapper.refresh();
                            }
                        },
                        error:function(e){
                            $('.js-error').show().find('p').text(e.message);
                            refresher.onErrorCompeted();
                            $('.pullUpLabel').text('');
                            vm.event.pulltoDo();
                        }
                    });
                }else{
                    refresher.onResherCompeted();
                    wrapper.refresh();
                }
            },
            reloadNew: function(){
                //下拉刷新
                currentPageNo = 1;
                params.pageNo = currentPageNo;
                $.ajax({
                    headers: {'Authorization':tokenValue},
                    type:'post',
                    url:serverApiUrl+'car/api/source/auditList',
                    async:false,
                    contentType:'application/json',
                    data:JSON.stringify(params),
                    dataType:"json",
                    success:function(res){
                        common.hideToast();
                        if(res.data.rows.length>0) {
                            var requestTmpl = doT.template($('#uploadListTemple').text());
                            carListDetail.html('').append(requestTmpl(res.data.rows));
                            if(res.data.rows.length < pageSize){
                                refresher.onResherCompeted();
                                upPermit = 1;
                            }else{
                                upPermit = 0;
                            }
                            wrapper.refresh();
                        }else {
                            $('.empty').show();
                            refresher.onEmptyCompeted();
                            wrapper.refresh();
                            $('.pullUpLabel').text('');
                        }
                    },
                    error:function(e){
                        common.hideToast();
                        $('.js-error').show().find('p').text(e.message);
                        refresher.onErrorCompeted();
                        $('.pullUpLabel').text('');
                        vm.event.pulltoDo();
                    }
                });
            }
        },
        page: {
            // 车辆详情
            jumpCarDetail: function (e) {
                var id = $(e.currentTarget).data('id'),
                    params={"param":id};
                window.location.href=localhostUrl+"carListDetail/carListDetail.html?userId="+id;

                //IOS页面跳转
                // flyMobile.data({
                //     source: 'carListDetail',
                //     action: 'carListDetail',
                //     actionType: '1',
                //     args:params,
                //     callback:false
                // });
            },

            // 新增车辆数据
            jumpUploadAdd: function(e){
                window.location.href=localhostUrl+"carAddSource/carAddSource.html";

                //IOS页面跳转
                // flyMobile.data({
                //     source:'carAddSource',
                //     action:'carAddSource',
                //     actionType:'1',
                //     callback:false
                // });
            },

            //导航--筛选--排序
            clickScreen:function(e){
                var index = $(this).index();
                $(this).addClass('active').siblings().removeClass('active');
                switch(index){
                    //车行
                    case 0:
                        carRankBg.hide();
                        carSort.slideUp('slow');
                        carLineCont.slideToggle('slow');
                        carLineBg.toggle();
                        carLineCont.find('ul').removeClass('screen-show');
                        carBrandBg.hide();
                        carBrandCont.slideUp('slow');//品牌
                        if(clickCarLine==0){
                            $.ajax({
                                headers: {'Authorization':tokenValue},
                                type:'post',
                                url:serverApiUrl+'crm/api/supplier/listByCity',
                                async:false,
                                dataType:"json",
                                success:function(res){
                                    var requestTmpl = doT.template($('#selectCarLineTemple').text());
                                    carLineCont.html('').append(requestTmpl(res.data));
                                    clickCarLine=1;
                                }
                            });
                        }
                        break;
                    //品牌
                    case 1:
                        carRankBg.hide();
                        carSort.slideUp('slow');

                        carLineCont.slideUp('slow');
                        carLineBg.hide();
                        carLineCont.find('ul').removeClass('screen-show');

                        carBrandBg.toggle();
                        carBrandCont.slideToggle('slow');

                        var params={"param":"1"};
                        if(clickCarBrand==0){
                            $.ajax({
                                headers: {'Authorization':tokenValue},
                                type:'post',
                                url:serverApiUrl+'car/api/brand/listByLetter',
                                async:false,
                                contentType:'application/json',
                                data:JSON.stringify(params),
                                dataType:"json",
                                success:function(res){
                                    common.hideToast();
                                    var requestTmpl = doT.template($('#selectCarBrandTemple').text());
                                    carBrandCont.html('').append(requestTmpl(res.data));
                                    clickCarBrand=1;
                                },
                                error:function(e){
                                    common.toast(e.message);
                                }
                            });
                        }

                        break;
                    // 排序
                    case 2:
                        carLineCont.slideUp('slow');
                        carLineBg.hide();
                        carLineCont.find('ul').removeClass('screen-show');
                        carBrandBg.hide();
                        carBrandCont.slideUp('slow');//品牌

                        carSort.slideToggle('slow');
                        carRankBg.toggle();

                        break;
                    case 3:
                        carRankBg.hide();
                        carSort.slideUp('slow');
                        carScreen.toggleClass('screen-show');
                        carScreenBg.toggle();
                        break;
                }
            },

            // 选择排序内容
            clickSort: function(e){
                var _this=$(this);
                _this.addClass('cur').siblings().removeClass('cur');
                $('.js-select-cont').text($(this).text());
                params.orderBy=_this.attr('data-type');
                params.orderDir=_this.attr('data-order');
                params.param.supplierId="";
                carRankBg.hide();
                carSort.slideUp('slow');
                $.ajax({
                    headers: {'Authorization':tokenValue},
                    type:'post',
                    url:serverApiUrl+'car/api/source/auditList',
                    async:false,
                    contentType:'application/json',
                    data:JSON.stringify(params),
                    dataType:"json",
                    success:function(res){
                        if(res.data.rows.length>0){
                            var requestTmpl = doT.template($('#uploadListTemple').text());
                            carListDetail.empty().append(requestTmpl(res.data.rows));
                            if (res.data.rows.length < pageSize) {
                                refresher.onResherCompeted();
                                upPermit = 1;
                            } else {
                                refresher.onInitCompeted();
                            }
                            vm.event.pulltoDo();
                        }else {
                            $('.empty').show();
                            refresher.onEmptyCompeted();
                            $('.pullUpLabel').text('');
                        }
                    },
                    error:function(e){
                        common.hideToast();
                        $('.js-error').show().find('p').text(e.message);
                        refresher.onErrorCompeted();
                        $('.pullUpLabel').text('');
                        vm.event.pulltoDo();
                    }
                });
            },

            //车行市选择
            carLineScreen:function(e){
                var _this=$(this);
                _this.addClass('active').parent().siblings().find('h4').removeClass('active');
                _this.siblings('ul').addClass('screen-show').parent().siblings().find('ul').removeClass('screen-show');
            },

            //车行确定
            sureCarLine:function(e){
                var _this=$(e.currentTarget);
                params.param.supplierId=_this.attr('data-id');
                carLineCont.slideUp('slow');
                carLineBg.hide();
                carLineCont.find('ul').removeClass('screen-show');
                $.ajax({
                    headers: {'Authorization':tokenValue},
                    type:'post',
                    url:serverApiUrl+'car/api/source/auditList',
                    async:false,
                    contentType:'application/json',
                    data:JSON.stringify(params),
                    dataType:"json",
                    success:function(res){
                        if(res.data.rows.length>0){
                            var requestTmpl = doT.template($('#uploadListTemple').text());
                            carListDetail.empty().append(requestTmpl(res.data.rows));
                            $('.empty').hide();
                            if (res.data.rows.length < pageSize) {
                                refresher.onResherCompeted();
                                upPermit = 1;
                            } else {
                                refresher.onInitCompeted();
                            }
                            vm.event.pulltoDo();
                        }else {
                            carListDetail.empty();
                            $('.empty').show();
                            refresher.onEmptyCompeted();
                            $('.pullUpLabel').text('');
                        }
                    },
                    error:function(e){
                        common.hideToast();
                        $('.js-error').show().find('p').text(e.message);
                        refresher.onErrorCompeted();
                        $('.pullUpLabel').text('');
                        vm.event.pulltoDo();
                    }
                });
            },

            //确定品牌
            sureCarBrand:function(e){
                var _this=$(e.currentTarget);
                params.param.brandId=_this.attr('data-id');
                params.orderBy="";
                params.orderDir="";
                params.param.supplierId="";
                carBrandBg.hide();
                carBrandCont.slideUp('slow');
                $.ajax({
                    headers: {'Authorization':tokenValue},
                    type:'post',
                    url:serverApiUrl+'car/api/source/auditList',
                    async:false,
                    contentType:'application/json',
                    data:JSON.stringify(params),
                    dataType:"json",
                    success:function(res){
                        if(res.data.rows.length>0){
                            var requestTmpl = doT.template($('#uploadListTemple').text());
                            carListDetail.empty().append(requestTmpl(res.data.rows));
                            $('.empty').hide();
                            if (res.data.rows.length < pageSize) {
                                refresher.onResherCompeted();
                                upPermit = 1;
                            } else {
                                refresher.onInitCompeted();
                            }
                            vm.event.pulltoDo();
                        }else {
                            carListDetail.empty();
                            $('.empty').show();
                            refresher.onEmptyCompeted();
                            $('.pullUpLabel').text('');
                        }
                    },
                    error:function(e){
                        common.hideToast();
                        $('.js-error').show().find('p').text(e.message);
                        refresher.onErrorCompeted();
                        $('.pullUpLabel').text('');
                        vm.event.pulltoDo();
                    }
                });
            },

            // 关闭更多筛选
            closeScreen:function(){
                carScreen.removeClass('screen-show');
            },

            //筛选--车辆状态
            selectState:function(){
                $(this).addClass('cur').siblings().removeClass('cur');
                saveScreen.attr('data-name',$(this).attr('data-type'));
            },

            //筛选--审核状态
            examineState:function(){
                $(this).addClass('cur').siblings().removeClass('cur');
                if($(this).hasClass('js-examine')){
                    $('.js-car-state').removeClass('gray-select').addClass('js-select');
                }else{
                    $('.js-car-state').addClass('gray-select').removeClass('js-select');
                }
                saveScreen.attr('data-type',$(this).attr('data-type'));
            },

            //确定更多选择
            moreScreenSure:function(){
                var carExamine=saveScreen.attr('data-type'),
                    carState=saveScreen.attr('data-name');
                if(carExamine=="status1"){
                    params.param.status=1;
                }else if(carExamine=="status2"){
                    params.param.status=2;
                    if(carState=="sellStatus1"){
                        params.param.sellStatus=1;
                    }else if(carState=="sellStatus2"){
                        params.param.sellStatus=2;
                    }else if(carState=="sellStatus3"){
                        params.param.sellStatus=3;
                    }else if(carState=="isSold1"){
                        params.param.isSold=1;
                    }else{
                        params.param.sellStatus="";
                        params.param.isSold="";
                    }
                }else if(carExamine=="status3"){
                    params.param.status=3;
                }else if(carExamine=="status4"){
                    params.param.status=4;
                }else if(carExamine=="status5"){
                    params.param.status=5;
                }else{
                    params.param.status="";
                    params.param.sellStatus="";
                    params.param.isSold="";
                };
                params.param.brandId="";
                params.orderBy="";
                params.orderDir="";
                params.param.supplierId="";

                var rangeOne=$('#range_1').val(),
                    rangeTwo=$('#range_2').val();
                params.param.beginSellPrice=rangeOne.split(";")[0];
                params.param.endSellPrice=rangeOne.split(";")[1];
                params.param.beginKilometers=rangeTwo.split(";")[0];
                params.param.endKilometers=rangeTwo.split(";")[1];

                carScreen.removeClass('screen-show');
                carScreenBg.hide();
                $.ajax({
                    headers: {'Authorization':tokenValue},
                    type:'post',
                    url:serverApiUrl+'car/api/source/auditList',
                    async:false,
                    contentType:'application/json',
                    data:JSON.stringify(params),
                    dataType:"json",
                    success:function(res){
                        if(res.data.rows.length>0){
                            var requestTmpl = doT.template($('#uploadListTemple').text());
                            carListDetail.empty().append(requestTmpl(res.data.rows));
                            $('.empty').hide();
                            if (res.data.rows.length < pageSize) {
                                refresher.onResherCompeted();
                                upPermit = 1;
                            } else {
                                refresher.onInitCompeted();
                            }
                            vm.event.pulltoDo();
                        }else {
                            carListDetail.empty();
                            $('.empty').show();
                            refresher.onEmptyCompeted();
                            $('.pullUpLabel').text('');
                        }
                    },
                    error:function(e){
                        common.hideToast();
                        $('.js-error').show().find('p').text(e.message);
                        refresher.onErrorCompeted();
                        $('.pullUpLabel').text('');
                        vm.event.pulltoDo();
                    }
                });
            }
        }
    });

    var dao = {
        //车辆列表
        getTotalCar: function(){
            common.showToast();
            $.ajax({
                headers: {'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'car/api/source/auditList',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(res){
                    common.hideToast();
                    if(res.data.rows.length>0){
                        var requestTmpl = doT.template($('#uploadListTemple').text());
                        carListDetail.append(requestTmpl(res.data.rows));
                        if (res.data.rows.length < pageSize) {
                            refresher.onResherCompeted();
                            upPermit = 1;
                        } else {
                            refresher.onInitCompeted();
                        }
                        vm.event.pulltoDo();
                    }else {
                        $('.empty').show();
                        refresher.onEmptyCompeted();
                        $('.pullUpLabel').text('');
                    }
                },
                error:function(e){
                    common.hideToast();
                    $('.js-error').show().find('p').text(e.message);
                    refresher.onErrorCompeted();
                    $('.pullUpLabel').text('');
                    vm.event.pulltoDo();
                }
            });
        }
    };

    var addEvent = function(){
        carDetailNav.on('click', '.js-nav li', vm.page.clickScreen);
        carSort.on('click', 'dd', vm.page.clickSort);
        carListDetail.on('click', 'li', vm.page.jumpCarDetail);
        carScreen.on('click','.js-close-screen',vm.page.closeScreen);
        carScreen.on('click','.js-examine-state dd',vm.page.examineState);
        carScreen.on('click','.js-select dd',vm.page.selectState);
        //选择车行
        carLineCont.on('click','.js-line-city',vm.page.carLineScreen);
        carLineCont.on('click','.js-line-item',vm.page.sureCarLine);
        //选择品牌
        carBrandCont.on('click','.js-brand-item',vm.page.sureCarBrand);
    };
    var init = function () {
        dao.getTotalCar();
        addEvent();
    };
    init();
    fly.bind(document.body, vm);
});