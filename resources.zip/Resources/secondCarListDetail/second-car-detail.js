/**
 * @author: xiaomei
 * @date: 2018.8.10
 * @description 二手车详情页
 */

require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll'
], function (doT, flyMobile,jquery,common,iscroll){

    var params={"param":257},
        discountData=$('.js-my-data');

    //获取用户信息
    window.getUserData = function(obj){
        if(obj.statusCode == 200){
            if(obj.data.userType==2){
                $('.js-show').addClass('hide');
                $('.js-hide').removeClass('hide');
            }
        }
    };

    $('.js-show').addClass('hide');
    $('.js-hide').removeClass('hide');


    var vm = window.vm = fly({
        data: {
            defaultDownPayments: "0",
            defaultMonthPayments: "0",
            defaultPeriods: "0",
            carGuidePrice: 0,
            sourceName: '',
            carDescription:'',
            cityName:'',
            supplierName:'',
            brandId: '',
            carCollect:"收藏",
            firstOnCard:"",
            sellPrice:"",
            kilometers:"",
            upDate:""
        },
        event:{},
        page: {
            //详细配置
            clickCarConfig: function () {
                var params={"userId":discountData.attr('data-id')};
                window.location.href=localhostUrl+"carParameter/carParameter.html";
            },

            // 收藏
            clickCarCollect: function(e){
                var params ={
                        "param":{
                            "carSourceId":"60",
                            "favAct":0
                        }
                    },
                    _this=$(e.currentTarget);

                if(_this.hasClass('active')){
                    params.param.favAct = 0
                }else{
                    params.param.favAct = 1;
                }

                $.ajax({
                    headers: {'Authorization':tokenValue},
                    type:'post',
                    url:serverApiUrl+'crm/api/user/fav',
                    async:false,
                    contentType:'application/json',
                    data:JSON.stringify(params),
                    dataType:"json",
                    success:function(res){
                        if(params.param.favAct == 0){
                            _this.removeClass('active');
                            vm.data.set('carCollect', '收藏');
                            common.toast("取消收藏成功");
                        }else {
                            _this.addClass('active');
                            vm.data.set('carCollect', '已收藏');
                            common.toast("收藏成功");
                        }
                    },
                    error:function(e){
                        common.toast(e.message);
                    }
                });
            },

            // 预约
            jumpAppointFrom: function () {
                var params={
                    "carUserId":discountData.attr('data-id'),
                    "carUserUrl": discountData.attr('data-url'),
                    "carUserName":discountData.attr('data-name')
                };
                window.location.href=localhostUrl+"goAppoint/goAppoint.html";
            },

            //客服
            clickPhone: function () {
                flyMobile.data({
                    source: 'newCarListDetail',
                    action: 'jumpCustomer',
                    actionType: '3',
                    callback: false
                });
            },

            // 我要优惠
            myDiscount:function(){
                var params={
                    "carUserId":discountData.attr('data-id'),
                    "carUserUrl": discountData.attr('data-url'),
                    "carUserName":discountData.attr('data-name')
                };
                window.location.href=localhostUrl+"carDiscount/carDiscount.html?params="+discountData.attr('data-id');
            },

            // 金融方案
            financeService: function () {
                var params={"userId":discountData.attr('data-id')};
                window.location.href=localhostUrl+"buyStage/buyStage.html";
            },

            // 门店信息
            storeDetail:function(){
                var params={"userId":discountData.attr('data-id')};
                window.location.href=localhostUrl+"carStoreDetail/carStoreDetail.html";
            }
        }
    });
    var dao = {
        //车辆详情
        getCarData: function(){
            $.ajax({
                headers: {'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'car/api/source/detail',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(res){
                    vm.data.set('sourceName', res.data.sourceName || 0);
                    vm.data.set('carGuidePrice', res.data.carGuidePrice || 0);
                    vm.data.set('sellPrice', res.data.sellPrice || 0);
                    vm.data.set('carFirstPrice', (res.data.defaultDownPayments || 0) + "元");
                    vm.data.set('carMonthPrice', (res.data.defaultMonthPayments || 0) + "元");
                    vm.data.set('carWeekPrice', (res.data.defaultPeriods || 0) + "期");
                    vm.data.set('carDescription', res.data.carDescription || "无");
                    vm.data.set('supplierName', res.data.supplierName || "无");
                    vm.data.set('firstOnCard', res.data.firstOnCard || "无");
                    vm.data.set('kilometers', (res.data.kilometers || 0) + "万公里");
                    vm.data.set('upDate', res.data.upDate || "无");
                    discountData.attr('data-id',res.data.id);
                    discountData.attr('data-url',res.data.defaultAttachUrl);
                    discountData.attr('data-name',res.data.modelName);
                    discountData.attr('data-type',res.data.supplierName);

                    // 获取基本配置
                    var carPicData = res.data.attachInfoList,
                        bugCarPlan = res.data.carFinancialProductInfoList;

                    //banner 轮播
                    var bannerTmpl = doT.template($('#detailBannerTemple').text());
                    $('.js-banner-list').html('').append(bannerTmpl(res.data.attachInfoList));
                    var bannerSwiper = new Swiper('.js-banner',{loop:false});

                    //车辆详怕
                    var carPicDataTmpl = doT.template($('#carPicDataTemple').text());
                    $('.js-pat-detail').append(carPicDataTmpl(carPicData));

                    //购买方案
                    var bugCarPlanTmpl = doT.template($('#bugCarPlanTemple').text());
                    $('.js-car-buy-detail').append(bugCarPlanTmpl(bugCarPlan));
                },
                error:function(e){
                    common.toast(e.message);
                }
            });
        }
    };

    dao.getCarData();

    fly.bind(document.body, vm);
});