/**
 * @author: xiaomei
 * @date: 2018.11.13
 * @description 登录
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'dialog'
], function (doT,flyMobile,dialog){
    var phoneNum=$('.js-phone'),
        phoneCode=$('.js-phone-code'),
        getCode=$('.js-get-code'),
        countCode=$('.js-count-code'),
        countNum=120;

    var vm = window.vm = fly({
        data:{},
        event:{},
        page:{
            //倒计时
            countDown:function(){
                if (countNum == 0) {
                    getCode.removeClass("hide");
                    countCode.addClass("hide");
                    countNum = 120;
                }else{
                    getCode.addClass("hide");
                    countCode.removeClass('hide').html("重新发送(" + countNum + ")s");
                    countNum--;
                    setTimeout(function(){
                        vm.page.countDown();
                    },1000)
                }
            },

            //发送验证码
            sendPhoneCode:function(){
                var userPhoneCont=phoneNum.val(),
                    myReg=/^(13[0-9]|14[5-9]|15[012356789]|166|17[0-8]|18[0-9]|19[8-9])[0-9]{8}$/;
                if(!$.trim(userPhoneCont)){
                    layer.msg('请输入手机号码');
                }else if (!myReg.test(userPhoneCont)) {
                    layer.msg('请输入正确的手机号码');
                }else{
                    var params={
                        "param":{
                            "mobileNo":userPhoneCont,
                            "deviceId":"f7887fdsgwef8w4848"
                        }
                    };
                    $.ajax({
                        headers:{'Authorization':tokenValue},
                        type:'post',
                        url:serverApiUrl+'auth/jwt/sendVerifyCode',
                        async:false,
                        contentType:'application/json',
                        data:JSON.stringify(params),
                        dataType:"json",
                        success:function(res){
                            layer.msg('发送短信成功');
                            $('.js-btn').attr('data-type',res.data);
                            vm.page.countDown();
                        },
                        error:function(e){
                            layer.msg('发送短信失败');
                        }
                    });
                }
            },

            //登录
            loginApp:function(){
                var userPhoneCont=phoneNum.val(),
                    phoneCodeCont=phoneCode.val(),
                    codeVal=$('.js-btn').attr('data-type'),
                    myReg=/^(13[0-9]|14[5-9]|15[012356789]|166|17[0-8]|18[0-9]|19[8-9])[0-9]{8}$/;

                var params={
                    "param": {
                        "captcha":codeVal,
                        "loginCode":userPhoneCont
                    }
                };

                if(!$.trim(userPhoneCont)){
                    layer.msg('请输入手机号码');
                }else if (!myReg.test(userPhoneCont)) {
                    layer.msg('请输入正确的手机号码');
                }else if(!phoneCode.hasClass('hide')){
                    if(!$.trim(phoneCodeCont)){
                        layer.msg('请输入验证码');
                    }else if(phoneCodeCont != codeVal){
                        layer.msg('验证码输入不正确');
                    }else{
                        $.ajax({
                            type:'post',
                            url:serverApiUrl+'auth/jwt/login',
                            async:false,
                            contentType:'application/json',
                            data:JSON.stringify(params),
                            dataType:"json",
                            success:function(res){
                                layer.msg('登录成功');
                            },
                            error:function(e){
                                layer.msg('登录失败');
                            }
                        });
                    }
                }else{
                    $.ajax({
                        type:'post',
                        url:serverApiUrl+'auth/jwt/login',
                        async:false,
                        contentType:'application/json',
                        data:JSON.stringify(params),
                        dataType:"json",
                        success:function(res){
                            layer.msg('登录成功');
                        },
                        error:function(e){
                            layer.msg('登录失败');
                        }
                    });
                }
            }
        }
    });

    fly.bind(document.body, vm);
});