/**
 * @author: xiaomei
 * @date: 2018.6.13
 * @description 我的订单
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'lazyLoad',
    'serverUrl',
    'jquery',
    'iscroll',
    'pullToRefresh'
], function (doT, flyMobile, jquery, common,lazyLoad, serverUrl, iscroll, pullToRefresh) {
    var pageSize = 10,
        currentPageNo = 1,
        upPermit = 0;

    var orderList=$('.js-order-list');

    // 筛选条件
    var params ={
           "pageNo":1,
           "pageSize":10
        };

    var vm = window.vm = fly({
        data: {},
        event: {
            pulltoDo: function() {
                //初始化上拉下拉操作
                refresher.init({
                    id: "wrapper",
                    pullDownAction: vm.event.reloadNew,
                    pullUpAction: vm.event.loadMore
                });
            },
            loadMore: function() {
                if (upPermit === 0) {
                    //上拉加载
                    currentPageNo++;
                    params.pageNo = currentPageNo;
                    $.ajax({
                        headers: {'Authorization':tokenValue},
                        type:'post',
                        url:serverApiUrl+'order/api/order/list',
                        async:false,
                        contentType:'application/json',
                        data:JSON.stringify(params),
                        dataType:"json",
                        success:function(res){
                            if(res.data.rows.length>0){
                                var requestTmpl = doT.template($('#collectListTemple').text());
                                orderList.append(requestTmpl(res.data.rows));
                                if (res.data.rows.length < pageSize) {
                                    upPermit=1;
                                    refresher.onResherCompeted();
                                }
                                wrapper.refresh();
                            } else {
                                refresher.onResherCompeted();
                                wrapper.refresh();
                            }
                        },
                        error:function(e){
                            vm.page.errorData(e);
                        }
                    });
                }else{
                    refresher.onResherCompeted();
                    wrapper.refresh();
                }
            },
            reloadNew: function() {
                //下拉刷新
                currentPageNo = 1;
                params.pageNo = currentPageNo;
                upPermit = 0;
                $.ajax({
                    headers: {'Authorization':tokenValue},
                    type:'post',
                    url:serverApiUrl+'order/api/order/list',
                    async:false,
                    contentType:'application/json',
                    data:JSON.stringify(params),
                    dataType:"json",
                    success:function(res){
                        if(res.data.rows.length>0){
                            var requestTmpl = doT.template($('#collectListTemple').text());
                            orderList.html('').append(requestTmpl(res.data.rows));
                            if(res.data.rows.length < pageSize) {
                                refresher.onResherCompeted();
                                upPermit = 1;
                            }
                            wrapper.refresh();
                        }else {
                            $('.js-empty').show();
                            refresher.onEmptyCompeted();
                            wrapper.refresh();
                            $('.pullUpLabel').text('');
                        }
                    },
                    error:function(e){
                        vm.page.errorData(e);
                    }
                });
            }
        },
        page: {
            // 订单详情
            orderDetail:function(e){
                var params={"userId":$(e.currentTarget).attr('data-id')};
                window.location.href=localhostUrl+"orderListDetail/orderListDetail.html";
            },

            //错误信息
            errorData:function(e){
                $('.js-error').show().find('p').text(e.message);
                refresher.onErrorCompeted();
                $('.pullUpLabel').text('');
                vm.event.pulltoDo();
            }
        }
    });
    var dao = {
        //我的订单列表
        getTotalCar: function(){
           common.showToast();
            $.ajax({
                headers: {'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'order/api/order/list',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(res){
                    common.hideToast();
                    if(res.data.rows.length>0){
                        var requestTmpl = doT.template($('#collectListTemple').text());
                        orderList.append(requestTmpl(res.data.rows));
                        if (res.data.rows.length < pageSize) {
                            refresher.onResherCompeted();
                            upPermit = 1;
                        } else {
                            refresher.onInitCompeted();
                        }
                        vm.event.pulltoDo();
                    }else{
                        $('.js-empty').show();
                        refresher.onEmptyCompeted();
                        $('.pullUpLabel').text('');
                    }
                },
                error:function(e){
                    common.hideToast();
                    vm.page.errorData(e);
                }
            });
        }
    };

    dao.getTotalCar();
    orderList.on('click','li dd .js-order-detail',vm.page.orderDetail);

    fly.bind(document.body, vm);
});