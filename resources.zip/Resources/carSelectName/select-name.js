/**
 * @author: xiaomei
 * @date: 2018.8.20
 * @description 选择车辆名称
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll'
], function (doT, flyMobile, jquery, common,iscroll) {

    var selectAllCar=$('.js-all-car'),
        carSystem=$('.js-car-system'),
        carSystemDetail=$('.js-system-car'),
        carType=$('.js-car-type'),
        bgColor=$('.js-rank-bg'),
        bgColor1=$('.js-rank-bg1');

    var vm = window.vm = fly({
        data:{},
        event:{},
        page:{
            //选择车系
            jumpCarName:function(e){
                var params={"param":$(e.currentTarget).attr('data-id')};
                $(e.currentTarget).addClass('active').siblings('li').removeClass('active');
                $(e.currentTarget).parent().siblings().find('li').removeClass('active');
                carSystem.addClass('p-show');
                $('body').addClass('no-scroll');
                bgColor.show();
                $.ajax({
                    headers: {'Authorization':tokenValue},
                    type:'post',
                    url:serverApiUrl+'car/api/series/list',
                    async:false,
                    contentType:'application/json',
                    data:JSON.stringify(params),
                    dataType:"json",
                    success:function(res){
                        var requestTmpl = doT.template($('#carSystemTemple').text());
                        carSystemDetail.html('').append(requestTmpl(res.data));
                    },
                    error:function(e){
                        common.toast(e.message);
                    }
                });
            },

            //选择车型
            jumpCarType:function(e){
                var params={"param":$(e.currentTarget).attr('data-id')};
                $(e.currentTarget).addClass('active').siblings('li').removeClass('active');
                carType.addClass('p-show');
                carSystem.addClass('no-scroll');
                bgColor1.show();
                $.ajax({
                    headers: {'Authorization':tokenValue},
                    type:'post',
                    url:serverApiUrl+'car/api/model/listByYear',
                    async:false,
                    contentType:'application/json',
                    data:JSON.stringify(params),
                    dataType:"json",
                    success:function(res){
                        var requestTmpl = doT.template($('#carTypeTemple').text());
                        carType.html('').append(requestTmpl(res.data));
                    },
                    error:function(e){
                        common.toast(e.message);
                    }
                });
            },

            //关闭车型
            closeCarType:function(){
                bgColor1.hide();
                carType.removeClass('p-show');
                carSystem.removeClass('no-scroll');
            },

            //关闭车系
            closeCarSystem:function(){
                carSystem.removeClass('p-show');
                $('body').removeClass('no-scroll');
                bgColor.hide();
            },

            //确认车型
            jumpSureCarType:function(e){
                var params={"param":$(e.currentTarget).attr('data-name')};
                $(e.currentTarget).addClass("active");
                window.location.href=localhostUrl+"carAddSource/carAddSource.html";
            }
        }
    });
    var dao = {
        getCarName:function(){
            common.showToast();
            $.ajax({
                headers: {'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'car/api/brand/listByLetter',
                async:false,
                dataType:"json",
                success:function(res){
                    common.hideToast();
                    var requestTmpl = doT.template($('#selectCarTemple').text());
                    selectAllCar.append(requestTmpl(res.data));
                },
                error:function(e){
                    common.toast(e.message);
                }
            });

        }
    };
    var addEvent = function(){
        selectAllCar.on('click','.js-all-item',vm.page.jumpCarName);
        carSystemDetail.on('click','li.js-system',vm.page.jumpCarType);
        carType.on('click','.js-type-item',vm.page.jumpSureCarType);
    };

    dao.getCarName();
    addEvent();

    fly.bind(document.body, vm);
});
