/**
 * @author: xiaomei
 * @date: 2018.6.26
 * @description 车主服务
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'serverUrl',
    'jquery'
], function (doT, flyMobile, jquery,serverUrl) {

    var vm = window.vm = fly({
        data: {
            newCarList:[]
        }
    });
    var dao = {
        /**
         * [车辆列表 ]
         */
        getTotalCar: function(type){
           common.showToast();
            flyMobile.data({
                source: 'carTrail',
                action: 'carlist',
                actionType: '4',
                path: 'car/api/source/list',
                args: params,
                callback: true
            }).done(function (res) {
                common.hideToast();
                res = JSON.parse(res);
                if (res != undefined && res.statusCode == 200 && !(res.data === null)) {
                    if(res.data.rows.length) {
                        var requestTmpl = doT.template($('#collectListTemple').text());
                        $('.collect-list').append(requestTmpl(res.data.rows));
                    }else {
                        $('.empty').show();
                    }
                } else {
                    $('.error').show();
                }
            });
        }
    };
    var init = function () {
        dao.getTotalCar();
    };
    init();
    fly.bind(document.body, vm);
});