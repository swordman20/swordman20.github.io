/**
 * @author: xiaomei
 * @date: 2018.7.24
 * @description 历史账单
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'serverUrl',
    'jquery'
], function (doT,flyMobile, jquery,common,serverUrl) {

    var vm = window.vm = fly({
        data:{
            remainingAmount:'',
            totalAmount:'',
            returnedAmount:''
        }
    });
    var dao = {
        //历史账单
        getTotalCarInfo: function(){
           common.showToast();
            $.ajax({
                headers: {'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'crm/api/reserve/findMyRefundplan',
                async:false,
                dataType:"json",
                success:function(res){
                    common.hideToast();
                    vm.data.set('remainingAmount', ("￥" + res.data.remainingAmount) || "0" );
                    vm.data.set('totalAmount', ("￥" + res.data.totalAmount) || "0" );
                    vm.data.set('returnedAmount', ("￥" + res.data.returnedAmount) || "0" );

                    var configData = res.data.planList;
                    var configDataTmpl = doT.template($('#basicParameterTemple').text());
                    $('.js-historical-bill').append(configDataTmpl(configData));
                },
                error:function(e){
                    common.hideToast();
                    common.toast(e.message);
                }
            });
        }
    };

    dao.getTotalCarInfo();

    fly.bind(document.body, vm);
});