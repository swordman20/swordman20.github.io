/**
 * @author: xiaomei
 * @date: 2018.6.21
 * @description 首页
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll'
], function (doT, flyMobile, jquery, common,iscroll){

    var headerCont=$('.js-header'),userLogin=false;

    //判断用户是否登录
    flyMobile.data({
        source:'',
        action:'',
        actionType:'7',
        path:'',
        callback:true
    }).done(function(obj){
        //判断是否登录
        var judgeLogin=obj.token;
        if(typeof judgeLogin == "undefined" || judgeLogin == null || judgeLogin == ""){
            userLogin=false;
        }else{
            userLogin=true;
        }
    });

    //头部滚动
    $(window).scroll(function(){
        var scroll_top=$(window).scrollTop();
        if(scroll_top>=100){
            headerCont.addClass('header-bg');
        }else{
            headerCont.removeClass('header-bg');
        }
    });

    // 获取轮播图
    function getAdvertising(res){
        debugger;
        res = JSON.parse(res);
        if (res.statusCode == 200) {
            var requestTmpl = doT.template($('#homeBannerTemple').text());
            $('.js-banner-list').html('').append(requestTmpl(res.data));
            var bannerSwiper = new Swiper('.js-banner',{
                loop:true,
                autoplay:5000,
                speed:80
            });
            //禁止播放
            if (res.data.length < 2) {
                bannerSwiper.autoplay=false;
            }
        }
    };

    //好车一周精选
    window.getJinpinData=function(res){
        res = JSON.parse(res);
        var requestTmpl = doT.template($('#newCarTemple').text()),
            resData=res.data.rows;
        if (res.statusCode == 200){
            $('.js-week-list').html('').append(requestTmpl(resData.slice(0,4)));
        }
    };

    //热销新车
    //window.getHotData = function(res){};

    //品质二手车
    window.getQualityData = function(res){
        res = JSON.parse(res);
        var requestTmpl = doT.template($('#newCarTemple').text()),
            resJson= res.data.rows;
        if (res.statusCode == 200){
            $('.js-second-car').html('').append(requestTmpl(resJson.slice(0,4)));
        }
    };

    //好车问答
    window.getFindProblemsData = function(res){
        var requestTmpl = doT.template($('#questionTemple').text());
        if (res.statusCode == 200){
            $('.js-question-list').html('').append(requestTmpl(res.data));
        }
    };

    //获取城市
    window.getCityName=function(obj){
        if(typeof obj == "undefined" || obj == null || obj == ""){
            $('.js-header-address').html('定位失败')
        }else{
            $('.js-header-address').html(obj);
        }
    };

    var vm = window.vm = fly({
        data:{},
        event:{},
        page: {
            //搜索
            jumpIndexSearch:function(){
                var params={"searchCarType":0};
                flyMobile.data({
                    source: 'indexSearch',
                    action: 'indexSearch',
                    actionType: '1',
                    args:params,
                    callback:false
                });
            },

            //新车团购
            jumpNewCarList: function (e) {
                flyMobile.data({
                    source: 'appIndex',
                    action: 'jumpNewCarList',
                    actionType: '3',
                    callback:false
                });
            },

            //新车筛选
            jumpParameterNewList:function(e){
                var typeCont = $(e.currentTarget).data('type'),
                    sortCont=$(e.currentTarget).data('order');
                var params={
                    "typeCont":typeCont,
                    "orderDir":sortCont
                };
                flyMobile.data({
                    source:'appIndex',
                    action:'jumpNewCarList',
                    args:params,
                    actionType:'3',
                    callback:false
                });
            },

            // 优选二手车
            jumpSecondCarList: function (e) {
                flyMobile.data({
                    source: 'appIndex',
                    action: 'jumpSecondCarList',
                    actionType: '3',
                    callback:false
                });
            },

            //车主服务
            jumpCarService: function(e){
                if(userLogin==false){
                    flyMobile.data({
                        source: 'myIndex',
                        action: 'jumpLogin',
                        actionType: '3',
                        callback: false
                    });
                }else{
                    flyMobile.data({
                        source: 'myStages',
                        action: 'myStages',
                        actionType: '1',
                        callback: false
                    });
                }
            },

            // 领劵中心
            jumpVoucherCenter: function(e){
                flyMobile.data({
                    source: 'voucherCenter',
                    action: 'voucherCenter',
                    actionType: '1',
                    callback: false
                });
            },

            // 帮助与支持
            jumpQuestionList: function(e){
                flyMobile.data({
                    source:'helpSupport',
                    action:'helpSupport',
                    actionType:'1',
                    callback:false
                });
            },

            // 二手车、新车详情页
            jumpCarSecondDetail:function(e){
                var params={"userId":$(e.currentTarget).attr('data-id')},
                    typeDetail=$(e.currentTarget).attr('data-type');
                if(typeDetail=="二手车"){
                    flyMobile.data({
                        source: 'secondCarListDetail',
                        action: 'secondCarListDetail',
                        actionType: '1',
                        args:params,
                        callback: false
                    });
                }else{
                    flyMobile.data({
                        source: 'newCarListDetail',
                        action: 'newCarListDetail',
                        actionType: '1',
                        args:params,
                        callback: false
                    });
                }
            },

            // 选择城市
            jumpAreaSelect: function(){
                flyMobile.data({
                    source:'appIndex',
                    action:'citySelect',
                    actionType:'3',
                    callback:false
                });
            },

            // 跳转到车辆搜索页面
            jumpCarSearch: function(e){
                flyMobile.data({
                    source: 'carSearch',
                    action: 'carSearch',
                    actionType: '1',
                    callback: false
                });
            },

            //好车问答效果
            goodCarQuestion:function(){
                var _this = $(this);
                if(_this.find('span').hasClass('cur')){
                    $(_this.siblings('p')).slideUp();
                    $(_this.find('span')).removeClass('cur');
                }else{
                    $(_this.siblings('p')).slideDown();
                    $(_this.find('span')).addClass('cur');
                    _this.parent().siblings().find('p').slideUp();
                    _this.parent().siblings().find('span').removeClass('cur');
                }
            }
        }
    });

    $('.js-question-list').on('click','li .js-question',vm.page.goodCarQuestion);
    $('.js-second-car,.js-week-list').on('click','li',vm.page.jumpCarSecondDetail);

    fly.bind(document.body, vm);
});
