/**
 * @author: xiaomei
 * @date: 2018.6.7
 * @description 预约记录
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'lazyLoad',
    'zepto',
    'iscroll',
    'pullToRefresh'
], function (doT, flyMobile, zepto, common,lazyLoad,iscroll, pullToRefresh) {
    var pageSize = 10,
        currentPageNo = 1,
        upPermit = 0,
        collectDataList=$('.js-collect-list');

    // 筛选条件
    var params={
        "pageNo":1,
        "pageSize":10,
        "orderBy":"crt_time",
        "orderDir":"desc"
    };


    var vm = window.vm = fly({
        data:{},
        event: {
            pulltoDo: function() {
                //初始化上拉下拉操作
                refresher.init({
                    id: "wrapper",
                    pullDownAction: vm.event.reloadNew,
                    pullUpAction: vm.event.loadMore
                });
            },
            loadMore: function() {
                if (upPermit === 0) {
                    //上拉加载
                    currentPageNo++;
                    params.pageNo = currentPageNo;
                    flyMobile.data({
                        source:'appointRecord',
                        action:'',
                        actionType:'4',
                        path:'crm/api/reserve/list',
                        args:params,
                        callback:true
                    }).done(function (res) {
                        if (res.statusCode == 200) {
                            if(res.data.rows.length>0){
                                var requestTmpl = doT.template($('#collectListTemple').text());
                                collectDataList.append(requestTmpl(res.data.rows));

                                vm.page.itemDetail();

                                if (res.data.rows.length < pageSize) {
                                    upPermit = 1;
                                    refresher.onResherCompeted();
                                }
                                wrapper.refresh();
                            } else {
                                refresher.onResherCompeted();
                                wrapper.refresh();
                            }
                        }else{
                            vm.page.errorPrompt(res);
                        }
                    });
                }else{
                    refresher.onResherCompeted();
                    wrapper.refresh();
                }
            },

            reloadNew: function() {
                //下拉刷新
                currentPageNo = 1;
                params.pageNo = currentPageNo;
                upPermit = 0;
                flyMobile.data({
                    source: 'appointRecord',
                    action: '',
                    actionType: '4',
                    path: 'crm/api/reserve/list',
                    args:params,
                    callback:true
                }).done(function (res) {
                    if (res.statusCode == 200) {
                        if(res.data.rows.length>0){
                            var requestTmpl = doT.template($('#collectListTemple').text());
                            collectDataList.html('').append(requestTmpl(res.data.rows));

                            //移动删除
                            vm.page.itemDetail();

                            if(res.data.rows.length < pageSize) {
                                refresher.onResherCompeted();
                                upPermit = 1;
                            }
                            wrapper.refresh();
                        }else {
                            $('.js-empty').show();
                            refresher.onEmptyCompeted();
                            wrapper.refresh();
                            $('.pullUpLabel').text('');
                        }
                    }else{
                        vm.page.errorPrompt(res);
                    }
                });
            }
        },
        page: {
            //详情页
            jumpCarDetail:function(e){
                var _this=$(e.currentTarget),
                    params={"userId":_this.attr('data-id')},
                    itemType=_this.attr('data-type');
                if(itemType=="二手车"){
                    flyMobile.data({
                        source: 'secondCarListDetail',
                        action: 'secondCarListDetail',
                        actionType: '1',
                        args:params,
                        callback: false
                    });
                }else{
                    flyMobile.data({
                        source: 'newCarListDetail',
                        action: 'newCarListDetail',
                        actionType: '1',
                        args:params,
                        callback: false
                    });
                }
            },

            //电话
            jumpCall: function(e){
                var params={"phone":$(e.currentTarget).attr('data-type')};
                flyMobile.data({
                    source:'appointRecord',
                    action:'call',
                    args:params,
                    actionType:'3',
                    callback:false
                });
            },

            //删除
            itemDetail:function(){
                //移动删除
                window.slideUtil = (function($) {
                    var listItem = $('.sl-content'),
                        listOpts = $('.sl-opts');
                    var onthel = false, // 是否处于最左端
                        isScroll = false, // 列表是否滚动状态
                        initX = 0, // 初始X坐标
                        initY = 0, // 初始Y坐标
                        endX = 0, // 结束时X坐标
                        endY = 0, // 结束时Y坐标
                        moveX = 0, // listItem 移动的距离
                        expandLi = null; // 是否存在展开的list
                    var slideMaxWid = listOpts.width();
                    var handleSlide = (function() {
                        listItem.on('touchstart',function(e){
                            // 判断有无已经展开的li，如果有，是否是当前的li，如果不是，将展开的li收起
                            if( expandLi ){
                                if( expandLi.parent().index()!==$(this).parent().index() ){
                                    // 判断当前list是左滑还是上下滑
                                    if( Math.abs(endY-initY) < Math.abs(endX-initX) ){
                                        e.preventDefault();
                                    }
                                    expandLi.css('-webkit-transform','translateX('+0+'px)');
                                }
                            }

                            initX = e.targetTouches[0].pageX;
                            initY = e.targetTouches[0].pageY;

                            moveX = $(this).offset().left;

                            $(this).on('touchmove',function(e){

                                var curY = e.targetTouches[0].pageY;
                                var curX = e.targetTouches[0].pageX;
                                var X = curX - initX; // 不断获取移动的距离
                                $(this).removeClass('animated');
                                if( Math.abs(endY-initY)<Math.abs(endX-initX) ){
                                    e.preventDefault();
                                    if( moveX==0 ){
                                        if( X>0 ) {
                                            $(this).css('-webkit-transform','translateX('+0+'px)');
                                        }else if( X<0 ){
                                            if( X<-slideMaxWid ) X=-slideMaxWid;
                                            $(this).css('-webkit-transform','translateX('+X+'px)');
                                        }
                                    }
                                    // 已经处于最左
                                    else if( moveX < 0 ){
                                        onthel = true;
                                        if( X>0 ) { // 向右滑
                                            if( X-slideMaxWid>0 ){
                                                $(this).css('-webkit-transform','translateX('+0+'px)');
                                            }else{
                                                $(this).css('-webkit-transform','translateX('+(X-slideMaxWid)+'px)');
                                            }
                                        }else { // 左滑
                                            $(this).addClass('animated');
                                            $(this).css('-webkit-transform','translateX('+0+'px)');
                                        }
                                    }
                                }else{
                                    isScroll = true;
                                }
                            })
                        });
                        listItem.on('touchend',function(e){
                            endX = e.changedTouches[0].pageX;
                            endY = e.changedTouches[0].pageY;
                            var X = endX - initX;
                            $(this).addClass('animated');
                            if( X>-20||onthel||isScroll ){
                                $(this).css('-webkit-transform','translateX('+0+'px)');
                                onthel = false;
                                isScroll = false;
                            }else{
                                $(this).css('-webkit-transform','translateX('+(-slideMaxWid)+'px)');
                                expandLi = $(this);
                            }
                        })
                    })();
                })(Zepto);
            },

            //错误提示
            errorPrompt:function(e){
                $('.js-error').show().find('p').text(e.message);
                refresher.onErrorCompeted();
                $('.pullUpLabel').text('');
                vm.event.pulltoDo();
            },

            //删除列表
            collectCarDetail:function(e){
                var params={
                    "param": {
                        "carSourceId":$(this).attr('data-id'),
                        "favAct":0
                    }
                };
                flyMobile.data({
                    source:'browseHistory',
                    action:'',
                    actionType: '4',
                    path:'crm/api/user/fav',
                    args:params,
                    callback:true
                }).done(function(res){
                    if (res.statusCode == 200){
                        $(e.currentTarget).parent("li").remove();
                    }else{
                        common.toast(res.message);
                    }
                });
            }
        }
    });
    var dao = {
        //预约列表
        getTotalCar: function(){
            common.showToast();
            flyMobile.data({
                source:'appointRecord',
                action:'',
                actionType:'4',
                path:'crm/api/reserve/list',
                args:params,
                callback:true
            }).done(function (res){
                common.hideToast();
         
                if (res.statusCode == 200){
                    if(res.data.rows.length>0){
                        var requestTmpl = doT.template($('#collectListTemple').text());
                        collectDataList.append(requestTmpl(res.data.rows));

                        //移动删除
                        vm.page.itemDetail();

                        if (res.data.rows.length < pageSize) {
                            refresher.onResherCompeted();
                            upPermit = 1;
                        } else {
                            refresher.onInitCompeted();
                        }
                        vm.event.pulltoDo();
                    }else {
                        $('.js-empty').show();
                        refresher.onEmptyCompeted();
                        $('.pullUpLabel').text('');
                    }
                } else {
                    vm.page.errorPrompt(res);
                }
            });
        }
    };

    collectDataList.on('click', 'li .js-car-detail', vm.page.jumpCarDetail);
    collectDataList.on('click', 'li .js-item', vm.page.jumpCall);
    // collectDataList.on('click', 'li .js-del',vm.page.collectCarDetail);
    dao.getTotalCar();

    fly.bind(document.body, vm);
});
