/**
 * @author: xiaomei
 * @date: 2018.6.7
 * @description 预约管理详情页
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'serverUrl',
    'dialog'
], function (doT,flyMobile,dialog,serverUrl){
    var params={'param':158};

    var appointId=$('.js-appoint-id'),
        operateDetail=$('.js-o-set'),
        operateBg=$('.js-rank-bg'),
        selectModel=true;

    var vm = window.vm = fly({
        data: {
            modelName:"",
            vin:"",
            supplierName:"",
            sellPrice:"",
            kilometers:"",
            name:"",
            sourceName:"",
            color:"",
            phone:"",
            firstOnCard:""
        },
        event: {},
        page: {
            //弹框
            confirm:function(str,setting){
                var parameters = {
                    type 	: setting.type,
                    title	: false,
                    content : str,
                    skin	: setting.cls,
                    id		: setting.id,
                    time    : setting.time,
                    move 	: setting.move,
                    shadeClose 	: setting.shadeClose,
                    closeBtn 	: setting.closeBtn,
                    btn 	: setting.btn,
                    success : setting.onLoad,
                    yes     : setting.onSure,
                    cancel  : setting.onCancel
                };
                var defaults = {
                    type 	: 0,
                    title	: '',
                    content : str || '我是提醒框',
                    skin	: '',
                    id		: '',
                    move 	: false,
                    shadeClose 	: false,
                    closeBtn 	: 0,
                    yes 	: function(index, layero){},
                    cancel 	: function(index, layero){},
                    btn2 	: function(index, layero){}
                };
                $.extend(defaults,parameters);
                layer.confirm(str,defaults);
            },

            //操作设置
            carOperate:function(){
                operateDetail.addClass('show-operate');
                operateBg.show();
            },

            //关闭操作
            closeOperate:function(e){
                $(e.currentTarget).parent().removeClass('show-operate');
                operateBg.hide();
            },

            //照片上传
            jumpImages: function () {
                $('.js-i-info').addClass('p-show');
            },

            //基本信息
            jumpCarInfo: function () {
                $('.js-b-info').addClass('p-show');
            },

            //手续信息
            jumpCarPro:function(){
                $('.js-p-info').addClass('p-show');
            },

            //车辆描述
            jumpCarDes:function(){
                $('.js-d-info').addClass('p-show');
            },

            //返回
            goBack:function(e){
                $(e.currentTarget).parent().removeClass('p-show');
            },

            // 点击预约退回按钮
            clickCancel:function(){
                vm.page.confirm('<h4 class="sure-bomb-cont">确认退回？</h4>',{
                    btn:['是','否'],
                    cls:'sure-bomb',
                    onSure:function(){
                        var returnReason='<div class="return-reason"><h4 class="sure-bomb-title">退回原因</h4>' +
                            '<textarea placeholder="请输入" class="return-cont js-return"></textarea>' +
                            '<span class="reason-null js-reason-null"></span></div>';
                        vm.page.confirm(returnReason,{
                            btn:['提交','取消'],
                            cls:'sure-bomb sure-reason',
                            onSure:function(){
                              var reasonCont=$('.js-return').val();
                              if(!$.trim(reasonCont)){
                                    $('.js-reason-null').text('请填写退回原因')
                              }else{
                                  var params={
                                      "param":{
                                          "remark": reasonCont,
                                          "reserveId":$.parseJSON(appointId.attr('data-id')),
                                          "status":2
                                      }
                                  };
                                  $.ajax({
                                      headers:{'Authorization':tokenValue},
                                      type:'post',
                                      url:serverApiUrl+'crm/api/reserve/updateReserveSale',
                                      async:false,
                                      contentType:'application/json',
                                      data:JSON.stringify(params),
                                      dataType:"json",
                                      success:function(res){
                                          operateDetail.removeClass('show-operate');
                                          operateBg.hide();
                                          layer.msg('预约已退回客服中心');
                                      },
                                      error:function(e){
                                          debugger;
                                          layer.msg(e.message);
                                      }
                                  });
                              }
                            }
                        })
                    }
                })
            },

            // 点击预约完成按钮
            clickComplete:function(){
                vm.page.confirm('<h4 class="sure-bomb-cont">预约完成？</h4>',{
                    btn:['是','否'],
                    cls:'sure-bomb',
                    onSure:function(){
                        var returnReason='<div class="return-reason"><h4 class="sure-bomb-title">添加备注</h4>' +
                            '<textarea placeholder="请输入" class="return-cont js-return"></textarea></div>';
                        vm.page.confirm(returnReason,{
                            btn:['提交','取消'],
                            cls:'sure-bomb sure-reason',
                            onSure:function(){
                                var params={
                                    "param":{
                                        "remark": $('.js-return').val(),
                                        "reserveId":$.parseJSON(appointId.attr('data-id')),
                                        "status":3
                                    }
                                };
                                $.ajax({
                                    headers:{'Authorization':tokenValue},
                                    type:'post',
                                    url:serverApiUrl+'crm/api/reserve/updateReserveSale',
                                    async:false,
                                    contentType:'application/json',
                                    data:JSON.stringify(params),
                                    dataType:"json",
                                    success:function(res){
                                        operateDetail.removeClass('show-operate');
                                        operateBg.hide();
                                        layer.msg('预约已返回客服中心',function(){
                                            window.location.href=localhostUrl+"carAddSource/carAddSource.html";
                                        });
                                    },
                                    error:function(e){
                                        layer.msg(e.message);
                                    }
                                });
                            }
                        })
                    }
                })
            },

            //车辆轨迹
            clickCarTrail:function(){
                var id=appointId.attr('data-id');
                window.location.href=localhostUrl+"carTrail/carTrail.html?userId="+id;
            }
        }
    });
    var dao = {
        //获取预约数据
        getCollectionData: function(){
            $.ajax({
                headers:{'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'crm/api/reserve/getReserveInfo',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(res){
                    vm.data.set('modelName', res.data.detail.modelName);
                    vm.data.set('vin', res.data.detail.vin);
                    vm.data.set('supplierName', res.data.detail.supplierName);
                    vm.data.set('sellPrice', '¥' + res.data.detail.sellPrice);
                    vm.data.set('kilometers', res.data.detail.kilometers);
                    vm.data.set('sourceName', res.data.detail.sourceName);
                    vm.data.set('firstOnCard', res.data.detail.firstOnCard);
                    vm.data.set('ownerDescription', res.data.detail.ownerDescription || "无");
                    vm.data.set('color', res.data.detail.color);
                    vm.data.set('name', res.data.reserve.name);
                    vm.data.set('phone', res.data.reserve.phone);
                    $('.js-car-phone').attr('data-type',res.data.reserve.phone);
                    appointId.attr('data-id',res.data.reserve.id);
                    appointId.attr('data-type',res.data.reserve.carSourceId);

                    //图片轮播
                    var bannerTmpl = doT.template($('#detailBannerTemple').text());
                    $('.js-banner-list').html('').append(bannerTmpl(res.data.detail.attachInfoList));
                    var bannerSwiper = new Swiper('.js-banner',{loop:false});

                    //照片
                    var imgTmpl=doT.template($('#detailImgTemple').text());
                    $('.js-img-detail').append(imgTmpl(res.data.detail.attachInfoList));

                    //手续信息
                    if(selectModel==true){
                        $('.js-no-data').removeClass('hide');
                        $('.js-info-detail').addClass('hide');
                        $('.js-new-kil').addClass('hide');
                    }else{
                        var requestTmpl = doT.template($('#formalitiesTemple').text());
                        $('.js-info-detail').append(requestTmpl(res.data.detail.formalitiesMap));
                    }
                },
                error:function(e){
                    layer.msg(e.message);
                }
            });
        }
    };

    dao.getCollectionData();
    fly.bind(document.body, vm);
});