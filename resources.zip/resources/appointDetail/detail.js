/**
 * @author: xiaomei
 * @date: 2018.6.7
 * @description 预约管理详情页
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'dialog'
], function (doT,flyMobile,dialog){
    var params={'param':''},
        selectModel=false,
        appointId=$('.js-appoint-id'),
        operateDetail=$('.js-o-set'),
        operateBg=$('.js-rank-bg');

    //获取参数
    window.getParams = function(res){
        params.param=res.userId;
        if(res.carType=="2"){
            selectModel=false;
        }else{
            selectModel=true
        }
        dao.getCollectionData();
    };

    var vm = window.vm = fly({
        data: {
            sourceName:"",
            vin:"",
            supplierName:"",
            sellPrice:"",
            kilometers:"",
            color:"",
            carDescription:"",
            name:"",
            phone:""
        },
        event:{},
        page:{
            //弹框
            confirm:function(str,setting){
                var parameters = {
                    type 	: setting.type,
                    title	: false,
                    content : str,
                    skin	: setting.cls,
                    id		: setting.id,
                    time    : setting.time,
                    move 	: setting.move,
                    shadeClose 	: setting.shadeClose,
                    closeBtn 	: setting.closeBtn,
                    btn 	: setting.btn,
                    success : setting.onLoad,
                    yes     : setting.onSure,
                    cancel  : setting.onCancel
                };
                var defaults = {
                    type 	: 0,
                    title	: '',
                    content : str || '我是提醒框',
                    skin	: '',
                    id		: '',
                    move 	: false,
                    shadeClose 	: false,
                    closeBtn 	: 0,
                    yes 	: function(index, layero){},
                    cancel 	: function(index, layero){},
                    btn2 	: function(index, layero){}
                };
                $.extend(defaults,parameters);
                layer.confirm(str,defaults);
            },

            //操作设置
            carOperate:function(){
                operateDetail.addClass('show-operate');
                operateBg.show();
            },

            //关闭操作
            closeOperate:function(e){
                $(e.currentTarget).parent().removeClass('show-operate');
                operateBg.hide();
            },

            //照片上传
            jumpImages: function () {
                $('.js-i-info').addClass('p-show');
            },

            //基本信息
            jumpCarInfo: function () {
                $('.js-b-info').addClass('p-show');
            },

            //手续信息
            jumpCarPro:function(){
                $('.js-p-info').addClass('p-show');
            },

            //车辆描述
            jumpCarDes:function(){
                $('.js-d-info').addClass('p-show');
            },

            //返回
            goBack:function(e){
                $(e.currentTarget).parent().removeClass('p-show');
            },

            // 点击预约退回按钮
            clickCancel:function(){
                vm.page.confirm('<h4 class="sure-bomb-cont">确认退回？</h4>',{
                    btn:['是','否'],
                    cls:'sure-bomb',
                    onSure:function(){
                        var returnReason='<div class="return-reason"><h4 class="sure-bomb-title">退回原因</h4>' +
                            '<textarea placeholder="请输入" class="return-cont js-return"></textarea>' +
                            '<span class="reason-null js-reason-null"></span></div>';
                        vm.page.confirm(returnReason,{
                            btn:['提交','取消'],
                            cls:'sure-bomb sure-reason',
                            onSure:function(){
                              var reasonCont=$('.js-return').val();
                              if(!$.trim(reasonCont)){
                                    $('.js-reason-null').text('退回原因不能为空');
                              }else{
                                  var params={
                                      "param":{
                                          "remark": reasonCont,
                                          "reserveId":$.parseJSON(appointId.attr('data-id')),
                                          "status":2
                                      }
                                  };
                                  flyMobile.data({
                                      source:'appointDetail',
                                      action:'',
                                      actionType:'4',
                                      path:'crm/api/reserve/updateReserveSale',
                                      args:params,
                                      callback:true
                                  }).done(function(res){
                                      if (res.statusCode == 200){
                                          operateDetail.removeClass('show-operate');
                                          operateBg.hide();
                                          var params={popType:2,jumpData:""};
                                          layer.msg('预约已退回客服中心',function(){
                                              flyMobile.data({
                                                  source:'appointAdmin',
                                                  action:'appointAdmin',
                                                  args:params,
                                                  actionType:'6',
                                                  callback:false
                                              });
                                          });
                                      }else{
                                          layer.msg(res.message);
                                      }
                                  });
                              }
                            }
                        })
                    }
                })
            },

            // 点击预约完成按钮
            clickComplete:function(){
                vm.page.confirm('<h4 class="sure-bomb-cont">预约完成？</h4>',{
                    btn:['是','否'],
                    cls:'sure-bomb',
                    onSure:function(){
                        var returnReason='<div class="return-reason"><h4 class="sure-bomb-title">添加备注</h4>' +
                            '<textarea placeholder="请输入" class="return-cont js-return"></textarea></div>';
                        vm.page.confirm(returnReason,{
                            btn:['提交','取消'],
                            cls:'sure-bomb sure-reason',
                            onSure:function(){
                                var params={
                                    "param":{
                                        "remark": $('.js-return').val(),
                                        "reserveId":$.parseJSON(appointId.attr('data-id')),
                                        "status":3
                                    }
                                };
                                flyMobile.data({
                                    source:'appointDetail',
                                    action:'',
                                    actionType:'4',
                                    path:'crm/api/reserve/updateReserveSale',
                                    args:params,
                                    callback:true
                                }).done(function(res){
                                    if (res.statusCode == 200){
                                        operateDetail.removeClass('show-operate');
                                        operateBg.hide();
                                        var params={popType:2,jumpData:""};
                                        layer.msg('预约已返回客服中心',function(){
                                            flyMobile.data({
                                                source:'appointAdmin',
                                                action:'appointAdmin',
                                                args:params,
                                                actionType:'6',
                                                callback:false
                                            });
                                        });
                                    }else{
                                        layer.msg(res.message);
                                    }
                                });
                            }
                        })
                    }
                })
            },

            //车辆轨迹
            clickCarTrail:function(){
                var params={"userId":appointId.attr('data-type')};
                flyMobile.data({
                    source:'carTrail',
                    action:'carTrail',
                    actionType:'1',
                    args:params,
                    callback:false
                });
            },

            //拨打电话
            callReserve:function(e){
                var params={"phone":$(e.currentTarget).attr('data-type')};
                flyMobile.data({
                    source:'appointDetail',
                    action:'call',
                    args:params,
                    actionType:'3',
                    callback: false
                });
            }
        }
    });

    var dao = {
        //获取预约数据
        getCollectionData: function(){
            flyMobile.data({
                source:'appointDetail',
                action:'',
                actionType:'4',
                path:'crm/api/reserve/getReserveInfo',
                args:params,
                callback:true
            }).done(function(res){
                if (res.statusCode == 200){
                    vm.data.set('modelName', res.data.detail.modelName);
                    vm.data.set('vin', res.data.detail.vin);
                    vm.data.set('supplierName', res.data.detail.supplierName);
                    vm.data.set('sellPrice', '¥' + res.data.detail.sellPrice);
                    vm.data.set('kilometers', res.data.detail.kilometers);
                    vm.data.set('sourceName', res.data.detail.sourceName);
                    vm.data.set('firstOnCard', res.data.detail.firstOnCard || "无");
                    vm.data.set('ownerDescription', res.data.detail.ownerDescription || "无");
                    vm.data.set('carDescription', res.data.detail.carDescription || "无");
                    vm.data.set('color', res.data.detail.color);
                    vm.data.set('name', res.data.reserve.name);
                    vm.data.set('phone', res.data.reserve.phone);
                    $('.js-car-phone').attr('data-type',res.data.reserve.phone);
                    appointId.attr('data-id',res.data.reserve.id);
                    appointId.attr('data-type',res.data.reserve.carSourceId);

                    //图片轮播
                    var bannerTmpl = doT.template($('#detailBannerTemple').text());
                    $('.js-banner-list').html('').append(bannerTmpl(res.data.detail.attachInfoList));
                    var bannerSwiper = new Swiper('.js-banner',{loop:false});

                    //照片
                    var imgTmpl=doT.template($('#detailImgTemple').text());
                    $('.js-img-detail').append(imgTmpl(res.data.detail.attachInfoList));

                    //手续信息
                    if(selectModel==true){
                        $('.js-no-data').removeClass('hide');
                        $('.js-info-detail').addClass('hide');
                        $('.js-new-kil').addClass('hide');
                        $('.js-new-car').removeClass('hide');
                        $('.js-old-car').addClass('hide');
                    }else{
                        var requestTmpl = doT.template($('#formalitiesTemple').text());
                        $('.js-info-detail').append(requestTmpl(res.data.detail.formalitiesMap));
                    }

                }else{
                    layer.msg(res.message);
                }
            }); 
        }
    };

    fly.bind(document.body, vm);
});