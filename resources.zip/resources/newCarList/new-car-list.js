/**
 * @author: xiaomei
 * @date: 2018.6.14
 * @description 新车首页
 */

var headerCityId=$('.js-header-address');

//获取城市
window.getCityName=function(res){
    headerCityId.html(res);
};

//获取城市id
window.getCityId=function(obj){
    if(typeof obj == "undefined" || obj == null || obj == ""){
        headerCityId.html('定位失败');
    }else{
        headerCityId.attr('data-id',obj);
    }
};

require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'lazyLoad',
    'jquery',
    'iscroll',
    'pullToRefresh'
], function (doT, flyMobile,jquery, common,lazyLoad,iscroll, pullToRefresh) {
    var pageSize = 10,
        currentPageNo = 1,
        upPermit = 0,
        clickCarBrand=0,
        userLogin=false;

    var newCarList=$('.js-new-list'),
        newHeaderNav=$('.js-car-nav'),

        newCarNavBg=$('.js-nav-bg'),
        newCarNavBg1=$('.js-nav-bg1'),
        newCarNavBg2=$('.js-nav-bg2'),
        carBrandBg=$('.js-nav-bg3'),
        carMoreScreen=$('.js-nav-bg4'),

        navSelectDetail=$('.js-nav-select-detail'),
        navMoreSelect=$('.js-screen'),
        carBrandCont=$('.js-car-brand'),

        firstCont=$('.js-choose-payment'),
        monthCont=$('.js-choose-supply'),
        defaultCont=$('.js-default-select'),

        selectTypeDetail=$('.js-select-type');

    // 筛选条件
    var params = {
        "orderBy": "",
        "orderDir": "",
        "pageNo": 1,
        "pageSize": 10,
        "param": {
            "carCategory":"1",
            "downPaymentsRates":"",
            "cityId":"",
            "brandId":"",
            "beginDownPayments":"",
            "endDownPayments":"",
            "beginMonthPayments":"",
            "endMonthPayments":"",
            "beginSellPrice":"",
            "endSellPrice":"",
            "sourceName":"",
            "levelNames":""
        }
    };

    //获取列表数据
    window.getNewCarListData=function(res){
        res = JSON.parse(res);
        if(res.statusCode == 200){
            if(res.data.rows.length>0) {
                var requestTmpl = doT.template($('#newCarTemple').text());
                newCarList.html('').append(requestTmpl(res.data.rows));
                if (res.data.rows.length < pageSize) {
                    refresher.onResherCompeted();
                    upPermit = 1;
                } else {
                    refresher.onInitCompeted();
                }
                vm.event.pulltoDo();
            }else {
                vm.page.emptyData();
            }
        }else {
            vm.page.errorCont(res.message);
        }
    };

    //判断用户是否登录
    flyMobile.data({
        source:'',
        action:'',
        actionType:'7',
        path:'',
        callback:true
    }).done(function(obj){
        //判断是否登录
        var judgeLogin=obj.token;
        if(typeof judgeLogin == "undefined" || judgeLogin == null || judgeLogin == ""){
            userLogin=false;
        }else{
            userLogin=true;
        }
    });

    var vm = window.vm = fly({
        data:{},
        event: {
            pulltoDo: function() {
                //初始化上拉下拉操作
                refresher.init({
                    id: "wrapper",
                    pullDownAction: vm.event.reloadNew,
                    pullUpAction: vm.event.loadMore
                });
            },
            loadMore: function() {
                if (upPermit === 0) {
                    //上拉加载
                    currentPageNo++;
                    params.pageNo = currentPageNo;
                    params.param.cityId=headerCityId.attr('data-id');
                    flyMobile.data({
                        source:'newCarList',
                        action:'',
                        actionType: '4',
                        path:'car/api/source/list',
                        args:params,
                        callback: true
                    }).done(function (res){
                        if (res.statusCode == 200){
                            if(res.data.rows.length>0){
                                var requestTmpl = doT.template($('#newCarTemple').text());
                                newCarList.append(requestTmpl(res.data.rows));

                                if (res.data.rows.length < pageSize) {
                                    upPermit = 1;
                                    refresher.onResherCompeted();
                                }
                                wrapper.refresh();
                            } else {
                                refresher.onResherCompeted();
                                wrapper.refresh();
                            }
                        }else{
                            vm.page.errorCont(res);
                        }
                    });
                }else{
                    refresher.onResherCompeted();
                    wrapper.refresh();
                }
            },
            reloadNew: function() {
                //下拉刷新
                currentPageNo = 1;
                params.pageNo = currentPageNo;
                params.param.cityId=headerCityId.attr('data-id');
                upPermit = 0;
                flyMobile.data({
                    source:'newCarList',
                    action:'',
                    actionType:'4',
                    path:'car/api/source/list',
                    args: params,
                    callback: true
                }).done(function (res) {
                    if (res.statusCode == 200){
                        if(res.data.rows.length>0){
                            var requestTmpl = doT.template($('#newCarTemple').text());
                            newCarList.html('').append(requestTmpl(res.data.rows));
                            if(res.data.rows.length < pageSize) {
                                refresher.onResherCompeted();
                                upPermit = 1;
                            }
                            wrapper.refresh();
                        }else{
                            vm.page.emptyData();
                        }
                    }else{
                        vm.page.errorCont(res);
                    }
                });
            }
        },
        page: {
            //搜索
            jumpIndexSearch:function(){
                var params={'searchCarType':1};
                flyMobile.data({
                    source: 'indexSearch',
                    action: 'indexSearch',
                    args:params,
                    actionType: '1',
                    callback:false
                });
            },

            // 新车情页
            secondCarDetail:function(e){
                var params={"userId":$(e.currentTarget).attr('data-id')};
                flyMobile.data({
                    source:'newCarListDetail',
                    action:'newCarListDetail',
                    actionType:'1',
                    args:params,
                    callback:false
                });
            },

            // 选择城市
            jumpAreaSelect: function(){
                flyMobile.data({
                    source:'newCarList',
                    action:'citySelect',
                    actionType:'3',
                    callback:false
                });
            },

            // 点击收藏按钮
            jumpCarCollect: function(e){
                var currentItem=$(this),
                    carSourceId = currentItem.data('id'),
                    params ={
                        "param":{
                            "carSourceId":carSourceId,
                            "favAct":1
                        }
                    };

                if(userLogin==false){
                    flyMobile.data({
                        source: 'myIndex',
                        action: 'jumpLogin',
                        actionType: '3',
                        callback: false
                    });
                }else{
                    if(currentItem.hasClass('active')){
                        params.param.favAct = 0
                    }else{
                        params.param.favAct = 1
                    }

                    flyMobile.data({
                        source:'newCarList',
                        action:'',
                        actionType:'4',
                        path:'crm/api/user/fav',
                        args:params,
                        callback: true
                    }).done(function (res) {
                        if(res.statusCode == 200){
                            if(params.param.favAct == 1){
                                currentItem.addClass('active');
                                common.toast("收藏" + res.message, '', '', '');
                            }else {
                                currentItem.removeClass('active');
                                common.toast("取消收藏成功", '', '', '');
                            }
                        }else {
                            common.toast("操作失败", '', '', '');
                        }
                    });
                }
            },

            // 头部导航
            clickScreen: function(e){
                var index = $(this).index();
                $(this).addClass('active').siblings().removeClass('active');
                switch(index){
                    case 0:
                        newCarNavBg.toggle();
                        defaultCont.slideToggle('slow');//默认排序
                        newCarNavBg1.hide();
                        firstCont.hide();//首付
                        newCarNavBg2.hide();
                        monthCont.hide();//月供
                        carBrandBg.hide();
                        carBrandCont.slideUp('slow');//品牌
                        carMoreScreen.hide();
                        navMoreSelect.removeClass('screen-show');//更多筛选
                        break;
                    case 1:
                        newCarNavBg.hide();
                        newCarNavBg1.hide();
                        newCarNavBg2.hide();
                        firstCont.hide();
                        monthCont.hide();
                        defaultCont.hide();
                        carBrandBg.toggle();
                        carBrandCont.slideToggle('slow');//品牌
                        carMoreScreen.hide();
                        navMoreSelect.removeClass('screen-show');//更多筛选
                        var params={"param":"1"};
                        if(clickCarBrand==0){
                            flyMobile.data({
                                source:'secondCarList',
                                action:'',
                                actionType:'4',
                                path:'car/api/brand/listByLetter',
                                args:params,
                                callback:true
                            }).done(function (res){
                                if(res.statusCode == 200){
                                    var requestTmpl = doT.template($('#selectCarBrandTemple').text());
                                    carBrandCont.html('').append(requestTmpl(res.data));
                                    clickCarBrand=1;
                                }else{
                                    common.toast(res.message);
                                }
                            });
                        }
                        break;
                    case 2:
                        newCarNavBg1.toggle();
                        firstCont.slideToggle('slow');//首付
                        newCarNavBg.hide();
                        defaultCont.hide();//默认排序
                        newCarNavBg2.hide();
                        monthCont.hide();//月供
                        carBrandBg.hide();
                        carBrandCont.slideUp('slow');//品牌
                        carMoreScreen.hide();
                        navMoreSelect.removeClass('screen-show');//更多筛选
                        break;
                    case 3:
                        newCarNavBg2.toggle();
                        monthCont.slideToggle('slow');//月供
                        newCarNavBg.hide();
                        defaultCont.hide();//默认排序
                        newCarNavBg1.hide();
                        firstCont.hide();//首付
                        carBrandBg.hide();
                        carBrandCont.slideUp('slow');//品牌
                        carMoreScreen.hide();
                        navMoreSelect.removeClass('screen-show');//更多筛选
                        break;
                    case 4:
                        newCarNavBg.hide();
                        newCarNavBg1.hide();
                        newCarNavBg2.hide();
                        firstCont.hide();
                        monthCont.hide();
                        defaultCont.hide();
                        carBrandBg.hide();
                        carBrandCont.slideUp('slow');//品牌
                        carMoreScreen.toggle();
                        navMoreSelect.toggleClass('screen-show');//更多筛选
                        break;
                }
            },

            //参数帅选
            screenParams:function(){
                params.pageNo=1;
                params.param.cityId=headerCityId.attr('data-id');
                flyMobile.data({
                    source:'newCarList',
                    action:'',
                    actionType:'4',
                    path:'car/api/source/list',
                    args: params,
                    callback: true
                }).done(function(res){
                    if (res.statusCode == 200){
                        if(res.data.rows.length>0){
                            var requestTmpl = doT.template($('#newCarTemple').text());
                            newCarList.html('').append(requestTmpl(res.data.rows));
                            $('.js-empty').hide();
                            if (res.data.rows.length < pageSize) {
                                refresher.onResherCompeted();
                                upPermit = 1;
                            } else {
                                refresher.onInitCompeted();
                            }
                            wrapper.refresh();
                        }else{
                            newCarList.empty();
                            vm.page.emptyData();
                        }
                    }else{
                        vm.page.errorCont(res);
                    }
                });
            },

            //确定默认排序
            selectDefaultSort:function(e){
                var _this=$(e.currentTarget);
                params.orderBy=_this.attr('data-type');
                params.orderDir=_this.attr('data-order');//默认排序
                params.param.brandId="";//品牌
                params.param.beginMonthPayments="";
                params.param.endMonthPayments="";//月供
                params.param.beginDownPayments="";
                params.param.endDownPayments="";//首付
                params.param.downPaymentsRates="";
                params.param.beginSellPrice="";
                params.param.endSellPrice="";
                params.param.levelNames="";//筛选
                _this.addClass('cur').siblings().removeClass('cur');
                newCarNavBg.hide();
                navSelectDetail.find('dl').eq(0).slideUp('slow');
                vm.page.screenParams();
            },

            //确定品牌
            clickSureBrand:function(e){
                var _this=$(e.currentTarget);
                params.orderBy="";
                params.orderDir="";//默认排序
                params.param.beginDownPayments="";
                params.param.endDownPayments="";//首付
                params.param.beginMonthPayments="";
                params.param.endMonthPayments="";//月供
                params.param.downPaymentsRates="";
                params.param.beginSellPrice="";
                params.param.endSellPrice="";
                params.param.levelNames="";//筛选
                params.param.brandId=_this.attr('data-id');//品牌
                carBrandBg.hide();
                carBrandCont.slideUp('slow');
                _this.addClass('cur').siblings().removeClass('cur');
                vm.page.screenParams();
            },

            //品牌不限
            sureBrandNoLimit:function(){
                params.orderBy="";
                params.orderDir="";//默认排序
                params.param.beginDownPayments="";
                params.param.endDownPayments="";//首付
                params.param.beginMonthPayments="";
                params.param.endMonthPayments="";//月供
                params.param.downPaymentsRates="";
                params.param.beginSellPrice="";
                params.param.endSellPrice="";
                params.param.levelNames="";//筛选
                params.param.brandId="";//品牌
                carBrandBg.hide();
                carBrandCont.slideUp('slow');
                vm.page.screenParams();
            },

            //确定首付
            sureFirst:function(){
                var firstNum=firstCont.find('dd.cur'),
                    paymentMin=$('.js-payment-min').val(),
                    paymentMax=$('.js-payment-max').val();
                params.orderBy="";
                params.orderDir="";//默认排序
                params.param.brandId="";//品牌
                params.param.beginMonthPayments="";
                params.param.endMonthPayments="";//月供
                params.param.downPaymentsRates="";
                params.param.beginSellPrice="";
                params.param.endSellPrice="";
                params.param.levelNames="";//筛选
                if(firstNum.length>0){
                    params.param.beginDownPayments=firstNum.attr('data-min');
                    params.param.endDownPayments=firstNum.attr('data-max');//首付
                    newCarNavBg1.hide();
                    firstCont.slideUp('slow');
                    vm.page.screenParams();
                }else{
                    if(!$.trim(paymentMin) || !$.trim(paymentMax)){
                        common.toast("请输入首付区间值");
                    }else{
                        params.param.beginDownPayments=""+parseInt(paymentMin)*10000+"";
                        params.param.endDownPayments=""+parseInt(paymentMax)*10000+"";//首付
                        newCarNavBg1.hide();
                        firstCont.slideUp('slow');
                        vm.page.screenParams();
                    }
                }
            },

            //确定月供
            sureMonth:function(){
                var monthNum=monthCont.find('dd.cur'),
                    supplyMin=$('.js-supply-min').val(),
                    supplyMax=$('.js-supply-max').val();
                params.orderBy="";
                params.orderDir="";//默认排序
                params.param.brandId="";//品牌
                params.param.beginDownPayments="";
                params.param.endDownPayments="";//首付
                params.param.downPaymentsRates="";
                params.param.beginSellPrice="";
                params.param.endSellPrice="";
                params.param.levelNames="";//筛选
                if(monthNum.length>0){
                    params.param.beginMonthPayments=monthNum.attr('data-min');
                    params.param.endMonthPayments=monthNum.attr('data-max');//月供
                    newCarNavBg2.hide();
                    monthCont.hide();
                    vm.page.screenParams();
                }else{
                    if(!$.trim(supplyMin) || !$.trim(supplyMax)){
                        common.toast("请输入首付区间值");
                    }else{
                        params.param.beginMonthPayments=supplyMin;
                        params.param.endDownPayments=supplyMax;//月供
                        newCarNavBg2.hide();
                        monthCont.hide();
                        vm.page.screenParams();
                    }
                }
            },

            //确定筛选
            navScreen:function(){
                var discountNum=$('.js-service').find('li.cur'),
                    carPriceNum=$('#range_1').val(),
                    carTypeNum=$('.js-model').find('li.cur'),
                    obj=[],array=[];
                if(carTypeNum.length>0){
                    for(var i=0;i<carTypeNum.length;i++){
                        obj.push(carTypeNum.eq(i).attr('data-type'))
                    }
                }else{
                    obj="";
                }
                array.push(discountNum.attr('data-type'));
                params.orderBy="";
                params.orderDir="";//默认排序
                params.param.brandId="";//品牌
                params.param.beginDownPayments="";
                params.param.endDownPayments="";//首付
                params.param.beginMonthPayments="";
                params.param.endMonthPayments="";//月供
                params.param.downPaymentsRates=array;
                params.param.beginSellPrice=carPriceNum.split(";")[0];
                params.param.endSellPrice=carPriceNum.split(";")[1];
                params.param.levelNames=obj;//筛选
                carMoreScreen.hide();
                navMoreSelect.removeClass('screen-show');
                vm.page.screenParams();
            },

            //错误提示
            errorCont:function(res){
                $('.js-error').show().find('p').text(res.message);
                refresher.onErrorCompeted();
                $('.pullUpLabel').text('');
                vm.event.pulltoDo();
            },

            //空数据
            emptyData:function(){
                $('.js-empty').show();
                refresher.onEmptyCompeted();
                wrapper.refresh();
                $('.pullUpLabel').text('');
            },

            //筛选--选择不同条件
            selectType:function(){
                $(this).addClass('cur').siblings().removeClass('cur');
            },

            //筛选--选择车型
            selectCarType:function(){
                selectTypeDetail.removeClass('cur');
                $(this).toggleClass('cur');
            },

            //筛选--选择车型--不限
            unLimitedCar:function(e){
                $(e.currentTarget).addClass('cur');
                $('.js-model').find('li').removeClass('cur');
            }
        }
    });

    var addEvent = function(){
        //收藏
        newCarList.on('click', '.js-collect', vm.page.jumpCarCollect);
        //详情页
        newCarList.on('click', '.js-second-detail', vm.page.secondCarDetail);

        //头部导航
        newHeaderNav.on('click', '.js-nav li', vm.page.clickScreen);
        newHeaderNav.on('click', '.js-choose-payment dd,.js-choose-supply dd', vm.page.selectType);

        //关闭筛选
        navMoreSelect.on('click','.js-service li',vm.page.selectType);
        navMoreSelect.on('click','.js-model li',vm.page.selectCarType);

        //确定默认排序
        navSelectDetail.on('click',".js-default-select dd",vm.page.selectDefaultSort);

        //确定品牌
        carBrandCont.on('click',".js-brand-item",vm.page.clickSureBrand);
        carBrandCont.on('click',".js-no-limit",vm.page.sureBrandNoLimit);
    };

    addEvent();

    fly.bind(document.body, vm);
});

$("#range_1").ionRangeSlider({
    min:0,
    max:100,
    from:0,
    to:100,
    type:'double',
    step:1,
    prefix:"",
    postfix:"",
    prettify:true,
    hasGrid:true
});
