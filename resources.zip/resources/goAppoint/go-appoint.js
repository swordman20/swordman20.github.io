/**
 * @author: xiaomei
 * @date: 2018.6.27
 * @description 立即预约
 */

require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'dialog'
], function (doT,flyMobile,dialog){
    var phoneCode=$('.js-code'),
        userName=$('.js-name'),
        userPhone=$('.js-phone'),
        discountName=$('.js-discount-name'),
        countNum=120,

        phoneDefault=$('.js-default'),
        phoneOther=$('.js-other');

    window.getParams=function(res){
       if(res.carUserUrl=="free"){
           $('.js-discount-img').attr('src',"../public/images/default_consult.png");
       }else{
           $('.js-discount-img').attr('src',res.carUserUrl);
       }
        discountName.html(res.carUserName);
        discountName.attr('data-id',res.carUserId);

        //判断用户信息
        flyMobile.data({
            source:'',
            action:'',
            actionType:'7',
            path:'',
            callback:true
        }).done(function(obj){
            $('.js-default').find('span').text(obj.userInfo.loginCode);
        });

    };

    var vm = window.vm = fly({
        data: {
            textTip: "使用其他的手机号预约"
        },
        event:{},
        page:{
            //切换手机预约
            changePhone:function() {
                if(phoneCode.hasClass('hide')){
                    vm.data.set('textTip', '使用默认的手机号预约');
                    phoneDefault.hide();
                    phoneOther.removeClass('hide');
                    phoneCode.removeClass('hide');
                }else{
                    vm.data.set('textTip', '使用其他的手机号预约');
                    phoneCode.addClass('hide');
                    phoneDefault.show();
                    phoneOther.addClass('hide');
                }
            },

            //倒计时
            countDown:function(){
                if (countNum == 0) {
                    $('.js-send-code').show();
                    $('.js-count-down').hide();
                    countNum = 120;
                }else{
                    $('.js-send-code').hide();
                    $('.js-count-down').show().html("重新发送(" + countNum + ")s");
                    countNum--;
                    setTimeout(function(){
                        vm.page.countDown();
                    },1000)
                }
            },

            //发送验证码
            sendPhoneCode:function(){
                var userPhoneCont=userPhone.val(),
                    myReg=/^[1][3,4,5,7,8][0-9]{9}$/;
                if(!$.trim(userPhoneCont)){
                    layer.msg('请输入手机号码');
                }else if (!myReg.test(userPhoneCont)) {
                    layer.msg('请输入正确的手机号码');
                }else{
                    var params={
                        "param":{
                            "mobileNo":userPhoneCont,
                            "deviceId":"f7887fdsgwef8w4848"
                        }
                    };
                    flyMobile.data({
                        source:'carDiscount',
                        action:'',
                        actionType:'4',
                        args:params,
                        path:'crm/api/user/sendVerifyCode',
                        callback:true
                    }).done(function (res){
                        if (res.statusCode == 200){
                            layer.msg('发送短信成功');
                            $('.js-btn').attr('data-type',res.data);
                            vm.page.countDown();
                        } else {
                            layer.msg('发送短信失败');
                        }
                    });
                }
            },

            //使用手机预约
            applyDefault:function(){
                var userNameCont=userName.val(),
                    userPhoneCont=userPhone.val(),
                    phoneCodeCont=phoneCode.find('input').val(),
                    codeVal=$('.js-btn').attr('data-type'),
                    myReg=/^[1][3,4,5,7,8][0-9]{9}$/;

                var params={
                    "param":{
                        "carSourceId":discountName.attr('data-id'),
                        "name":userNameCont,
                        "phone":""
                    }
                };

                if(phoneOther.hasClass('hide')){
                    params.param.phone=phoneDefault.find('span').html();
                }else{
                    params.param.phone=userPhoneCont;
                }

                if(!$.trim(userNameCont)){
                    layer.msg('请输入姓名');
                }else if(!phoneOther.hasClass('hide')){
                    if(!$.trim(userPhoneCont)){
                        layer.msg('请输入手机号码');
                    }else if(!myReg.test(userPhoneCont)){
                        layer.msg('请输入正确的手机号码');
                    }else if(!$.trim(phoneCodeCont)){
                        layer.msg('请输入验证码');
                    }else if(phoneCodeCont != codeVal){
                        layer.msg('验证码输入不正确');
                    }else{
                        flyMobile.data({
                            source: 'carDiscount',
                            action: '',
                            actionType: '4',
                            args: params,
                            path: 'crm/api/reserve/save',
                            callback: true
                        }).done(function(res){
                            if (res.statusCode == 200){
                                var params={popType:1,jumpData:""};
                                $('.js-appoint-btn').removeClass('hide');
                                $('.js-btn').addClass('hide');
                                layer.msg('预约成功',function(){
                                    flyMobile.data({
                                        source:'',
                                        action:'',
                                        args:params,
                                        actionType:'6',
                                        callback: false
                                    })
                                });
                            } else {
                                layer.msg('预约失败');
                            }
                        });
                    }
                }else {
                    flyMobile.data({
                        source: 'carDiscount',
                        action: '',
                        actionType: '4',
                        args: params,
                        path: 'crm/api/reserve/save',
                        callback: true
                    }).done(function(res){
                        if (res.statusCode == 200){
                            var params={popType:1,jumpData:""};
                            $('.js-appoint-btn').removeClass('hide');
                            $('.js-btn').addClass('hide');
                            layer.msg('预约成功',function(){
                                flyMobile.data({
                                    source:'',
                                    action:'',
                                    args:params,
                                    actionType:'6',
                                    callback:false
                                })
                            });
                        } else {
                            layer.msg('预约失败');
                        }
                    });
                }
            }
        }
    });
    fly.bind(document.body, vm);
});
