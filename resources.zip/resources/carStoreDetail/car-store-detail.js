/**
 * @author: xiaomei
 * @date: 2018.6.27
 * @description 门店详情
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery'
], function (doT,flyMobile,jquery,common){
    var params={"param":""},
        storeType=$('.js-store-data'),
        storeData=$('.js-store-name'),
        userLogin=true;

    window.getParams=function(res){
        params.param=res.userId;
        storeData.html(res.userType);
        storeType.attr('data-id',res.userId);
        storeType.attr('data-name',res.userType);
        storeType.attr('data-type',res.userCityName);
        dao.getTotalCar();

        //判断用户信息
        flyMobile.data({
            source:'',
            action:'',
            actionType:'7',
            path:'',
            callback:true
        }).done(function(obj){
            //判断是否登录
            var judgeLogin=obj.token;
            if(typeof judgeLogin == "undefined" || judgeLogin == null || judgeLogin == ""){
                userLogin=false;
            }else{
                userLogin=true;
            }
        });

    };

    var vm = window.vm = fly({
        data:{
            textFollow: "关注"
        },
        event:{},
        page:{
            //关注
            clickCarFollow:function(e){
                var _this=$(e.currentTarget),
                    params={
                    "param":{
                        "status":0,
                        "supplierAddress":storeType.attr('data-type'),
                        "supplierId":storeType.attr('data-id'),
                        "supplierName":storeType.attr('data-name')
                    }
                };
                if(userLogin==false){
                    flyMobile.data({
                        source: 'myIndex',
                        action: 'jumpLogin',
                        actionType: '3',
                        callback: false
                    });
                }else{
                    if(_this.hasClass('active')){
                        params.param.status = 0
                    }else{
                        params.param.status = 1;
                    }
                    flyMobile.data({
                        source:'carStoreDetail',
                        action:'',
                        actionType:'4',
                        path:'crm/api/user/attention',
                        args:params,
                        callback:true
                    }).done(function(res){
                        if(res.statusCode == 200){
                            if(params.param.status==0){
                                common.toast("取消关注成功");
                                _this.removeClass('active');
                                vm.data.set('textFollow', '关注');
                            }else{
                                common.toast("关注成功");
                                _this.addClass('active');
                                vm.data.set('textFollow', '已关注');
                            }
                        }else{
                            common.toast(res.message);
                        }
                    });
                }
            },

            //跳转到详情
            jumpCarSecondDetail:function(e){
                var params={"userId":$(e.currentTarget).attr('data-id')},
                    typeDetail=$(e.currentTarget).attr('data-type');
                if(typeDetail=="二手车"){
                    flyMobile.data({
                        source: 'secondCarListDetail',
                        action: 'secondCarListDetail',
                        actionType: '1',
                        args:params,
                        callback: false
                    });
                }else{
                    flyMobile.data({
                        source: 'newCarListDetail',
                        action: 'newCarListDetail',
                        actionType: '1',
                        args:params,
                        callback: false
                    });
                }
            }
        }
    });

    var dao = {
        //门店详情
        getTotalCar: function(){
            common.showToast();
            flyMobile.data({
                source:'carStoreDetail',
                action:'',
                actionType:'4',
                path:'car/api/source/listBySupplier',
                args:params,
                callback:true
            }).done(function(res){
                common.hideToast();
                if (res.statusCode == 200){
                    if(res.data.isAttention=="0"){
                        $('.js-attention').removeClass('active');
                        vm.data.set('textFollow', '关注');
                    }else{
                        $('.js-attention').addClass('active');
                        vm.data.set('textFollow', '已关注');
                    }
                    if(res.data.list.length>0){
                        var requestTmpl = doT.template($('#storeListTemple').text());
                        $('.js-store-list').append(requestTmpl(res.data.list));
                    }else{
                        $('.js-empty').show();
                    }
                }else{
                    common.toast(res.message);
                }
            });
        }
    };

    $('.js-store-list').on('click',"li",vm.page.jumpCarSecondDetail);

    fly.bind(document.body, vm);
});