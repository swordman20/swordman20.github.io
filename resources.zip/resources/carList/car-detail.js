/**
 * @author: xiaomei
 * @date: 2018.6.11
 * @description 车辆管理列表页
 */

window.refreshList=function(){
    dao.getTotalCar();
};

require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'lazyLoad',
    'jquery',
    'iscroll',
    'pullToRefresh'
], function (doT, flyMobile, jquery, common,lazyLoad,iscroll, pullToRefresh) {
    var pageSize = 10,
        currentPageNo = 1,
        upPermit = 0,
        clickCarLine=0,
        clickCarBrand=0;

    var carDetailNav=$('.js-car-nav'),
        carScreen=$('.js-screen'),
        carListDetail=$('.js-car-detail'),

        carRankBg=$('.js-rank-bg'),
        carLineBg=$('.js-line-bg'),
        carBrandBg=$('.js-brand-bg'),
        carScreenBg=$('.js-screen-bg'),

        carSort=$('.js-nav-drop'),
        carLineCont=$('.js-car-line'),
        carBrandCont=$('.js-car-brand'),
        saveScreen=$('.js-save-screen');

    // 筛选条件
    var params={
        "orderBy":"",
        "orderDir":"",
        "pageNo":1,
        "pageSize":10,
        "param":{
            "sellStatus":"",
            "status":"",
            "supplierId":"",
            "brandId":"",
            "beginSellPrice":"",
            "endSellPrice":"",
            "beginKilometers":"",
            "endKilometers":""
        }
    };

    //获取参数
    window.getParams = function(res){
        var typeData=res.typeValue;
        switch(typeData){
            case "all":
                break;
            case "sellStatus2":
                params.param.sellStatus=2;
                break;
            case "status1":
                params.param.status=1;
                break;
            case "isSold1":
                params.param.sellStatus=4;
                break;
            case "status2":
                params.param.status=2;
                break;
            case "sellStatus3":
                params.param.sellStatus=3;
                break;
        }
        
        dao.getTotalCar();
    };

    var vm = window.vm = fly({
        data:{},
        event: {
            pulltoDo:function(){
                //初始化上拉下拉操作
                refresher.init({
                    id: "wrapper",
                    pullDownAction:vm.event.reloadNew,
                    pullUpAction:vm.event.loadMore
                });
            },
            loadMore: function() {
                if (upPermit === 0) {
                    //上拉加载
                    currentPageNo++;
                    params.pageNo = currentPageNo;
                    flyMobile.data({
                        source:'carList',
                        action:'',
                        actionType: '4',
                        path:'car/api/source/auditList',
                        args: params,
                        callback: true
                    }).done(function (res) {
                        if (res.statusCode == 200){
                            if(res.data.rows.length>0){
                                var requestTmpl = doT.template($('#uploadListTemple').text());
                                carListDetail.append(requestTmpl(res.data.rows));
                                if (res.data.rows.length < pageSize) {
                                    upPermit = 1;
                                    refresher.onResherCompeted();
                                }
                                wrapper.refresh();
                            }
                        }else{
                            vm.page.errorData(res);
                        }
                    });
                }else{
                    refresher.onResherCompeted();
                    wrapper.refresh();
                }
            },
            reloadNew: function() {
                //下拉刷新
                currentPageNo = 1;
                params.pageNo = currentPageNo;
                upPermit = 0;
                flyMobile.data({
                    source:'carList',
                    action:'',
                    actionType:'4',
                    path:'car/api/source/auditList',
                    args: params,
                    callback:true
                }).done(function (res) {
                    if(res.statusCode == 200){
                        if(res.data.rows.length>0) {
                            var requestTmpl = doT.template($('#uploadListTemple').text());
                            carListDetail.html('').append(requestTmpl(res.data.rows));
                            if(res.data.rows.length < pageSize){
                                refresher.onResherCompeted();
                                upPermit = 1;
                            }
                            wrapper.refresh();
                        }else {
                            vm.page.emptyData();
                            wrapper.refresh();
                        }
                    }else{
                        vm.page.errorData(res);
                    }
                });
            }
        },
        page: {
            //错误数据
            errorData:function(e){
                $('.js-error').show().find('p').text(e.message);
                refresher.onErrorCompeted();
                $('.pullUpLabel').text('');
                vm.event.pulltoDo();
            },

            //暂无内容
            emptyData:function(){
                $('.js-empty').show();
                refresher.onEmptyCompeted();
                $('.pullUpLabel').text('');
            },

            // 车辆详情
            jumpCarDetail: function (e){
                var params={"userId":$(e.currentTarget).attr('data-id')};
                flyMobile.data({
                    source:'carListDetail',
                    action:'carListDetail',
                    actionType:'1',
                    args:params,
                    callback:false
                });
            },

            //导航--筛选--排序
            clickScreen:function(e){
                var index = $(this).index();
                $(this).addClass('active').siblings().removeClass('active');
                switch(index){
                    //车行
                    case 0:
                        carRankBg.hide();
                        carSort.slideUp('slow');//排序
                        carLineCont.slideToggle('slow');
                        carLineBg.toggle();
                        carLineCont.find('ul').removeClass('screen-show');//车行
                        carBrandBg.hide();
                        carBrandCont.slideUp('slow');//品牌
                        carScreen.removeClass('screen-show');
                        carScreenBg.hide();//筛选
                        if(clickCarLine==0){
                            flyMobile.data({
                                source:'carList',
                                action:'',
                                actionType:'4',
                                path:'crm/api/supplier/listByCity',
                                callback:true
                            }).done(function(res){
                                if(res.statusCode == 200){
                                    var requestTmpl = doT.template($('#selectCarLineTemple').text());
                                    carLineCont.html('').append(requestTmpl(res.data));
                                    clickCarLine=1;
                                }else{
                                    common.toast(res.message);
                                }
                            });
                        }
                        break;
                    //品牌
                    case 1:
                        carRankBg.hide();
                        carSort.slideUp('slow');//排序
                        carLineCont.slideUp('slow');
                        carLineBg.hide();
                        carLineCont.find('ul').removeClass('screen-show');//车行
                        carBrandBg.toggle();
                        carBrandCont.slideToggle('slow');//品牌
                        carScreen.removeClass('screen-show');
                        carScreenBg.hide();//筛选
                        var params={"param":"1"};
                        if(clickCarBrand==0){
                            flyMobile.data({
                                source:'carList',
                                action:'',
                                actionType:'4',
                                path:'car/api/brand/listByLetter',
                                args:params,
                                callback:true
                            }).done(function (res){
                                if(res.statusCode == 200){
                                    var requestTmpl = doT.template($('#selectCarBrandTemple').text());
                                    carBrandCont.html('').append(requestTmpl(res.data));
                                    clickCarBrand=1;
                                }else{
                                    common.toast(res.message);
                                }
                            });
                        }
                        break;
                    // 排序
                    case 2:
                        carSort.slideToggle('slow');
                        carRankBg.toggle();//排序
                        carLineCont.slideUp('slow');
                        carLineBg.hide();
                        carLineCont.find('ul').removeClass('screen-show');//车行
                        carBrandBg.hide();
                        carBrandCont.slideUp('slow');//品牌
                        carScreen.removeClass('screen-show');
                        carScreenBg.hide();//筛选
                        break;
                    case 3:
                        carRankBg.hide();
                        carSort.slideUp('slow');//排序
                        carLineCont.slideUp('slow');
                        carLineBg.hide();
                        carLineCont.find('ul').removeClass('screen-show');//车行
                        carBrandBg.hide();
                        carBrandCont.slideUp('slow');//品牌
                        carScreen.toggleClass('screen-show');
                        carScreenBg.toggle();//筛选
                        break;
                }

            },

            // 选择排序内容
            clickSort: function(e){
                var _this=$(this);
                _this.addClass('cur').siblings().removeClass('cur');
                $('.js-select-cont').text($(this).text());
                params.orderBy=_this.attr('data-type');
                params.orderDir=_this.attr('data-order');
                params.param.supplierId="";
                params.param.status="";
                params.param.sellStatus="";
                params.param.beginSellPrice="";
                params.param.endSellPrice="";
                params.param.beginKilometers="";
                params.param.endKilometers="";
                carRankBg.hide();
                carSort.slideUp('slow');
                vm.page.selectParams();
            },

            // 关闭更多筛选
            closeScreen:function(){
                carScreen.removeClass('screen-show');
            },

            //筛选--车辆状态
            selectState:function(){
                $(this).addClass('cur').siblings().removeClass('cur');
                saveScreen.attr('data-name',$(this).attr('data-type'));
            },

            //车行市选择
            carLineScreen:function(e){
                var _this=$(this);
                _this.addClass('active').parent().siblings().find('h4').removeClass('active');
                _this.siblings('ul').addClass('screen-show').parent().siblings().find('ul').removeClass('screen-show');
            },

            //车行确定
            sureCarLine:function(e){
                var _this=$(e.currentTarget);
                params.param.supplierId=_this.attr('data-id');
                params.orderBy="";
                params.orderDir="";
                params.param.brandId="";
                params.param.status="";
                params.param.sellStatus="";
                params.param.beginSellPrice="";
                params.param.endSellPrice="";
                params.param.beginKilometers="";
                params.param.endKilometers="";
                carLineCont.slideUp('slow');
                carLineBg.hide();
                carLineCont.find('ul').removeClass('screen-show');
                vm.page.selectParams();
            },

            //确定品牌
            sureCarBrand:function(e){
                var _this=$(e.currentTarget);
                params.param.brandId=_this.attr('data-id');
                params.orderBy="";
                params.orderDir="";
                params.param.supplierId="";
                params.param.status="";
                params.param.sellStatus="";
                params.param.beginSellPrice="";
                params.param.endSellPrice="";
                params.param.beginKilometers="";
                params.param.endKilometers="";
                carBrandBg.hide();
                carBrandCont.slideUp('slow');
                vm.page.selectParams();
            },

            //添加筛选条件
            selectParams:function(){
                flyMobile.data({
                    source:'carList',
                    action:'',
                    actionType:'4',
                    path:'car/api/source/auditList',
                    args:params,
                    callback:true
                }).done(function(res){
                    common.hideToast();
                    if(res.statusCode == 200){
                        if(res.data.rows.length>0) {
                            var requestTmpl = doT.template($('#uploadListTemple').text());
                            carListDetail.empty().append(requestTmpl(res.data.rows));
                            $('.js-empty').hide();
                            if (res.data.rows.length < pageSize) {
                                refresher.onResherCompeted();
                                upPermit = 1;
                            } else {
                                refresher.onInitCompeted();
                            }
                            wrapper.refresh();
                        }else {
                            carListDetail.empty();
                            vm.page.emptyData();
                        }
                    }else{
                        vm.page.errorData(res);
                    }
                });
            },

            //确定更多选择
            moreScreenSure:function(){
                var carExamine=saveScreen.attr('data-type'),
                    carState=saveScreen.attr('data-name');
                if(carExamine=="status1"){
                    params.param.status=1;
                }else if(carExamine=="status2"){
                    params.param.status=2;
                    if(carState=="sellStatus1"){
                        params.param.sellStatus=1;
                    }else if(carState=="sellStatus2"){
                        params.param.sellStatus=2;
                    }else if(carState=="sellStatus3"){
                        params.param.sellStatus=3;
                    }else if(carState=="isSold1"){
                        params.param.sellStatus=4;
                    }else{
                        params.param.sellStatus="";
                    }
                }else if(carExamine=="status3"){
                    params.param.status=3;
                }else if(carExamine=="status4"){
                    params.param.status=4;
                }else if(carExamine=="status5"){
                    params.param.status=5;
                }else{
                    params.param.status="";
                    params.param.sellStatus="";
                }
                var rangeOne=$('#range_1').val(),
                    rangeTwo=$('#range_2').val();
                params.param.brandId="";
                params.orderBy="";
                params.orderDir="";
                params.param.supplierId="";
                params.param.beginSellPrice=rangeOne.split(";")[0];
                params.param.endSellPrice=rangeOne.split(";")[1];
                params.param.beginKilometers=rangeTwo.split(";")[0];
                params.param.endKilometers=rangeTwo.split(";")[1];
                vm.page.selectParams();
                carScreen.removeClass('screen-show');
                carScreenBg.hide();
            },

            //筛选--审核状态
            examineState:function(){
                $(this).addClass('cur').siblings().removeClass('cur');
                if($(this).hasClass('js-examine')){
                    $('.js-car-state').removeClass('gray-select').addClass('js-select');
                }else{
                    $('.js-car-state').addClass('gray-select').removeClass('js-select');
                }
                saveScreen.attr('data-type',$(this).attr('data-type'));
            }
        }
    });
    var dao = {
        //车辆列表
        getTotalCar: function(){
            common.showToast();
            flyMobile.data({
                source:'carList',
                action:'',
                actionType:'4',
                path:'car/api/source/auditList',
                args:params,
                callback:true
            }).done(function(res){
                common.hideToast();
                if(res.statusCode == 200){
                    if(res.data.rows.length>0) {
                        var requestTmpl = doT.template($('#uploadListTemple').text());
                        carListDetail.append(requestTmpl(res.data.rows));
                        if (res.data.rows.length < pageSize) {
                            refresher.onResherCompeted();
                            upPermit = 1;
                        } else {
                            refresher.onInitCompeted();
                        }
                        vm.event.pulltoDo();
                    }else {
                        vm.page.emptyData();
                    }
                }else{
                    vm.page.errorData(res);
                }
            });
        }
    };
    var addEvent = function(){
        carDetailNav.on('click', '.js-nav li', vm.page.clickScreen);
        carSort.on('click', 'dd', vm.page.clickSort);
        carListDetail.on('click', 'li', vm.page.jumpCarDetail);
        carScreen.on('click','.js-close-screen',vm.page.closeScreen);
        carScreen.on('click','.js-examine-state dd',vm.page.examineState);
        carScreen.on('click','.js-select dd',vm.page.selectState);

        //选择车行
        carLineCont.on('click','.js-line-city',vm.page.carLineScreen);
        carLineCont.on('click','.js-line-item',vm.page.sureCarLine);

        //选择品牌
        carBrandCont.on('click','.js-brand-item',vm.page.sureCarBrand);
    };

    addEvent();

    fly.bind(document.body, vm);
});
