/**
 * @author: xiaomei
 * @date: 2018.6.8
 * @description 基本信息
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'jquery'
], function (doT, flyMobile, jquery) {

    var vm = window.vm = fly({
        data: {
            VIN: "1G1BL52P7TR115520",
            dealer: "合肥",
            name: "奥迪 A3 018款 30周年年型 Sportback 35 TFSI 进取型",
            sellPrice: "15.19万",
            color: "冰川白",
            kilometers: "0.8万公里",
            firstUp: "2018-03"
        }
    });
    var dao = {
        /**
         * [车辆列表 ]
         */
        getUploadData: function(){
            // vm.data.set('modelName', res.data.modelName);
            // vm.data.set('statusDesc', res.data.statusDesc);
            // vm.data.set('vin', res.data.vin);
            // vm.data.set('supplierName', res.data.supplierName);
            // vm.data.set('sellPrice', '¥' + res.data.sellPrice);
            // vm.data.set('kilometers', res.data.kilometers);
            // vm.data.set('optMan', res.data.optMan);
            // vm.data.set('optManPhone', res.data.optManPhone);
            // vm.data.set('rejectReasons', res.data.rejectReasons);
        }
    };
    var init = function () {
        dao.getUploadData();
    };
    init();
    fly.bind(document.body, vm);
});