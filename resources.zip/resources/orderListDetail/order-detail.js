/**
 * @author: xiaomei
 * @date: 2018.7.2
 * @description 订单详情
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery'
], function (doT, flyMobile, jquery,common){
    var params={"param":""};

    //获取参数
    window.getParams = function(res){
        params.param=res.userId;
        dao.getOrderData();
    };

    var vm = window.vm = fly({
        data:{
            orderCode:"",
            orderAddress: "",
            saleName: "",
            downPayments: "",
            monthPayments: "",
            serviceCharge: "",
            periods: "",
            sellPrice: "",
            kilometers:"",
            sourceName:"",
            payDeposit:"",
            color:""
        },
        page:{}
    });

    var dao={
        //订单详情
        getOrderData:function(){
            common.showToast();
            flyMobile.data({
                source:'orderListDetail',
                action:'',
                actionType:'4',
                path:'order/api/order/getOrderInfo',
                args:params,
                callback:true
            }).done(function (res){
                common.hideToast();
                if(res.statusCode == 200) {
                    vm.data.set('orderCode', res.data.orderCode || '0');
                    vm.data.set('orderAddress', res.data.orderAddress || '合肥');
                    vm.data.set('saleName', res.data.saleName);
                    vm.data.set('downPayments', res.data.downPayments || '0');
                    vm.data.set('monthPayments', res.data.monthPayments || '0');
                    vm.data.set('serviceCharge', res.data.serviceCharge || '0');
                    vm.data.set('periods', res.data.periods || '0');
                    vm.data.set('sellPrice', res.data.sellPrice || '0');
                    vm.data.set('color', res.data.color || '白色');
                    vm.data.set('kilometers', res.data.kilometers || '0');
                    vm.data.set('sourceName', res.data.sourceName || '无');
                    vm.data.set('payDeposit', res.data.payDeposit || '0');

                    //车状态
                    var carNew=$('.js-car-new'),
                        carSecond=$('.js-car-second'),
                        stateImg=$('.js-state-img'),
                        statePhone=$('.js-phone');
                    stateImg.attr('src',res.data.fileUrl);
                    statePhone.attr('href',res.data.phone);
                    if(res.data.carCategoryDesc=='新车'){
                        carNew.removeClass('state-hide');
                    }else if(res.data.carCategoryDesc=='二手车'){
                        carSecond.removeClass('state-hide');
                    }

                    //订单状态
                    var carNavState=$('.js-node'),
                        orderState=res.data.orderStatus;
                    switch(orderState){
                        case 1:
                            break;
                        case 2:
                            carNavState.find('li').eq(1).addClass('cur');
                            break;
                        case 3:
                            carNavState.find('li').eq(1).addClass('cur');
                            carNavState.find('li').eq(2).addClass('cur');
                            break;
                        case 4:
                            carNavState.find('li').eq(1).addClass('cur');
                            carNavState.find('li').eq(2).addClass('cur');
                            carNavState.find('li').eq(3).addClass('cur');
                            break;
                        case 5:
                            carNavState.find('li').addClass('cur');
                            break;
                    }
                }else{
                    common.toast(res.message);
                }
            });
        }
    };

    fly.bind(document.body, vm);
});