/**
 * @author: xiaomei
 * @date: 2018.7.24
 * @description 历史账单
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery'
], function (doT,flyMobile, jquery,common) {

    var vm = window.vm = fly({
        data:{
            remainingAmount:'',
            totalAmount:'',
            returnedAmount:''
        }
    });
    var dao = {
        //历史账单
        getTotalCarInfo: function(){
           common.showToast();
            flyMobile.data({
                source: 'historicalBill',
                action: '',
                actionType: '4',
                path: 'crm/api/reserve/findMyRefundplan',
                callback:true
            }).done(function (res) {
                common.hideToast();
                if (res.statusCode == 200) {

                    vm.data.set('remainingAmount', ("￥" + res.data.remainingAmount) || "0" );
                    vm.data.set('totalAmount', ("￥" + res.data.totalAmount) || "0" );
                    vm.data.set('returnedAmount', ("￥" + res.data.returnedAmount) || "0" );

                    var configData = res.data.planList;
                    var configDataTmpl = doT.template($('#basicParameterTemple').text());
                    $('.js-historical-bill').append(configDataTmpl(configData));

                }else{
                    common.toast(res.message);
                }
            });
        }
    };

    dao.getTotalCarInfo();

    fly.bind(document.body, vm);
});