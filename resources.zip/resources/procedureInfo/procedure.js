/**
 * @author: xiaomei
 * @date: 2018.6.8
 * @description 手续信息
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'jquery'
], function (doT, flyMobile, jquery){
    var data = [];
    // window下面的方法
    window.submitData = function(){
        return data;
    };
    var vm = window.vm = fly({
        data:{},
        event:{},
        page:{}
    });
    var dao = {
        //获取手续信息
        getPosData: function(type){
            // flyMobile.data({
            //     source: 'procedureInfo',
            //     action: 'posListData',
            //     actionType: '4',
            //     path: 'crm/api/supplier/listAll',
            //     args: params
            //     callback: true
            // }).done(function (res) {
            //     res = JSON.parse(res);
                res = { 
                    statusCode: 200, 
                    message: "成功", 
                    data: [ 
                        { 
                        label: "手续信息", 
                        value: "[{'name':'购置税','yes':'有','no':'无'},{'name':'行驶证','yes':'有','no':'无'},{'name':'登记证','yes':'有','no':'无'},{'name':'原车主身份证','yes':'有','no':'无'},{'name':'原车牌照','yes':'有','no':'无'},{'name':'新车发票','yes':'有','no':'无'},{'name':'新车质保','yes':'保内','no':'过保'},{'name':'新车保养手册','yes':'有','no':'无'},{'name':'车辆说明书','yes':'有','no':'无'},{'name':'交强险单','yes':'有','no':'无'},{'name':'商业险单','yes':'有','no':'无'},{'name':'车船税证','yes':'有','no':'无'}]", 
                        type: "formalities", 
                        description: "手续信息", 
                        sort: 1 
                        } 
                    ]
                };
                if (res != undefined && res.statusCode == 200 && !(res.data === null)) {
                    var value = eval(res.data[0].value);
                    var requestTmpl = doT.template($('#proceListTemple').text());
                    $('.proce-list').append(requestTmpl(value));

                }else {
                    $('.empty').removeClass('hide');
                }

            // }); 
        }
    };
    var init = function(){
        dao.getPosData();
    };
    init();
    fly.bind(document.body, vm);
});