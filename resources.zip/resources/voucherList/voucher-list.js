/**
 * @author: wxm
 * @date: 2018.6.1
 * @description 我的卡券
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll',
    'pullToRefresh'
], function (doT, flyMobile, jquery, common,iscroll,pullToRefresh) {
    var pageSize = 10,
        currentPageNo = 1,
        upPermit = 0;

    var voucherCenter=$('.js-voucher');

    // 筛选条件
    var params = {
        "pageNo":1,
        "pageSize":10,
        "param":"0"
    };

    var vm = window.vm = fly({
        data:{
            unuse:"0",
            used:"0",
            expired:"0"
        },
        event: {
            pulltoDo: function() {
                //初始化上拉下拉操作
                refresher.init({
                    id: "wrapper",
                    pullDownAction: vm.event.reloadNew,
                    pullUpAction: vm.event.loadMore
                });
            },
            loadMore: function() {
                if (upPermit === 0){
                    //上拉加载
                    currentPageNo++;
                    params.pageNo = currentPageNo;
                    $.ajax({
                        headers:{'Authorization':tokenValue},
                        type:'post',
                        url:serverApiUrl+'coupon/api/coupon/listByUser',
                        async:false,
                        contentType:'application/json',
                        data:JSON.stringify(params),
                        dataType:"json",
                        success:function(res){
                            if(res.data.result.length>0){
                                var requestTmpl = doT.template($('#myVoucherTemple').text());
                                voucherCenter.append(requestTmpl(res.data.result));
                                if (res.data.result.length < pageSize) {
                                    upPermit = 1;
                                    refresher.onResherCompeted();
                                }
                                wrapper.refresh();
                            } else {
                                refresher.onResherCompeted();
                                wrapper.refresh();
                            }
                        },
                        error:function(e){
                            common.hideToast();
                        }
                    });
                }else{
                    refresher.onResherCompeted();
                    wrapper.refresh();
                }
            },
            reloadNew: function() {
                //下拉刷新
                currentPageNo = 1;
                upPermit = 0;
                params.pageNo = currentPageNo;

                $.ajax({
                    headers:{'Authorization':tokenValue},
                    type:'post',
                    url:serverApiUrl+'coupon/api/coupon/listByUser',
                    async:false,
                    contentType:'application/json',
                    data:JSON.stringify(params),
                    dataType:"json",
                    success:function(res){
                        if(res.data.result.length>0){
                            var requestTmpl = doT.template($('#myVoucherTemple').text());
                            voucherCenter.html("").append(requestTmpl(res.data.result));
                            if(res.data.result.length < pageSize) {
                                refresher.onResherCompeted();
                                upPermit = 1;
                            }
                            wrapper.refresh();
                        } else {
                            vm.page.emptyData();
                        }
                    },
                    error:function(e){
                        common.hideToast();
                        vm.page.errorData(e);
                    }
                });
            }
        },
        page: {
            // 领券中心
            jumpVoucherCenter: function (e) {
                window.location.href=localhostUrl+"voucherCenter/voucherCenter.html";
            },

            //头部点击
            voucherTab:function(e){
                var _this=$(e.currentTarget).attr('data-type');
                params.param=_this;
                $(e.currentTarget).addClass('active').siblings().removeClass('active');
                dao.clickTabSwitch();
            },

            //错误提示
            errorData:function(e){
                $('.js-error').show().find('p').text(e.statusText);
                refresher.onErrorCompeted();
                $('.pullUpLabel').text('');
                vm.event.pulltoDo();
            },

            //暂无内容
            emptyData:function(){
                $('.js-empty').show();
                refresher.onEmptyCompeted();
                wrapper.refresh();
                $('.pullUpLabel').text('');
            }
        }
    });

    var dao = {
        //卡券列表
        getTotalCar: function(){
            common.showToast();
            $.ajax({
                headers:{'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'coupon/api/coupon/listByUser',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(res){
                    common.hideToast();
                    vm.data.set('unuse', res.data.unuse || '0');
                    vm.data.set('used', res.data.used || '0');
                    vm.data.set('expired', res.data.expired || '0');
                    if(res.data.result.length>0){
                        var requestTmpl = doT.template($('#myVoucherTemple').text());
                        voucherCenter.append(requestTmpl(res.data.result));

                        if (res.data.result.length < pageSize){
                            refresher.onResherCompeted();
                            upPermit = 1;
                        }else{
                            refresher.onInitCompeted();
                        }
                        vm.event.pulltoDo();
                    }else{
                        vm.page.emptyData();
                    }
                },
                error:function(e){
                    common.hideToast();
                    vm.page.errorData(e);
                }
            });
        },

        clickTabSwitch:function(){
            $.ajax({
                headers:{'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'coupon/api/coupon/listByUser',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(res){
                    if(res.data.result.length>0){
                        var requestTmpl = doT.template($('#myVoucherTemple').text());
                        $('.js-empty').hide();
                        voucherCenter.html("").append(requestTmpl(res.data.result));
                        if (res.data.result.length < pageSize){
                            refresher.onResherCompeted();
                            upPermit = 1;
                        }else{
                            refresher.onInitCompeted();
                        }
                        vm.event.pulltoDo();
                    }else{
                        voucherCenter.empty();
                        vm.page.emptyData();
                    }
                },
                error:function(e){
                    common.hideToast();
                    vm.page.errorData(e);
                }
            });
        }
    };

    $('.js-voucher-tab').on('click', 'li', vm.page.voucherTab);
    dao.getTotalCar();

    fly.bind(document.body, vm);
});