/**
 * @author: wxm
 * @date: 2018.6.1
 * @description 我的卡券
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll',
    'range',
    'pullToRefresh'
], function (doT, flyMobile, jquery, common,iscroll,jRange,pullToRefresh) {
    var pageSize = 10,
        currentPageNo = 1,
        upPermit = 0;

    var voucherCenter=$('.js-voucher');

    // 筛选条件
    var params = {
        "pageNo":1,
        "pageSize":10,
        "param":0
    };

    var vm = window.vm = fly({
        data:{
            unuse:"0",
            used:"0",
            expired:"0"
        },
        event: {
            pulltoDo: function() {
                //初始化上拉下拉操作
                refresher.init({
                    id: "wrapper",
                    pullDownAction: vm.event.reloadNew,
                    pullUpAction: vm.event.loadMore
                });
            },
            loadMore: function() {
                if (upPermit === 0) {
                    //上拉加载
                    currentPageNo++;
                    params.pageNo = currentPageNo;
                    flyMobile.data({
                        source:'voucherList',
                        action:'',
                        actionType:'4',
                        path:'coupon/api/coupon/listByUser',
                        args:params,
                        callback:true
                    }).done(function(res){
                        if(res.statusCode == 200){
                            if(res.data.result.length>0){
                                var requestTmpl = doT.template($('#myVoucherTemple').text());
                                voucherCenter.append(requestTmpl(res.data.result));
                                if (res.data.result.length < pageSize) {
                                    upPermit = 1;
                                    refresher.onResherCompeted();
                                }
                                wrapper.refresh();
                            } else {
                                refresher.onResherCompeted();
                                wrapper.refresh();
                            }
                        }
                    });
                }else{
                    refresher.onResherCompeted();
                    wrapper.refresh();
                }
            },
            reloadNew: function() {
                //下拉刷新
                currentPageNo = 1;
                upPermit = 0;
                params.pageNo = currentPageNo;
                flyMobile.data({
                    source:'voucherList',
                    action:'',
                    actionType:'4',
                    path:'coupon/api/coupon/listByUser',
                    args:params,
                    callback:true
                }).done(function(res){
                    if(res.statusCode == 200){
                        if(res.data.result.length>0){
                            var requestTmpl = doT.template($('#myVoucherTemple').text());
                            voucherCenter.html("").append(requestTmpl(res.data.result));
                            if(res.data.result.length < pageSize){
                                refresher.onResherCompeted();
                                upPermit = 1;
                            }
                            wrapper.refresh();
                        }else {
                            vm.page.emptyData();
                        }
                    }
                });
            }
        },
        page: {
            // 领券中心
            jumpVoucherCenter: function(e){
                flyMobile.data({
                    source:'voucherCenter',
                    action:'voucherCenter',
                    actionType:'1',
                    callback:false
                });
            },

            //头部点击
            voucherTab:function(e){
                var _this=$(e.currentTarget).attr('data-type');
                params.param=_this;
                $(e.currentTarget).addClass('active').siblings().removeClass('active');
                dao.clickTabSwitch();
            },

            //错误提示
            errorData:function(e){
                $('.js-error').show().find('p').text(e.statusText);
                refresher.onErrorCompeted();
                $('.pullUpLabel').text('');
                vm.event.pulltoDo();
            },

            //暂无内容
            emptyData:function(){
                $('.js-empty').show();
                refresher.onEmptyCompeted();
                wrapper.refresh();
                $('.pullUpLabel').text('');
            }
        }
    });
    var dao = {
        //卡券列表
        getTotalCar: function(){
            common.showToast();
            flyMobile.data({
                source:'voucherList',
                action:'',
                actionType:'4',
                path:'coupon/api/coupon/listByUser',
                args:params,
                callback:true
            }).done(function(res){
                common.hideToast();
                if(res.statusCode == 200){
                    vm.data.set('unuse', res.data.unuse || '0');
                    vm.data.set('used', res.data.used || '0');
                    vm.data.set('expired', res.data.expired || '0');

                    if(res.data.result.length>0){
                        var requestTmpl = doT.template($('#myVoucherTemple').text());
                        voucherCenter.append(requestTmpl(res.data.result));

                        if (res.data.result.length < pageSize) {
                            refresher.onResherCompeted();
                            upPermit = 1;
                        }else{
                            refresher.onInitCompeted();
                        }
                        vm.event.pulltoDo();
                    }else{
                        vm.page.emptyData();
                    }
                } else {
                    vm.page.errorData(res);
                }
            })
        },

        clickTabSwitch:function(){
            flyMobile.data({
                source:'voucherList',
                action:'',
                actionType:'4',
                path:'coupon/api/coupon/listByUser',
                args:params,
                callback:true
            }).done(function(res){
                if(res.statusCode == 200){
                    if (res.data.result.length>0){
                        var requestTmpl = doT.template($('#myVoucherTemple').text());
                        $('.js-empty').hide();
                        voucherCenter.html("").append(requestTmpl(res.data.result));
                        if (res.data.result.length < pageSize) {
                            refresher.onResherCompeted();
                            upPermit = 1;
                        }else{
                            refresher.onInitCompeted();
                        }
                        vm.event.pulltoDo();
                    } else {
                        voucherCenter.empty();
                        vm.page.emptyData();
                    }
                } else {
                    vm.page.errorData(res);
                }
            })
        }
    };

    $('.js-voucher-tab').on('click', 'li', vm.page.voucherTab);
    dao.getTotalCar();

    fly.bind(document.body, vm);
});