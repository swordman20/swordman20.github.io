/**
 * @author: xiaomei
 * @date: 2018.6.14
 * @description 新车首页
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'lazyLoad',
    'jquery',
    'iscroll',
    'pullToRefresh'
], function (doT, flyMobile,jquery, common,lazyLoad,iscroll, pullToRefresh) {
    var pageSize = 10,
        currentPageNo = 1,
        upPermit = 0,
        clickCarBrand=0;

    var newCarList=$('.js-new-list'),
        newHeaderNav=$('.js-car-nav'),

        newCarNavBg=$('.js-nav-bg'),
        newCarNavBg1=$('.js-nav-bg1'),
        newCarNavBg2=$('.js-nav-bg2'),
        carBrandBg=$('.js-nav-bg3'),
        carMoreScreen=$('.js-nav-bg4'),

        navSelectDetail=$('.js-nav-select-detail'),
        navMoreSelect=$('.js-screen'),
        carBrandCont=$('.js-car-brand'),

        firstCont=$('.js-choose-payment'),
        monthCont=$('.js-choose-supply'),
        defaultCont=$('.js-default-select');

    //获取列表数据
    window.getUsedCarListData=function(res){
        var resData = res.message,
            resJson= JSON.parse(resData);
        res = resJson.data.rows;
        if(resJson.statusCode == 200){
            var resLength=resJson.data.rows;
            if(resLength.length>0) {
                var requestTmpl = doT.template($('#newCarTemple').text());
                newCarList.append(requestTmpl(res));
                if (res.length < pageSize) {
                    refresher.onResherCompeted();
                    upPermit = 1;
                } else {
                    refresher.onInitCompeted();
                }
                vm.event.pulltoDo();
            }else {
                $('.js-empty').show();
                refresher.onEmptyCompeted();
                wrapper.refresh();
                $('.pullUpLabel').text('');
            }
        }else {
            vm.page.errorCont(res);
        }
    };

    // 筛选条件
    var params = {
        "orderBy": "",
        "orderDir": "",
        "pageNo": 1,
        "pageSize": 10,
        "param": {
            "carCategory":"2",
            "cityId":"",
            "downPaymentsRates":"",
            "brandId":"",
            "beginDownPayments":"",
            "endDownPayments":"",
            "beginMonthPayments":"",
            "endMonthPayments":"",
            "beginSellPrice":"",
            "endSellPrice":"",
            "levelNames":""
        }
    };

    var vm = window.vm = fly({
        data: {
            newCarList:[] // 全国排名列表
        },
        event: {
            pulltoDo: function() {
                //初始化上拉下拉操作
                refresher.init({
                    id: "wrapper",
                    pullDownAction: vm.event.reloadNew,
                    pullUpAction: vm.event.loadMore
                });
            },
            loadMore: function() {
                if (upPermit === 0) {
                    //上拉加载
                    currentPageNo++;
                    params.pageNo = currentPageNo;
                    flyMobile.data({
                        source:'newCarList',
                        action:'',
                        actionType: '4',
                        path:'car/api/source/list',
                        args:params,
                        callback: true
                    }).done(function (res){
                        res = JSON.parse(res);
                        if (res.statusCode == 200){
                            if(res.data.rows.length>0){
                                var requestTmpl = doT.template($('#newCarTemple').text());
                                newCarList.append(requestTmpl(res.data.rows));

                                if (res.data.rows.length < pageSize) {
                                    upPermit = 1;
                                    refresher.onResherCompeted();
                                }
                                wrapper.refresh();
                            } else {
                                refresher.onResherCompeted();
                                wrapper.refresh();
                            }
                        }else{
                            vm.page.errorCont(res);
                        }
                    });
                }else{
                    refresher.onResherCompeted();
                    wrapper.refresh();
                }
            },
            reloadNew: function() {
                //下拉刷新
                currentPageNo = 1;
                params.pageNo = currentPageNo;
                upPermit = 0;
                flyMobile.data({
                    source:'newCarList',
                    action:'',
                    actionType:'4',
                    path:'car/api/source/list',
                    args: params,
                    callback: true
                }).done(function (res) {
                    res = JSON.parse(res);
                    if (res.statusCode == 200){
                        if(res.data.rows.length>0){
                            var requestTmpl = doT.template($('#newCarTemple').text());
                            newCarList.html('').append(requestTmpl(res.data.rows));
                            if(res.data.rows.length < pageSize) {
                                refresher.onResherCompeted();
                                upPermit = 1;
                            }
                            wrapper.refresh();
                        }else{
                            $('.js-empty').show();
                            refresher.onEmptyCompeted();
                            wrapper.refresh();
                            $('.pullUpLabel').text('');
                        }
                    }else{
                        vm.page.errorCont(res);
                    }
                });
            }
        },
        page: {
            //搜索
            jumpIndexSearch:function(){
                flyMobile.data({
                    source: 'indexSearch',
                    action: 'indexSearch',
                    actionType: '1',
                    callback:false
                });
            },

            // 二手车情页
            secondCarDetail:function(){
                var params={
                    "userId":$(this).data('id'),
                    "carType":$(this).data('type')
                };
                flyMobile.data({
                    source:'secondCarListDetail',
                    action:'secondCarListDetail',
                    actionType:'1',
                    args:params,
                    callback:false
                });
            },

            // 点击收藏按钮
            jumpCarCollect: function(e){
                var currentItem=$(this),
                    carSourceId = currentItem.data('id'),
                    params ={
                        "param":{
                            "carSourceId":carSourceId,
                            "favAct":1
                        }
                    };

                if(currentItem.hasClass('active')){
                    params.param.favAct = 0
                }else{
                    params.param.favAct = 1
                }
                $.ajax({
                    headers: {'Authorization':tokenValue},
                    type:'post',
                    url:serverApiUrl+'crm/api/user/fav',
                    async:false,
                    contentType:'application/json',
                    data:JSON.stringify(params),
                    dataType:"json",
                    success:function(res){
                        if(res.statusCode == 200){
                            if(params.param.favAct == 1){
                                currentItem.addClass('active');
                                common.toast("收藏" + res.message, '', '', '');
                            }else {
                                currentItem.removeClass('active');
                                common.toast("取消收藏成功", '', '', '');
                            }
                        }else {
                            common.toast("操作失败", '', '', '');
                        }
                    },
                    error:function(e){
                        common.toast(e.message);
                    }
                });
            },

            // 头部导航
            clickScreen: function(e){
                var index = $(this).index();
                $(this).addClass('active').siblings().removeClass('active');
                switch(index){
                    case 0:
                        newCarNavBg.toggle();
                        defaultCont.slideToggle('slow');//默认排序
                        newCarNavBg1.hide();
                        firstCont.hide();//首付
                        newCarNavBg2.hide();
                        monthCont.hide();//月供
                        carBrandBg.hide();
                        carBrandCont.slideUp('slow');//品牌
                        carMoreScreen.hide();
                        navMoreSelect.removeClass('screen-show');//更多筛选
                        break;
                    case 1:
                        newCarNavBg.hide();
                        newCarNavBg1.hide();
                        newCarNavBg2.hide();
                        firstCont.hide();
                        monthCont.hide();
                        defaultCont.hide();
                        carBrandBg.toggle();
                        carBrandCont.slideToggle('slow');//品牌
                        carMoreScreen.hide();
                        navMoreSelect.removeClass('screen-show');//更多筛选
                        var params={"param":"1"};
                        if(clickCarBrand==0){
                            $.ajax({
                                headers: {'Authorization':tokenValue},
                                type:'post',
                                url:serverApiUrl+'car/api/brand/listByLetter',
                                async:false,
                                contentType:'application/json',
                                data:JSON.stringify(params),
                                dataType:"json",
                                success:function(res){
                                    common.hideToast();
                                    var requestTmpl = doT.template($('#selectCarBrandTemple').text());
                                    carBrandCont.html('').append(requestTmpl(res.data));
                                    clickCarBrand=1;
                                },
                                error:function(e){
                                    common.toast(e.message);
                                }
                            });
                        };
                        break;
                    case 2:
                        newCarNavBg1.toggle();
                        firstCont.slideToggle('slow');//首付
                        newCarNavBg.hide();
                        defaultCont.hide();//默认排序
                        newCarNavBg2.hide();
                        monthCont.hide();//月供
                        carBrandBg.hide();
                        carBrandCont.slideUp('slow');//品牌
                        carMoreScreen.hide();
                        navMoreSelect.removeClass('screen-show');//更多筛选
                        break;
                    case 3:
                        newCarNavBg2.toggle();
                        monthCont.slideToggle('slow');//月供
                        newCarNavBg.hide();
                        defaultCont.hide();//默认排序
                        newCarNavBg1.hide();
                        firstCont.hide();//首付
                        carBrandBg.hide();
                        carBrandCont.slideUp('slow');//品牌
                        carMoreScreen.hide();
                        navMoreSelect.removeClass('screen-show');//更多筛选
                        break;
                    case 4:
                        newCarNavBg.hide();
                        newCarNavBg1.hide();
                        newCarNavBg2.hide();
                        firstCont.hide();
                        monthCont.hide();
                        defaultCont.hide();
                        carBrandBg.hide();
                        carBrandCont.slideUp('slow');//品牌
                        carMoreScreen.toggle();
                        navMoreSelect.toggleClass('screen-show');//更多筛选
                        break;
                }
            },

            //参数帅选
            screenParams:function(){
                $.ajax({
                    headers:{'Authorization':tokenValue},
                    type:'post',
                    url:serverApiUrl+'car/api/source/list',
                    async:false,
                    contentType:'application/json',
                    data:JSON.stringify(params),
                    dataType:"json",
                    success:function(res){
                        if(res.data.rows.length>0){
                            var requestTmpl = doT.template($('#newCarTemple').text());
                            newCarList.empty().append(requestTmpl(res.data.rows));
                            $('.js-empty').hide();
                            if (res.data.rows.length < pageSize) {
                                refresher.onResherCompeted();
                                upPermit = 1;
                            } else {
                                refresher.onInitCompeted();
                            }
                            vm.event.pulltoDo();
                        }else{
                            newCarList.empty();
                            $('.js-empty').show();
                            refresher.onEmptyCompeted();
                            wrapper.refresh();
                            $('.pullUpLabel').text('');
                        }
                    },
                    error:function(e){
                        common.hideToast();
                        vm.page.errorPrompt(e);
                    }
                });
            },

            //确定默认排序
            selectDefaultSort:function(e){
                var _this=$(e.currentTarget);
                params.orderBy=_this.attr('data-type');
                params.orderDir=_this.attr('data-order');//默认排序
                params.param.brandId="";//品牌
                _this.addClass('cur').siblings().removeClass('cur');
                newCarNavBg.hide();
                navSelectDetail.find('dl').eq(0).slideUp('slow');
                vm.page.screenParams();
            },

            //确定品牌
            clickSureBrand:function(e){
                var _this=$(e.currentTarget);
                params.orderBy="";
                params.orderDir="";//默认排序
                params.param.beginDownPayments="";
                params.param.endDownPayments="";//首付
                params.param.beginMonthPayments="";
                params.param.endMonthPayments="";//月供
                params.param.brandId=_this.attr('data-id');//品牌
                carBrandBg.hide();
                carBrandCont.slideUp('slow');//品牌
                _this.addClass('cur').siblings().removeClass('cur');
                vm.page.screenParams();
            },

            //确定首付
            sureFirst:function(){
                var firstNum=firstCont.find('dd.cur');
                params.orderBy="";
                params.orderDir="";//默认排序
                params.param.brandId="";//品牌
                params.param.beginMonthPayments="";
                params.param.endMonthPayments="";//月供
                params.param.beginDownPayments=firstNum.attr('data-min');
                params.param.endDownPayments=firstNum.attr('data-max');//首付
                newCarNavBg1.hide();
                firstCont.hide();
                vm.page.screenParams();
            },

            //确定月供
            sureMonth:function(){
                var monthNum=monthCont.find('dd.cur');
                params.orderBy="";
                params.orderDir="";//默认排序
                params.param.brandId="";//品牌
                params.param.beginDownPayments="";
                params.param.endDownPayments="";//首付
                params.param.beginMonthPayments=monthNum.attr('data-min');
                params.param.endMonthPayments=monthNum.attr('data-max');//月供
                newCarNavBg2.hide();
                monthCont.hide();
                vm.page.screenParams();
            },

            //筛选--确定
            navScreen:function(){
                var discountNum=$('.js-service').find('li.cur'),
                    carPriceNum=$('#range_1').val(),
                    carTypeNum=$('.js-model').find('li.cur');
                params.orderBy="";
                params.orderDir="";//默认排序
                params.param.brandId="";//品牌
                params.param.beginDownPayments="";
                params.param.endDownPayments="";//首付
                params.param.beginMonthPayments="";
                params.param.endMonthPayments="";//月供
                params.param.downPaymentsRates=discountNum.attr('data-type');
                params.param.beginSellPrice=carPriceNum.split(";")[0];
                params.param.endSellPrice=carPriceNum.split(";")[1];
                params.param.levelNames=carTypeNum.attr('data-type');//筛选
                carMoreScreen.hide();
                navMoreSelect.removeClass('screen-show');
                vm.page.screenParams();
            },

            //错误提示
            errorCont:function(res){
                $('.js-error').show().find('p').text(res.message);
                refresher.onErrorCompeted();
                $('.pullUpLabel').text('');
                vm.event.pulltoDo();
            },

            //筛选--选择不同条件
            selectType:function(){
                $(this).addClass('cur').siblings().removeClass('cur');
            }
        }
    });

    var addEvent = function(){
        //收藏
        newCarList.on('click', '.js-collect', vm.page.jumpCarCollect);
        //详情页
        newCarList.on('click', '.js-second-detail', vm.page.secondCarDetail);

        //头部导航
        newHeaderNav.on('click', '.js-nav li', vm.page.clickScreen);
        newHeaderNav.on('click', '.js-choose-payment dd,.js-choose-supply dd', vm.page.selectType);

        //关闭筛选
        navMoreSelect.on('click','.js-service li,.js-model li',vm.page.selectType);

        //确定默认排序
        navSelectDetail.on('click',".js-default-select dd",vm.page.selectDefaultSort);

        //确定品牌
        carBrandCont.on('click',".js-brand-item",vm.page.clickSureBrand);

    };

    var dao={
        a:function(){
            $.ajax({
                headers:{'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'car/api/source/list',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(res){
                    if(res.data.rows.length>0) {
                        var requestTmpl = doT.template($('#newCarTemple').text());
                        newCarList.append(requestTmpl(res.data.rows));
                        if (res.data.rows.length < pageSize) {
                            refresher.onResherCompeted();
                            upPermit = 1;
                        } else {
                            refresher.onInitCompeted();
                        }
                        vm.event.pulltoDo();
                    }else {
                        $('.js-empty').show();
                        refresher.onEmptyCompeted();
                        wrapper.refresh();
                        $('.pullUpLabel').text('');
                    }
                },
                error:function(e){
                    common.hideToast();
                    vm.page.errorPrompt(e);
                }
            });
        }
    };

    addEvent();
    dao.a();

    fly.bind(document.body, vm);
});

$("#range_1").ionRangeSlider({
    min:0,
    max:100,
    from:0,
    to:100,
    type:'double',
    step:1,
    prefix:"",
    postfix:"",
    prettify:true,
    hasGrid:true
});