/**
 * @author: xiaomei
 * @date: 2018.6.11
 * @description 车辆管理详情
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'dialog'
], function (doT, flyMobile,dialog){
    var params={'param':''},
        appointId=$('.js-appoint-id'),
        operateDetail=$('.js-o-set'),
        telCont=$('.js-car-phone'),
        operateBg=$('.js-rank-bg');

    //获取参数
    window.getParams = function(res){
        params.param=res.userId;
        dao.getUploadData();
    };

    var vm = window.vm = fly({
        data: {
            sourceName:"",
            vin:"",
            supplierName:"",
            sellPrice: "",
            kilometers: "",
            statusDesc:"",
            optMan: "",
            remark:"",
            optManPhone:"",
            auditResult:"",
            color:"",
            firstOnCard:"",
            ownerDescription:""
        },
        event: {},
        page: {
            //弹框
            confirm:function(str,setting){
                var parameters = {
                    type 	: setting.type,
                    title	: false,
                    content : str,
                    skin	: setting.cls,
                    id		: setting.id,
                    time    : setting.time,
                    move 	: setting.move,
                    shadeClose 	: setting.shadeClose,
                    closeBtn 	: setting.closeBtn,
                    btn 	: setting.btn,
                    success : setting.onLoad,
                    yes     : setting.onSure,
                    cancel  : setting.onCancel
                };
                var defaults = {
                    type 	: 0,
                    title	: '',
                    content : str || '我是提醒框',
                    skin	: '',
                    id		: '',
                    move 	: false,
                    shadeClose 	: false,
                    closeBtn 	: 0,
                    yes 	: function(index, layero){},
                    cancel 	: function(index, layero){},
                    btn2 	: function(index, layero){}
                };
                $.extend(defaults,parameters);
                layer.confirm(str,defaults);
            },

            // 照片上传
            jumpImages: function () {
                $('.js-i-info').addClass('p-show');
            },

            //基本信息
            jumpCarInfo: function () {
                $('.js-b-info').addClass('p-show');
            },

            //手续信息
            jumpCarPro:function(){
                $('.js-p-info').addClass('p-show');
            },

            //返回
            goBack:function(e){
                $(e.currentTarget).parent().removeClass('p-show');
            },

            // 车辆描述
            jumpCarDes:function(){
                $('.js-d-info').addClass('p-show');
            },

            //操作设置
            carOperate:function(){
                operateDetail.addClass('show-operate');
                operateBg.show();
            },

            //关闭操作
            closeOperate:function(e){
                $(e.currentTarget).parent().removeClass('show-operate');
                operateBg.hide();
            },

            //车辆编辑
            clickCarEdit:function(){
                flyMobile.data({
                    source:'carEditSource',
                    action:'carEditSource',
                    args:params,
                    actionType:'1',
                    callback:false
                });
            },

            //车辆轨迹
            clickCarTrail:function(){
                var params={"userId":appointId.attr('data-id')};
                flyMobile.data({
                    source:'carTrail',
                    action:'carTrail',
                    actionType:'1',
                    args:params,
                    callback:false
                });
            },

            // 放弃审核
            clickCancel:function(){
                vm.page.confirm('<h4 class="sure-bomb-cont">是否确认放弃审核？</h4>',{
                    btn:['是','否'],
                    cls:'sure-bomb',
                    onSure:function(){
                        var params={
                            "param":{
                                "id":appointId.attr('data-id'),
                                "accept":2
                            }
                        };
                        flyMobile.data({
                            source:'appointDetail',
                            action:'',
                            actionType:'4',
                            path:'car/api/source/review',
                            args:params,
                            callback:true
                        }).done(function(res){
                            if (res.statusCode == 200){
                                operateBg.hide();
                                operateDetail.removeClass('show-operate');
                                var params={popType:2,jumpData:""};
                                layer.msg('放弃审核成功',function(){
                                    flyMobile.data({
                                        source:'carList',
                                        action:'carList',
                                        args:params,
                                        actionType:'6',
                                        callback:false
                                    });
                                });
                            }else{
                                layer.msg(res.message);
                            }
                        });
                    }
                })
            },

            // 提交审核
            clickComplete:function(){
                vm.page.confirm('<h4 class="sure-bomb-cont">是否确认提交审核？</h4>',{
                    btn:['是','否'],
                    cls:'sure-bomb',
                    onSure:function(){
                        var params={
                            "param":{
                                "reserveId":appointId.attr('data-id'),
                                "status":2
                            }
                        };
                        flyMobile.data({
                            source:'appointDetail',
                            action:'',
                            actionType:'4',
                            path:'crm/api/reserve/updateReserveSale',
                            args:params,
                            callback:true
                        }).done(function(res){
                            if (res.statusCode == 200){
                                operateBg.hide();
                                operateDetail.removeClass('show-operate');
                                var params={popType:2,jumpData:""};
                                layer.msg('提交审核成功',function(){
                                    flyMobile.data({
                                        source:'carList',
                                        action:'carList',
                                        args:params,
                                        actionType:'6',
                                        callback:false
                                    });
                                });
                            }else{
                                layer.msg(res.message);
                            }
                        });
                    }
                })
            },

            callPhone:function(e){
                var params={"phone":$(e.currentTarget).attr('data-type')};
                flyMobile.data({
                    source:'carListDetail',
                    action:'call',
                    actionType:'3',
                    args:params,
                    callback:false
                })
            }
        }
    });
    var dao = {
        //车辆详情
        getUploadData: function(){
            flyMobile.data({
                source:'carListDetail',
                action:'',
                actionType:'4',
                args:params,
                path:'car/api/source/getBasicDetail',
                callback:true
            }).done(function (res){
                if (res.statusCode == 200){
                    vm.data.set('sourceName', res.data.sourceName);
                    vm.data.set('statusDesc', res.data.statusDesc);
                    vm.data.set('vin', res.data.vin);
                    vm.data.set('supplierName', res.data.supplierName);
                    vm.data.set('sellPrice', '¥' + res.data.sellPrice || '0');
                    vm.data.set('kilometers', res.data.kilometers || '0');
                    vm.data.set('optMan', res.data.optMan || "无");
                    vm.data.set('optManPhone', res.data.optManPhone || "无");
                    vm.data.set('auditResult', res.data.auditResult);
                    vm.data.set('remark', res.data.remark || "无");
                    vm.data.set('color', res.data.color);
                    vm.data.set('firstOnCard', res.data.firstOnCard);
                    vm.data.set('ownerDescription', res.data.ownerDescription || "无");
                    telCont.attr('data-type',res.data.optManPhone);
                    appointId.attr('data-id',res.data.id);

                    //图片轮播
                    var bannerTmpl = doT.template($('#detailBannerTemple').text());
                    $('.js-banner-list').html('').append(bannerTmpl(res.data.attachInfoList));
                    var bannerSwiper = new Swiper('.js-banner',{loop:false});

                    //照片
                    var imgTmpl=doT.template($('#detailImgTemple').text());
                    $('.js-img-detail').append(imgTmpl(res.data.attachInfoList));

                    //手续信息
                    var requestTmpl = doT.template($('#formalitiesTemple').text());
                    $('.js-info-detail').append(requestTmpl(res.data.formalitiesMap));

                    //审核状态
                    var examineState=$('.js-examine-state'),
                        stateRemarks=$('.js-remarks'),
                        stateReasons=$('.js-reasons'),
                        examineStateNum=res.data.status;
                    switch(examineStateNum){
                        case 1:
                            examineState.addClass('to-be-audited');
                            stateRemarks.removeClass('examine-explain');
                            break;
                        case 2:
                            examineState.addClass('pass-through');
                            stateRemarks.removeClass('examine-explain');
                            break;
                        case 3:
                            examineState.addClass('no-pass-through');
                            stateReasons.removeClass('examine-explain');
                            $('.js-car-edit').removeClass('hide');
                            $('.js-give-up').removeClass('hide');
                            break;
                    }
                }
            });
        }
    };

    $('.js-phone-detail').on('click','.js-car-phone',vm.page.callPhone);

    fly.bind(document.body, vm);
});
