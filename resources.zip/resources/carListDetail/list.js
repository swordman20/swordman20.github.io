/**
 * @author: xiaomei
 * @date: 2018.6.11
 * @description 车辆管理详情
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'dialog'
], function (doT, flyMobile,dialog){
    var parseUrl=window.location.href,
        getDetailId=parseUrl.split("?userId=")[1],
        params={'param':getDetailId};

    var appointId=$('.js-appoint-id'),
        operateDetail=$('.js-o-set'),
        operateBg=$('.js-rank-bg');

    var vm = window.vm = fly({
        data: {
            sourceName: "",
            vin: "",
            supplierName: "",
            sellPrice: "",
            kilometers: "",
            statusDesc:"",
            optMan: "",
            remark:"",
            optManPhone:"",
            rejectReasons:"",
            color:"",
            firstOnCard:"",
            ownerDescription:""
        },
        event: {},
        page: {
            //弹框
            confirm:function(str,setting){
                var parameters = {
                    type 	: setting.type,
                    title	: false,
                    content : str,
                    skin	: setting.cls,
                    id		: setting.id,
                    time    : setting.time,
                    move 	: setting.move,
                    shadeClose 	: setting.shadeClose,
                    closeBtn 	: setting.closeBtn,
                    btn 	: setting.btn,
                    success : setting.onLoad,
                    yes     : setting.onSure,
                    cancel  : setting.onCancel
                };
                var defaults = {
                    type 	: 0,
                    title	: '',
                    content : str || '我是提醒框',
                    skin	: '',
                    id		: '',
                    move 	: false,
                    shadeClose 	: false,
                    closeBtn 	: 0,
                    yes 	: function(index, layero){},
                    cancel 	: function(index, layero){},
                    btn2 	: function(index, layero){}
                };
                $.extend(defaults,parameters);
                layer.confirm(str,defaults);
            },

            // 照片上传
            jumpImages: function(){
                $('.js-i-info').addClass('p-show');
            },

            //基本信息
            jumpCarInfo: function () {
                $('.js-b-info').addClass('p-show');
            },

            //手续信息
            jumpCarPro:function(){
                $('.js-p-info').addClass('p-show');
            },

            //返回
            goBack:function(e){
                $(e.currentTarget).parent().removeClass('p-show');
            },

            //车辆编辑
            clickCarEdit:function(){
                window.location.href=localhostUrl+"carAddSource/carAddSource.html";
            },

            // 车辆描述
            jumpCarDes:function(){
                $('.js-d-info').addClass('p-show');
            },

            //车辆轨迹
            clickCarTrail:function(){
                var id=appointId.attr('data-id');
                window.location.href=localhostUrl+"carTrail/carTrail.html?userId="+id;
            },

            //操作设置
            carOperate:function(){
                operateDetail.addClass('show-operate');
                operateBg.show();
            },

            //关闭操作
            closeOperate:function(e){
                $(e.currentTarget).parent().removeClass('show-operate');
                operateBg.hide();
            },

            // 放弃审核
            clickCancel:function(){
                vm.page.confirm('<h4 class="sure-bomb-cont">是否确认放弃审核？</h4>',{
                    btn:['是','否'],
                    cls:'sure-bomb',
                    onSure:function(){
                        var params={
                            "param":{
                                "remark":"",
                                "reserveId":$.parseJSON(appointId.attr('data-id')),
                                "status":4
                            }
                        };
                        $.ajax({
                            headers:{'Authorization':tokenValue},
                            type:'post',
                            url:serverApiUrl+'crm/api/reserve/updateReserveSale',
                            async:false,
                            contentType:'application/json',
                            data:JSON.stringify(params),
                            dataType:"json",
                            success:function(res){
                                operateBg.hide();
                                operateDetail.removeClass('show-operate');
                                layer.msg('放弃审核成功');
                            },
                            error:function(e){
                                layer.msg(e.message);
                            }
                        });
                    }
                })
            },

            // 提交审核
            clickComplete:function(){
                vm.page.confirm('<h4 class="sure-bomb-cont">是否确认提交审核？</h4>',{
                    btn:['是','否'],
                    cls:'sure-bomb',
                    onSure:function(){
                        var params={
                            "param":{
                                "remark":"",
                                "reserveId":$.parseJSON(appointId.attr('data-id')),
                                "status":1
                            }
                        };
                        $.ajax({
                            headers:{'Authorization':tokenValue},
                            type:'post',
                            url:serverApiUrl+'crm/api/reserve/updateReserveSale',
                            async:false,
                            contentType:'application/json',
                            data:JSON.stringify(params),
                            dataType:"json",
                            success:function(res){
                                operateBg.hide();
                                operateDetail.removeClass('show-operate');
                                layer.msg('提交审核成功');
                            },
                            error:function(e){
                                layer.msg(e.message);
                            }
                        });
                    }
                })
            }
        }
    });

    var dao = {
        //车辆详情
        getUploadData: function(){
            $.ajax({
                headers:{'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'car/api/source/getBasicDetail',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(res){
                    vm.data.set('sourceName', res.data.sourceName);
                    vm.data.set('statusDesc', res.data.statusDesc);
                    vm.data.set('vin', res.data.vin);
                    vm.data.set('supplierName', res.data.supplierName);
                    vm.data.set('sellPrice', '¥' + res.data.sellPrice || '0');
                    vm.data.set('kilometers', res.data.kilometers || '0');
                    vm.data.set('optMan', res.data.optMan || "无");
                    vm.data.set('optManPhone', res.data.optManPhone || "无");
                    vm.data.set('rejectReasons', res.data.rejectReasons);
                    vm.data.set('remark', res.data.remark || "无");
                    vm.data.set('color', res.data.color);
                    vm.data.set('firstOnCard', res.data.firstOnCard);
                    vm.data.set('ownerDescription', res.data.ownerDescription || "无");
                    $('.js-car-phone').attr('href',"tel:"+res.data.optManPhone);
                    appointId.attr('data-id',res.data.id);

                    //图片轮播
                    var bannerTmpl = doT.template($('#detailBannerTemple').text());
                    $('.js-banner-list').html('').append(bannerTmpl(res.data.attachInfoList));
                    var bannerSwiper = new Swiper('.js-banner',{loop:false});

                    //照片
                    var imgTmpl=doT.template($('#detailImgTemple').text());
                    $('.js-img-detail').append(imgTmpl(res.data.attachInfoList));

                    //手续信息
                    var requestTmpl = doT.template($('#formalitiesTemple').text());
                    $('.js-info-detail').append(requestTmpl(res.data.formalitiesMap));

                    //审核状态
                    var examineState=$('.js-examine-state'),
                        stateRemarks=$('.js-remarks'),
                        stateReasons=$('.js-reasons'),
                        examineStateNum=res.data.status;
                    switch(examineStateNum){
                        case 1:
                            examineState.addClass('to-be-audited');
                            stateRemarks.removeClass('examine-explain');
                            break;
                        case 2:
                            examineState.addClass('pass-through');
                            stateRemarks.removeClass('examine-explain');
                            break;
                        case 3:
                            examineState.addClass('no-pass-through');
                            stateReasons.removeClass('examine-explain');
                            operateDetail.find('li').show();
                            break;
                    }
                }
            });
        }
    };

    dao.getUploadData();

    fly.bind(document.body, vm);
});
