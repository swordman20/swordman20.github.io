/**
 * @author: xiaomei
 * @date: 2018.7.23
 * @description 我的分期
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery'
], function (doT, flyMobile, jquery,common) {

    var vm = window.vm = fly({
        data: {
            modelName:'',
            totalAmount:'',
            totalPeriods:'',
            returnedCount:'',
            currentTotalPlan:'',
            currentPlanDate:''
        },
        page:{
            //我的账单
            jumpMyBill:function (){
                flyMobile.data({
                    source:'myBill',
                    action:'myBill',
                    actionType:'1',
                    callback:false
                })
            },

            //历史账单
            jumpHistoricalBill:function () {
                flyMobile.data({
                    source:'historicalBill',
                    action:'historicalBill',
                    actionType:'1',
                    callback:false
                })
            }
        }
    });
    var dao = {
        //分期详情
        getTotalCar: function(){
            flyMobile.data({
                source:'myStages',
                action:'',
                actionType: '4',
                path:'crm/api/reserve/findMyRefundplan',
                callback:true
            }).done(function(res){
                if(res.statusCode == 200){
                    $('.js-bill-box').removeClass('hide');
                    $('.js-error').addClass('hide');
                    if(res.data.length>0){
                        vm.data.set('modelName', res.data.modelName);
                        vm.data.set('totalAmount', res.data.totalAmount + "元");
                        vm.data.set('totalPeriods', res.data.totalPeriods + "期");
                        vm.data.set('returnedCount', res.data.returnedCount + "期");
                        vm.data.set('currentTotalPlan', "￥" + res.data.currentTotalPlan);
                        vm.data.set('currentPlanDate', res.data.currentPlanDate);
                    }
                }else{
                    common.toast(res.message);
                }
            })
        }
    };

    dao.getTotalCar();

    fly.bind(document.body, vm);
});