/**
 * @author: xiaomei
 * @date: 2018.7.23
 * @description 我的分期
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery'
], function (doT, flyMobile, jquery,common) {

    var vm = window.vm = fly({
        data: {
            modelName:'',
            totalAmount:'',
            totalPeriods:'',
            returnedCount:'',
            currentTotalPlan:'',
            currentPlanDate:''
        },
        page:{
            //我的账单
            jumpMyBill:function (){
                window.location.href=localhostUrl+"myBill/myBill.html";
            },

            //历史账单
            jumpHistoricalBill:function () {
                window.location.href=localhostUrl+"historicalBill/historicalBill.html";
            }
        }
    });
    var dao = {
        //分期详情
        getTotalCar: function(){
           common.showToast();
            $.ajax({
                headers: {'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'crm/api/reserve/findMyRefundplan',
                async:false,
                dataType:"json",
                success:function(res){
                    common.hideToast();
                    vm.data.set('modelName', res.data.modelName);
                    vm.data.set('totalAmount', res.data.totalAmount + "元");
                    vm.data.set('totalPeriods', res.data.totalPeriods + "期");
                    vm.data.set('returnedCount', res.data.returnedCount + "期");
                    vm.data.set('currentTotalPlan', "￥" + res.data.currentTotalPlan);
                    vm.data.set('currentPlanDate', res.data.currentPlanDate);
                },
                error:function(e){
                    common.hideToast();
                    common.toast(e.message);
                }
            });
        }
    };

    dao.getTotalCar();

    fly.bind(document.body, vm);
});