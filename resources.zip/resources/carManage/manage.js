/**
 * @author: xiaomei
 * @date: 2018.6.8
 * @description 车辆管理
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery'
], function (doT, flyMobile, jquery,common) {

    var vm = window.vm = fly({
        data: {
            all:'0',         //全部车辆
            upCount:'0',     //网络在售
            waitCount:'0',   //待审核
            soldCount:'0',   //已售
            passCount:'0',   //审核通过
            downCount:'0'    //已下架
        },
        page:{
            //车辆管理列表
            jumpCarDetail:function(e){
                var selectValue=$(e.currentTarget).data('type');
                window.location.href=localhostUrl+"carList/carList.html";

                //IOS跳转
                // flyMobile.data({
                //     source:'carList',
                //     action:'carList',
                //     actionType:'1',
                //     callback:false
                // });
            },

            // 新增车辆数据
            jumpUploadAdd: function(e){
                window.location.href=localhostUrl+"carAddSource/carAddSource.html";

                //IOS页面跳转
                // flyMobile.data({
                //     source:'carAddSource',
                //     action:'carAddSource',
                //     actionType:'1',
                //     callback:false
                // });
            }
        }
    });

    var dao = {
        //车辆信息
        getTotalCar: function(){
           common.showToast();
            $.ajax({
                headers:{'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'car/api/source/statisList',
                async:false,
                dataType:"json",
                success:function(res){
                    common.hideToast();
                    vm.data.set('all', res.data.all || '0');
                    vm.data.set('soldCount', res.data.soldCount || '0');
                    vm.data.set('waitCount', res.data.waitCount || '0');
                    vm.data.set('upCount', res.data.upCount || '0');
                    vm.data.set('passCount', res.data.passCount || '0');
                    vm.data.set('downCount', res.data.downCount || '0');
                },
                error:function(e){
                    common.hideToast();
                    common.toast(e.message,'','','');
                }
            });
        }
    };
    var init = function(){
        dao.getTotalCar();
    };
    init();
    fly.bind(document.body, vm);
});