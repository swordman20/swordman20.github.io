/**
 * @author: xiaomei
 * @date: 2018.6.15
 * @description 新车详情页
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll'
], function (doT, flyMobile,jquery,common,iscroll){

    var params={"param":284};

    var discountData=$('.js-my-discount-data');

    var vm = window.vm = fly({
        data: {
            defaultDownPayments: "0",
            defaultMonthPayments: "0",
            defaultPeriods: "0",
            carGuidePrice: 0,
            modelName: '',
            carDescription:'',
            cityName:'',
            supplierName:'',
            brandId: '',
            carCollect:"收藏"
        },
        event:{},
        page: {
            //详细配置
            clickCarConfig: function () {
                var params={"userId":discountData.attr('data-id')};
                window.location.href=localhostUrl+"carParameter/carParameter.html";
            },

            // 收藏
            clickCarCollect: function(e){
                var params ={
                    "param":{
                        "carSourceId":"230",
                        "favAct":0
                    }
                },
                _this=$(e.currentTarget);

                if(_this.hasClass('active')){
                    params.param.favAct = 0
                }else{
                    params.param.favAct = 1;
                }

                $.ajax({
                    headers: {'Authorization':tokenValue},
                    type:'post',
                    url:serverApiUrl+'crm/api/user/fav',
                    async:false,
                    contentType:'application/json',
                    data:JSON.stringify(params),
                    dataType:"json",
                    success:function(res){
                        if(params.param.favAct == 0){
                            _this.removeClass('active');
                            vm.data.set('carCollect', '收藏');
                            common.toast("取消收藏成功");
                        }else {
                            _this.addClass('active');
                            vm.data.set('carCollect', '已收藏');
                            common.toast("收藏成功");
                        }
                    },
                    error:function(e){
                        common.toast(e.message);
                    }
                });
            },

            // 预约
            jumpAppointFrom: function () {
                var params={
                    "carUserId":discountData.attr('data-id'),
                    "carUserUrl": discountData.attr('data-url'),
                    "carUserName":discountData.attr('data-name')
                };
                window.location.href=localhostUrl+"goAppoint/goAppoint.html";
            },

            //客服
            clickPhone: function () {
                flyMobile.data({
                    source: 'newCarListDetail',
                    action: 'jumpCustomer',
                    actionType: '3',
                    callback: false
                });
            },

            // 我要优惠
            myDiscount:function(){
                var params={
                    "carUserId":discountData.attr('data-id'),
                    "carUserUrl": discountData.attr('data-url'),
                    "carUserName":discountData.attr('data-name')
                };
                window.location.href=localhostUrl+"carDiscount/carDiscount.html?params="+params;
            },

            // 金融方案
            financeService: function () {
                var params={"userId":discountData.attr('data-id')};
                window.location.href=localhostUrl+"buyStage/buyStage.html";
            },

            // 门店信息
            storeDetail:function(){
                var params={"userId":discountData.attr('data-id')};
                window.location.href=localhostUrl+"carStoreDetail/carStoreDetail.html";
            }
        }
    });
    var dao = {
        //车辆详情
        getCarData: function(){
            $.ajax({
                headers: {'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'car/api/source/detail',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(res){
                    vm.data.set('modelName', res.data.modelName || 0);
                    vm.data.set('carGuidePrice', res.data.carGuidePrice || 0);
                    vm.data.set('carTaxesPrice', res.data.carGuidePrice || 0);
                    vm.data.set('carFirstPrice', (res.data.defaultDownPayments || 0) + "元");
                    vm.data.set('carMonthPrice', (res.data.defaultMonthPayments || 0) + "元");
                    vm.data.set('carWeekPrice', (res.data.defaultPeriods || 0) + "期");
                    vm.data.set('carDescription', res.data.carDescription || "无");
                    vm.data.set('supplierName', res.data.supplierName || "无");
                    discountData.attr('data-id',res.data.id);
                    discountData.attr('data-url',res.data.defaultAttachUrl);
                    discountData.attr('data-name',res.data.modelName);
                    discountData.attr('data-type',res.data.supplierName);

                    //判断是否收藏
                    if(res.data.isFav==0){
                        $('.js-active').removeClass('active');
                        vm.data.set('carCollect', '收藏');
                    }else{
                        $('.js-active').addClass('active');
                        vm.data.set('carCollect', '已收藏');
                    }

                    // 获取基本配置
                    var configData = res.data.basicMapConfig,
                        configHighData = res.data.carLabelInfoList,
                        carPicData = res.data.attachInfoList,
                        bugCarPlan = res.data.carFinancialProductInfoList;

                    var arry = [];
                    for (var i in configData) {
                        var obj = [];
                        if(i=="基本参数"){
                            for(var j in configData[i]){
                                obj.push({name:j, text:configData[i][j]});
                            }
                            arry.push({key:i, value: obj});
                        }
                    }

                    //banner 轮播
                    var bannerTmpl = doT.template($('#detailBannerTemple').text());
                    $('.js-banner-list').html('').append(bannerTmpl(res.data.attachInfoList));
                    var bannerSwiper = new Swiper('.js-banner',{loop:false});

                    //基本参数
                    if(configData.length>0){
                        var configDataTmpl = doT.template($('#configDataTemple').text());
                        $('.js-basic-detail').append(configDataTmpl(arry[0].value));
                    }

                    //配置亮度
                    var configHighDataTmpl = doT.template($('#configHighDataTemple').text());
                    $('.js-config-detail').append(configHighDataTmpl(configHighData));

                    //车辆详怕
                    var carPicDataTmpl = doT.template($('#carPicDataTemple').text());
                    $('.js-pat-detail').append(carPicDataTmpl(carPicData));

                    //购买方案
                    var bugCarPlanTmpl = doT.template($('#bugCarPlanTemple').text());
                    $('.js-car-buy-detail').append(bugCarPlanTmpl(bugCarPlan));
                },
                error:function(e){
                    common.toast(e.message);
                }
            });
        },

        getBrowseData:function(){
            var args={param:{"carSourceId":60}};
            $.ajax({
                headers: {'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'crm/api/user/browse',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(args),
                dataType:"json",
                success:function(res){},
                error:function(e){common.toast(e.message);}
            });
        }
    };

    dao.getCarData();
    dao.getBrowseData();

    fly.bind(document.body, vm);
});
