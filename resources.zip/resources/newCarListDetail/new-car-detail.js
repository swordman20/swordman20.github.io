/**
 * @author: xiaomei
 * @date: 2018.6.15
 * @description 新车详情页
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll'
], function (doT, flyMobile,jquery,common,iscroll){
    var params={"param":''},args={param:{"carSourceId":""}},parameters={"userId":''};
    var discountData=$('.js-my-data');

    var userLogin=false;

    //获取参数
    window.getParams=function(res){
        params.param=res.userId;
        args.param.carSourceId=res.userId;
        parameters.userId=res.userId;
        dao.getCarData();

        var parameter={"userId":res.userId};

        //判断用户信息
        flyMobile.data({
            source:'',
            action:'',
            actionType:'7',
            path:'',
            args:parameter,
            callback:true
        }).done(function(obj){
            //判断是否登录
            var judgeLogin=obj.token;
            if(typeof judgeLogin == "undefined" || judgeLogin == null || judgeLogin == ""){
                userLogin=false;
            }else{
                userLogin=true;
                dao.getBrowseData();
                //判断是否销售
                if(obj.userInfo.userType==2){
                    $('.js-show').addClass('hide');
                    $('.js-hide').removeClass('hide');
                }
            }
        });
    };

    var vm = window.vm = fly({
        data: {
            defaultDownPayments: "0",
            defaultMonthPayments: "0",
            defaultPeriods: "0",
            sourceName: '',
            carDescription:'',
            cityName:'',
            supplierName:'',
            brandId: '',
            carCollect:"收藏"
        },
        event:{},
        page: {
            //详细配置
            clickCarConfig: function () {
                var params={"userId":discountData.attr('data-id')};
                flyMobile.data({
                    source:'carParameter',
                    action:'carParameter',
                    actionType:'1',
                    args:params,
                    callback: false
                });
            },

            // 关注
            clickCarCollect:function(e){
                var args ={
                        "param":{
                            "carSourceId":discountData.attr('data-id'),
                            "favAct":0
                        }
                    },
                    _this=$(e.currentTarget);

                if(userLogin==false){
                    flyMobile.data({
                        source: 'myIndex',
                        action: 'jumpLogin',
                        actionType: '3',
                        args:parameters,
                        callback: false
                    });
                }else{
                    if(_this.hasClass('active')){
                        args.param.favAct = 0
                    }else{
                        args.param.favAct = 1;
                    }

                    flyMobile.data({
                        source:'newCarListDetail',
                        action:'',
                        actionType:'4',
                        path:'crm/api/user/fav',
                        args:args,
                        callback: true
                    }).done(function (res) {
                        if(res.statusCode == 200){
                            if(args.param.favAct == 0){
                                _this.removeClass('active');
                                vm.data.set('carCollect', '收藏');
                                common.toast("取消收藏成功");
                            }else {
                                _this.addClass('active');
                                vm.data.set('carCollect', '已收藏');
                                common.toast("收藏成功");
                            }
                        }else{
                            common.toast("操作失败");
                        }
                    });
                }
            },

            // 预约
            jumpAppointFrom: function () {
                var params={
                    "carUserId":discountData.attr('data-id'),
                    "carUserUrl": discountData.attr('data-url'),
                    "carUserName":discountData.attr('data-name')
                };
                if(userLogin==false){
                    flyMobile.data({
                        source: 'myIndex',
                        action: 'jumpLogin',
                        actionType: '3',
                        args:parameters,
                        callback: false
                    });
                }else{
                    flyMobile.data({
                        source:'goAppoint',
                        action:'goAppoint',
                        actionType:'1',
                        args:params,
                        callback:false
                    });
                }
            },

            //客服
            clickPhone:function(){
                var params={"phone":"4008761010"};
                flyMobile.data({
                    source:'newCarListDetail',
                    action:'call',
                    args:params,
                    actionType:'3',
                    callback: false
                });
            },

            // 我要优惠
            myDiscount: function(){
                var params={
                    "carUserId":discountData.attr('data-id'),
                    "carUserUrl": discountData.attr('data-url'),
                    "carUserName":discountData.attr('data-name')
                };
                             
                if(userLogin==false){
                    flyMobile.data({
                        source: 'myIndex',
                        action: 'jumpLogin',
                        actionType: '3',
                        args:parameters,
                        callback: false
                    });
                }else{
                    flyMobile.data({
                        source:'carDiscount',
                        action:'carDiscount',
                        args:params,
                        actionType:'1',
                        callback:false
                    });
                }
            },

            // 金融方案
            financeService: function(){
                var params={"userId":discountData.attr('data-id')};
                flyMobile.data({
                    source:'buyStage',
                    action:'buyStage',
                    args:params,
                    actionType:'1',
                    callback:false
                });
            },

            // 门店信息
            storeDetail: function () {
                var params={
                    "userId":discountData.attr('data-store'),
                    "userType":discountData.attr('data-type'),
                    "userCityName":discountData.attr("data-city")
                };
                flyMobile.data({
                    source:'carStoreDetail',
                    action:'carStoreDetail',
                    args:params,
                    actionType: '1',
                    callback: false
                });
            }
        }
    });
    var dao = {
        //车辆详情
        getCarData: function(){
            common.showToast();
            flyMobile.data({
                source:'newCarListDetail',
                action:'',
                actionType:'4',
                path:'car/api/source/detail',
                args:params,
                callback: true
            }).done(function (res) {
                common.hideToast();
                if(res.statusCode == 200){
                    vm.data.set('modelName', res.data.modelName || 0);
                    vm.data.set('carGuidePrice', res.data.carGuidePrice || 0);
                    vm.data.set('carFirstPrice', (res.data.defaultDownPayments || 0) + "元");
                    vm.data.set('carMonthPrice', (res.data.defaultMonthPayments || 0) + "元");
                    vm.data.set('carWeekPrice', (res.data.defaultPeriods || 0) + "期");
                    vm.data.set('carDescription', res.data.carDescription || "无");
                    vm.data.set('supplierName', res.data.supplierName || "无");
                    discountData.attr('data-id',res.data.id);
                    discountData.attr('data-store',res.data.supplierId);
                    discountData.attr('data-url',res.data.defaultAttachUrl);
                    discountData.attr('data-name',res.data.modelName);
                    discountData.attr('data-type',res.data.supplierName);
                    discountData.attr("data-city",res.data.cityName);

                    //判断是否收藏
                    if(res.data.isFav==0){
                        $('.js-active').removeClass('active');
                        vm.data.set('carCollect', '收藏');
                    }else{
                        $('.js-active').addClass('active');
                        vm.data.set('carCollect', '已收藏');
                    }

                    // 获取基本配置
                    var configData = res.data.basicMapConfig,
                        configHighData = res.data.carLabelInfoList,
                        carPicData = res.data.attachInfoList,
                        bugCarPlan = res.data.carFinancialProductInfoList;

                    var arry = [];
                    for (var i in configData){
                        var obj = [];
                        if(i=="基本参数"){
                            for(var j in configData[i]){
                                obj.push({name:j, text:configData[i][j]});
                            }
                            arry.push({key:i, value: obj});
                        }
                    }

                    //banner 轮播
                    var bannerTmpl = doT.template($('#detailBannerTemple').text());
                    $('.js-banner-list').html('').append(bannerTmpl(res.data.attachInfoList));
                    var bannerSwiper = new Swiper('.js-banner',{loop:false});

                    //基本参数
                    var configDataTmpl = doT.template($('#configDataTemple').text());
                    $('.js-basic-detail').append(configDataTmpl(arry[0].value));

                    //配置亮度
                    var configHighDataTmpl = doT.template($('#configHighDataTemple').text());
                    $('.js-config-detail').append(configHighDataTmpl(configHighData));

                    //车辆详怕
                    var carPicDataTmpl = doT.template($('#carPicDataTemple').text());
                    $('.js-pat-detail').append(carPicDataTmpl(carPicData));

                    //购买方案
                    var bugCarPlanTmpl = doT.template($('#bugCarPlanTemple').text());
                    $('.js-car-buy-detail').append(bugCarPlanTmpl(bugCarPlan));

                }else{
                    common.toast(res.message);
                }
            })
        },

        //获取浏览记录
        getBrowseData:function(){
            flyMobile.data({
                source:'newCarListDetail',
                action:'',
                actionType:'4',
                path:'crm/api/user/browse',
                args:args,
                callback: true
            }).done(function(res){
                if(res.statusCode != 200){
                    common.toast(res.message);
                }
            })
        }
    };
    fly.bind(document.body, vm);
});
