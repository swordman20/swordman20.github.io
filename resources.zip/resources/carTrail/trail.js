/**
 * @author: xiaomei
 * @date: 2018.6.8
 * @description 车辆轨迹
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery'
], function (doT,flyMobile,jquery,common){

    var params={'param':''};

    //获取参数
    window.getParams = function(res){
        params.param=res.userId;
        dao.getTotalCar();
    };

    var vm = window.vm = fly({
        data:{}
    });
    var dao = {
        //获取轨迹详情
        getTotalCar:function(){
           common.showToast();
            flyMobile.data({
                source:'carTrail',
                action:'',
                actionType:'4',
                path:'car/api/source/listCarOptRecord',
                args:params,
                callback:true
            }).done(function(res){
                common.hideToast();
                if(res.statusCode == 200){
                    if(res.data.length>0){
                        var requestTmpl = doT.template($('#uploadListTemple').text());
                        $('.js-history-detail').append(requestTmpl(res.data));
                    }else{
                        $('.js-empty').show();
                    }
                }else{
                    common.toast(res.message);
                }
            });
        }
    };

    fly.bind(document.body, vm);
});