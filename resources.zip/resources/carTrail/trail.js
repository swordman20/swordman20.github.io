/**
 * @author: xiaomei
 * @date: 2018.6.8
 * @description 车辆轨迹
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery'
], function (doT,flyMobile,jquery,common){

    var parseUrl=window.location.href,
        getDetailId=parseUrl.split("?userId=")[1],
        params={'param':230};

    var vm = window.vm = fly({
        data: {
            newCarList:[]
        }
    });
    var dao = {
        //获取轨迹详情
        getTotalCar:function(){
            common.showToast();
            $.ajax({
                headers:{'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'car/api/source/listCarOptRecord',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(res){
                    common.hideToast();
                    if(res.data.length>0){
                        var requestTmpl = doT.template($('#uploadListTemple').text());
                        $('.js-history-detail').append(requestTmpl(res.data));
                    }else{
                        $('.js-empty').show();
                    }
                },
                error:function(e){
                    common.hideToast();
                    common.toast(e.message);
                }
            });
        }
    };

    dao.getTotalCar();

    fly.bind(document.body, vm);
});