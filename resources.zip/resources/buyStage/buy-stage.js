/**
 * @author: xiaomei
 * @date: 2018.7.6
 * @description 分期购
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll'
], function (doT, flyMobile,jquery,common,iscroll){
    var params ={"param":''};

    //获取参数
    window.getParams=function(res){
        params.param=res.userId;
        dao.getCarData();
    };

    var planList=$('.js-plan-list'),
        rateTabs=$('.js-rate-tabs'),
        rateCont=$('.js-plan-title'),
        rateNoData=$('.js-no-plan-title');

    var vm = window.vm = fly({
        data:{
            planPrice:'0'
        },
        event:{},
        page:{
            //tabs点击
            tabsSwitch:function(){
                $(this).addClass('cur').siblings('li').removeClass('cur');
                var tabsIndex=$(this).attr('data-type');
                if(tabsIndex==1){
                    planList.find('.js-one').removeClass('cont-hide');
                    var planListOne=planList.find('.js-one').attr('data-order');
                    if(typeof planListOne == "undefined" || planListOne == null || planListOne == ""){
                        rateNoData.show();
                        rateCont.hide();
                    }else{
                        rateCont.show();
                        rateNoData.hide();
                        vm.data.set('planPrice',planListOne);
                    }
                    planList.find('.js-two,.js-three,.js-four').addClass('cont-hide');
                }else if(tabsIndex==2){
                    planList.find('.js-two').removeClass('cont-hide');
                    var planListTwo=planList.find('.js-two').attr('data-order');
                    if(typeof planListTwo == "undefined" || planListTwo == null || planListTwo == ""){
                        rateNoData.show();
                        rateCont.hide();
                    }else{
                        rateCont.show();
                        rateNoData.hide();
                        vm.data.set('planPrice',planListTwo);
                    }
                    planList.find('.js-one,.js-three,.js-four').addClass('cont-hide');
                }else if(tabsIndex==3){
                    planList.find('.js-three').removeClass('cont-hide');
                    var planListThree=planList.find('.js-three').attr('data-order');
                    if(typeof planListThree == "undefined" || planListThree == null || planListThree == ""){
                        rateNoData.show();
                        rateCont.hide();
                    }else{
                        rateCont.show();
                        rateNoData.hide();
                        vm.data.set('planPrice',planListThree);
                    }
                    planList.find('.js-two,.js-one,.js-four').addClass('cont-hide');
                }else{
                    planList.find('.js-four').removeClass('cont-hide');
                    var planListFour=planList.find('.js-four').attr('data-order');
                    if(typeof planListFour == "undefined" || planListFour == null || planListFour == ""){
                        rateNoData.show();
                        rateCont.hide();
                    }else{
                        rateCont.show();
                        rateNoData.hide();
                        vm.data.set('planPrice',planListFour);
                    }
                    planList.find('.js-two,.js-three,.js-one').addClass('cont-hide');
                }
            }
        }
    });
    var dao = {
        //分期详情
        getCarData: function(){
            common.showToast();
            flyMobile.data({
                source:'buyStage',
                action:'',
                actionType:'4',
                path:'car/api/source/detail',
                args:params,
                callback:true
            }).done(function(res){
                common.hideToast();
                if(res.statusCode == 200){
                    var bugCarPlan = res.data.carFinancialProductInfoList;
                    var bugCarPlanTmpl = doT.template($('#bugCarPlanTemple').text());
                    $('.js-plan-list').append(bugCarPlanTmpl(bugCarPlan));
                    if(bugCarPlan[0].downPaymentsRate=="25%"){
                        rateCont.show();
                        rateNoData.hide();
                        vm.data.set('planPrice',bugCarPlan[0].downPayments);
                    }else{
                        rateNoData.show();
                        rateCont.hide();
                    }
                }else{

                    common.toast(res.message);
                }
            })
        }
    };

    rateTabs.on('click','li',vm.page.tabsSwitch);

    fly.bind(document.body, vm);
});
