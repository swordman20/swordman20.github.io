/**
 * @author: xiaomei
 * @date: 2018.8.20
 * @description 选择车辆名称
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll'
], function (doT, flyMobile, jquery, common,iscroll){

    var selectAllCar=$('.js-all-car'),
        carSystem=$('.js-car-system'),
        carSystemDetail=$('.js-system-car'),
        carType=$('.js-car-type'),
        bgColor=$('.js-rank-bg'),
        bgColor1=$('.js-rank-bg1');

    var vm = window.vm = fly({
        data:{},
        event:{},
        page:{
            //选择车系
            jumpCarName:function(e){
                var params={"param":$(e.currentTarget).attr('data-id')};
                $(e.currentTarget).addClass('active').siblings('li').removeClass('active');
                $(e.currentTarget).parent().siblings().find('li').removeClass('active');
                carSystem.addClass('p-show');
                $('body').addClass('no-scroll');
                bgColor.show();
                flyMobile.data({
                    source:'carSelectName',
                    action:'',
                    actionType:'4',
                    args:params,
                    path:'car/api/series/list',
                    callback:true
                }).done(function (res){
                    if(res.statusCode == 200){
                        var requestTmpl = doT.template($('#carSystemTemple').text());
                        carSystemDetail.html('').append(requestTmpl(res.data));
                    }else{
                        common.toast(res.message);
                    }
                });
            },

            //选择车型
            jumpCarType:function(e){
                var params={"param":$(e.currentTarget).attr('data-id')};
                $(e.currentTarget).addClass('active').siblings('li').removeClass('active');
                carType.addClass('p-show');
                carSystem.addClass('no-scroll');
                bgColor1.show();
                flyMobile.data({
                    source:'carSelectName',
                    action:'',
                    actionType:'4',
                    args:params,
                    path:'car/api/model/listByYear',
                    callback:true
                }).done(function (res){
                    if(res.statusCode == 200){
                        var requestTmpl = doT.template($('#carTypeTemple').text());
                        carType.html('').append(requestTmpl(res.data));
                    }else{
                        common.toast(res.message);
                    }
                });
            },

            //关闭车型
            closeCarType:function(){
                bgColor1.hide();
                carType.removeClass('p-show');
                carSystem.removeClass('no-scroll');
            },

            //关闭车系
            closeCarSystem:function(){
                carSystem.removeClass('p-show');
                $('body').removeClass('no-scroll');
                bgColor.hide();
            },

            //确认车型
            jumpSureCarType:function(e){
                var params={"carName":$(e.currentTarget).attr('data-name')};
                $(e.currentTarget).addClass("active");
                flyMobile.data({
                    source:'carAddSource',
                    action:'carAddSource',
                    actionType:'6',
                    args:params,
                    callback:false
                });
            }
        }
    });
    var dao = {
        getCarName:function(){
            common.showToast();
            flyMobile.data({
                source:'carSelectName',
                action:'',
                actionType:'4',
                path:'car/api/brand/listByLetter',
                callback:true
            }).done(function (res){
                common.hideToast();
                if(res.statusCode == 200){
                    var requestTmpl = doT.template($('#selectCarTemple').text());
                    selectAllCar.append(requestTmpl(res.data));
                }else{
                    common.toast(res.message);
                }
            });
        }
    };
    var addEvent = function(){
        selectAllCar.on('click','.js-all-item',vm.page.jumpCarName);
        carSystemDetail.on('click','li.js-system',vm.page.jumpCarType);
        carType.on('click','.js-type-item',vm.page.jumpSureCarType);
    };

    dao.getCarName();
    addEvent();

    fly.bind(document.body, vm);
});
