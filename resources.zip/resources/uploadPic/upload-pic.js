/**
 * @author: xiaomei
 * @date: 2018.6.8
 * @description 上传照片
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'serverUrl',
    'jquery',
    'iscroll'
], function (doT,flyMobile,jquery,serverUrl,iscroll){

    var vm = window.vm = fly({
        event:{},
        page: {
            // tabs切换
            tabsSwitch: function(){

            }
        }
    });
    var init = function () {
        $('.car-list').on('click', '.car-li', vm.page.tabsSwitch);
    };
    init();
    fly.bind(document.body, vm);
});