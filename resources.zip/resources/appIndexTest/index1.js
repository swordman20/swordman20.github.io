/**
 * @author: xiaomei
 * @date: 2018.6.21
 * @description 首页
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll'
], function (doT, flyMobile, jquery, common,iscroll){

    var headerCont=$('.js-header');
    //头部滚动
    $(window).scroll(function(){
        var scroll_top=$(window).scrollTop();
        if(scroll_top>=100){
            headerCont.addClass('header-bg');
        }else{
            headerCont.removeClass('header-bg');
        }
    });

    //获取数据
    var params={"getPageData":[{
            "action":"banner",
            "url":"third/api/banner/queryBannerList",
            "params":{
                "param":"banner"
            }
        },{
            "action":"selectedCar",
            "url":"car/api/source/list",
            "params":{
                "orderBy":"upDate",
                "orderDir":"desc",
                "pageNo":0,
                "pageSize":10,
                "param":{
                    "isFeatured":1
                }
            }
        },{
            "action":"qualityCar",
            "url":"car/api/source/list",
            "params":{
                "orderBy":"upDate",
                "orderDir":"desc",
                "pageNo":0,
                "pageSize":10,
                "param":{
                    "isQuality": 1
                }
            }
        }
        ]};

    flyMobile.data({
        args:params,
        callback:true
    }).done(function(res){
    console.log(res);
        //这个是进入页面主动请求数据

        // res= JSON.parse(res);
        // if (res.statusCode == 200){
        //     var requestTmpl = doT.template($('#homeBannerTemple').text());
        //     $('.js-banner-list').html('').append(requestTmpl(res.data));
        //     var bannerSwiper = new Swiper('.js-banner',{
        //         loop:true,
        //         autoplay:3000,
        //         speed:50
        //     });
        //     //禁止播放
        //     if (res.data.length < 2) {
        //         bannerSwiper.autoplay=false;
        //     }
        // }
    });

    //好车一周精选
    window.getJinpinData=function(res){
        var requestTmpl = doT.template($('#newCarTemple').text());
        var resData = res.message,
            resJson= JSON.parse(resData);
        res = resJson.data.rows;
        if (resJson.statusCode == 200){
            $('.js-week-list').html('').append(requestTmpl(res.slice(0,4)));
        }
    };

    //品质二手车
    window.getQualityData = function(res){
        common.showToast();
        var requestTmpl = doT.template($('#newCarTemple').text());
        var resData = res.message,
            resJson= JSON.parse(resData);
        res = resJson.data.rows;
        if (resJson.statusCode == 200){
            common.hideToast();
            $('.js-second-car').html('').append(requestTmpl(res.slice(0,4)));
        }
    };

    //好车问答
    window.getFindProblemsData = function(res){
        common.showToast();
        var requestTmpl = doT.template($('#questionTemple').text());
        var resData = res.message;
        res = JSON.parse(resData);
        if (res.statusCode == 200){
            common.hideToast();
            $('.js-question-list').html('').append(requestTmpl(res.data));
        }
    };

    var vm = window.vm = fly({
        data:{},
        event:{},
        page:{
            //搜索
            jumpIndexSearch:function(){
                flyMobile.data({
                    source: 'indexSearch',
                    action: 'indexSearch',
                    actionType: '1',
                    callback:false
                });
            },

            //新车团购
            jumpNewCarList: function(e){
                // flyMobile.data({
                //     source: 'appIndex',
                //     action: 'jumpNewCarList',
                //     actionType: '3',
                //     callback:false
                // });
                //跳转到新车页面
                var params={"source":"appIndexTest/appIndexTest.html",
                        "uri":"newCarList/newCarList.html",
                        "params":{}
                };

                flyMobile.data({
                    args:params,
                    callback:false
                })

            },

            //新车筛选
            jumpParameterNewList:function(){
                var typeCont = $(this).data('type'),
                    sortCont=$(this).data('order');
                var params={
                    typeCont:typeCont,
                    orderDir:sortCont
                };
                flyMobile.data({
                    source:'appIndex',
                    action:'jumpNewCarList',
                    args:params,
                    actionType:'3',
                    callback:false
                });
            },

            // 优选二手车
            jumpSecondCarList: function (e) {
                //跳转到二手车页面
                var params={"source":"appIndexTest/appIndexTest.html",
                    "uri":"secondCarList/secondCarList.html",
                    "params":{}
                };

                flyMobile.data({
                    args:params,
                    callback:false
                })

                // flyMobile.data({
                //     source: 'appIndex',
                //     action: 'jumpSecondCarList',
                //     actionType: '3',
                //     callback:false
                // });
            },

            //车主服务
            jumpCarService: function(e){
                flyMobile.data({
                    source: 'carService',
                    action: 'carService',
                    actionType: '1',
                    callback: false
                });
            },

            // 领劵中心
            jumpVoucherCenter: function(e){
                flyMobile.data({
                    source: 'voucherCenter',
                    action: 'voucherCenter',
                    actionType: '1',
                    callback: false
                });
            },

            // 帮助与支持
            jumpQuestionList: function(e){
                flyMobile.data({
                    source:'helpSupport',
                    action:'helpSupport',
                    actionType:'1',
                    callback:false
                });
            },

            // 新车详情页
            jumpCarDetail: function (e){
                var id = $(this).data('id');
                var params={
                    id:id
                };
                flyMobile.data({
                    source: 'newCarListDetail',
                    action: 'newCarListDetail',
                    actionType: '1',
                    args:params,
                    callback: false
                });
            },

            // 二手车详情页
            jumpCarSecondDetail: function (e){
                var id = $(this).data('id');
                var params={
                    id:id
                };
                flyMobile.data({
                    source: 'secondCarListDetail',
                    action: 'secondCarListDetail',
                    actionType: '1',
                    args:params,
                    callback: false
                });
            },

            // 跳转到合肥区域页面
            jumpAreaSelect: function(e){
                var area = $(e.currentTarget).data('id');
                flyMobile.data({
                    source:'appIndex',
                    action:'jumpAreaSelect',
                    actionType:'3',
                    args:area,
                    callback:false
                });
            },

            // 跳转到车辆搜索页面
            jumpCarSearch: function(e){
                flyMobile.data({
                    source: 'carSearch',
                    action: 'carSearch',
                    actionType: '1',
                    callback: false
                });
            },

            //好车问答效果
            goodCarQuestion:function(){
                $(this).siblings('p').slideToggle('slow');
                $(this).parent('li').find('p').slideUp();
                if($(this).find('span').hasClass('cur')){
                    $(this).find('span').removeClass('cur');
                }else{
                    $(this).find('span').addClass('cur');
                }
            }
        }
    });

    $('.js-question-list').on('click','li .js-question',vm.page.goodCarQuestion);

    fly.bind(document.body, vm);
});