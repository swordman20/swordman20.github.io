/**
 * @author: xiaomei
 * @date: 2018.6.20
 * @description 帮助和支持
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery'
], function (doT, flyMobile, jquery,common) {
    var searchList=$('.js-search'),
        selectListCont=$('.js-select-list'),
        sureCont=$('.js-sure-cont'),
        searchDetail=$('.js-search-input'),
        searchHot=$('.js-search-hot');

    searchDetail.focus();
    var params={"param":'2'};

    var vm = window.vm = fly({
        page: {
            //新车、二手车
            jumpAreaSelect:function(){
                selectListCont.toggleClass('search-show');
            },

            //选择新车、二手车
            selectCar:function(e){
                var _this=$(e.currentTarget);
                selectListCont.removeClass('search-show');
                sureCont.html(_this.attr('data-name'));
                if(_this.attr('data-name')=="新车"){
                    params.param=1
                }else{
                    params.param=2
                }
                dao.getQuestionData();
            },

            //搜索
            sureSearchCont:function(){
                var searchText=searchDetail.val();
                if(!$.trim(searchText)){
                    common.toast('请输入内容');
                }else{

                }
            },

            //取消
            jumpInforList:function(){
                window.history.go(-1);
            }
        }
    });

    var dao={
        //好车问答列表
        getQuestionData:function(){
            $.ajax({
                headers: {'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'car/api/search/findHotLabel',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(e){
                    var configDataTmpl = doT.template($('#carHotTemple').text());
                    searchHot.empty().append(configDataTmpl(e.data));
                },
                error:function(e){
                    common.hideToast();
                    common.toast(e.message);
                }
            });
        }
    };

    dao.getQuestionData();
    searchList.on('click','li',vm.page.selectCar);

    fly.bind(document.body, vm);
});