/**
 * @author: xiaomei
 * @date: 2018.6.20
 * @description 帮助和支持
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery'
], function (doT, flyMobile, jquery,common) {
    var searchList=$('.js-search'),
        selectListCont=$('.js-select-list'),
        sureCont=$('.js-sure-cont'),
        homeSureCont=$('.js-car-cont'),
        homeSearch=$('.js-home'),
        searchDetail=$('.js-search-input'),
        searchHot=$('.js-search-hot');
    var params={"param":''};

    //获取参数
    window.getParams = function(obj){
        if(obj.searchCarType==2){
            homeSureCont.html('二手车');
            params.param=2;
        }else if(obj.searchCarType==1){
            homeSureCont.html('新车');
            params.param=1;
        }else{
            homeSearch.removeClass('hide');
            homeSureCont.addClass('hide');
            params.param=1;
        }
        dao.getHotData();
    };

    searchDetail.focus();

    var vm = window.vm = fly({
        page: {
            //新车、二手车
            jumpAreaSelect:function(){
                selectListCont.toggleClass('search-show');
            },

            //选择新车、二手车
            selectCar:function(e){
                var _this=$(e.currentTarget);
                selectListCont.removeClass('search-show');
                sureCont.html(_this.attr('data-name'));
                if(_this.attr('data-name')=="新车"){
                    params.param=1
                }else{
                    params.param=2
                }
                dao.getHotData();
            },

            //搜索
            sureSearchCont:function(){
                var searchText=searchDetail.val();
                if(!$.trim(searchText)){
                    common.toast('请输入内容');
                }else{
                    var params={popType:3,jumpData:{isHome:"",carType:"",searchText:searchText}};
                    if(homeSearch.hasClass('hide')){
                        params.jumpData.isHome=0;
                        if(homeSureCont.html()=="新车"){
                            params.jumpData.carType=1
                        }else{
                            params.jumpData.carType=2
                        }
                    }else{
                        params.jumpData.isHome=1;
                        if(sureCont.html()=="新车"){
                            params.jumpData.carType=1
                        }else{
                            params.jumpData.carType=2
                        }
                    }
                    flyMobile.data({
                        source: 'newCarList',
                        action: 'newCarList',
                        args:params,
                        actionType: '6',
                        callback:false
                    });
                }
            },

            //热门搜索
            sureHotCar:function(e){
                var params={popType:3,jumpData:{isHome:"",carType:"",searchText:$(e.currentTarget).attr('data-name')}};
                if(homeSearch.hasClass('hide')){
                    params.jumpData.isHome=0;
                    if(homeSureCont.html()=="新车"){
                        params.jumpData.carType=1
                    }else{
                        params.jumpData.carType=2
                    }
                }else{
                    params.jumpData.isHome=1;
                    if(sureCont.html()=="新车"){
                        params.jumpData.carType=1
                    }else{
                        params.jumpData.carType=2
                    }
                }
                flyMobile.data({
                    source: 'newCarList',
                    action: 'newCarList',
                    args:params,
                    actionType: '6',
                    callback:false
                });
            }
        }
    });

    var dao={
        //热门标签
        getHotData:function(){
            flyMobile.data({
                source:'indexSearch',
                action:'',
                actionType:'4',
                path:'car/api/search/findHotLabel',
                args:params,
                callback: true
            }).done(function(e){
                if(e.statusCode == 200){
                    if(e.data.length>0){
                        var configDataTmpl = doT.template($('#carHotTemple').text());
                        searchHot.html('').append(configDataTmpl(e.data));
                    }else{
                        $('.js-no-data').show();
                    }
                }else{
                    common.toast(e.message);
                }
            })
        }
    };

    searchList.on('click','li',vm.page.selectCar);
    searchHot.on('click','li',vm.page.sureHotCar);

    fly.bind(document.body, vm);
});