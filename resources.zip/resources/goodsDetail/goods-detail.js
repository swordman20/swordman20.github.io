/**
 * @author: xiaomei
 * @date: 2018.11.09
 * @description 商品详情页
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll'
], function (doT, flyMobile,jquery,common,iscroll){
    var params={"param":'3'},discountData=$('.js-my-data'),parameters={"userId":''};
    var userLogin=false;

    //获取参数
    window.getParams=function(e){
        params.param=e.goodsId;
        parameters.userId=e.goodsId;
        discountData.attr('data-id',e.goodsId);
        dao.getGoodsData();
        var parameter={"userId":e.goodsId};

        //判断用户信息
        flyMobile.data({
            source:'',
            action:'',
            actionType:'7',
            path:'',
            args:parameter,
            callback:true
        }).done(function(obj){
            //判断是否登录
            var judgeLogin=obj.token;
            if(typeof judgeLogin == "undefined" || judgeLogin == null || judgeLogin == ""){
                userLogin=false;
            }else{
                userLogin=true;
            }
        });

    };

    var vm = window.vm = fly({
        data: {
            goodsTitle:"",
            goodsLabel:"",
            goodsPrice:"",
            carCollect:"收藏"
        },
        event:{},
        page: {
            //收藏
            goodsDetailCollect:function(e){
                var args ={
                        "param":{
                            "goodsId":3/*discountData.attr('data-id')*/,
                            "favAct":0
                        }
                    },
                    _this=$(e.currentTarget);

                // if(userLogin==false){
                //     flyMobile.data({
                //         source:'goodsDetail',
                //         action:'jumpLogin',
                //         actionType: '3',
                //         args:parameters,
                //         callback:false
                //     });
                // }else{
                    if(_this.hasClass('active')){
                        args.param.favAct = 0
                    }else{
                        args.param.favAct = 1;
                    }
                    $.ajax({
                        headers:{'Authorization':tokenValue},
                        type:'post',
                        url:serverApiUrl+'goods/service/saveGoodsUserFav',
                        async:false,
                        contentType:'application/json',
                        data:JSON.stringify(args),
                        dataType:"json",
                        success:function(obj){
                            if(obj.statusCode == 200){
                                if(args.param.favAct == 0){
                                    _this.removeClass('active');
                                    vm.data.set('carCollect', '收藏');
                                    common.toast("取消收藏成功");
                                }else {
                                    _this.addClass('active');
                                    vm.data.set('carCollect', '已收藏');
                                    common.toast("收藏成功");
                                }
                            }else{
                                common.toast("操作失败");
                            }
                        }
                    });
                // }
            },

            //客服
            callPhone:function(){
                var params={"phone":"4008761010"};
                flyMobile.data({
                    source:'newCarListDetail',
                    action:'call',
                    args:params,
                    actionType:'3',
                    callback: false
                });
            },

            // 预约
            goToAppoint:function(){
                var params={
                    "carUserId":discountData.attr('data-id'),
                    "carUserUrl": discountData.attr('data-url'),
                    "carUserName":discountData.attr('data-name')
                };
                if(userLogin==false){
                    flyMobile.data({
                        source: 'myIndex',
                        action: 'jumpLogin',
                        actionType: '3',
                        args:parameters,
                        callback: false
                    });
                }else{
                    flyMobile.data({
                        source:'goAppoint',
                        action:'goAppoint',
                        actionType:'1',
                        args:params,
                        callback:false
                    });
                }
            }
        }
    });

    var dao = {
        getGoodsData:function(){
            common.showToast();
            $.ajax({
                headers:{'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'goods/service/getGoodsDetail',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(obj){
                    common.hideToast();
                    if(obj.statusCode == 200){
                        //banner 轮播
                        var bannerTemple = doT.template($('#detailBannerTemple').text());
                        $('.js-banner-list').html('').append(bannerTemple(obj.data.attachList));
                        var bannerSwiper = new Swiper('.js-banner',{loop:false});

                        vm.data.set('goodsTitle', obj.data.name || "无");
                        vm.data.set('goodsLabel', obj.data.subDesc || "无");
                        vm.data.set('goodsPrice', obj.data.marketPrice || "0");

                        //判断是否收藏
                        if(obj.data.isFav==0){
                            $('.js-active').removeClass('active');
                            vm.data.set('carCollect', '收藏');
                        }else{
                            $('.js-active').addClass('active');
                            vm.data.set('carCollect', '已收藏');
                        }

                        //详情退换货
                        var freightTemple = doT.template($('#goodsLabelCont').text());
                        $('.js-g-freight').html('').append(freightTemple(obj.data.goodsLableMap));

                        $('.js-d-cont').html((obj.data.goodsDesc).replace(/<br>/g,''));

                    }else{
                        common.toast(obj.message);
                    }
                }
            })
        }
    };

    dao.getGoodsData();

    fly.bind(document.body, vm);
});
