/**
 * @author: xiaomei
 * @date: 2018.6.11
 * @description 收藏管理
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'lazyLoad',
    'serverUrl',
    'jquery',
    'iscroll',
    'pullToRefresh'
], function (doT, flyMobile, jquery, common,lazyLoad, serverUrl, iscroll, pullToRefresh) {
    var pageSize = 10,
        currentPageNo = 1,
        upPermit = 0;

    var collectCont=$('.js-collect-list');

    var params={
        "pageNo":1,
        "pageSize":10
    };

    var vm = window.vm = fly({
        data:{},
        event: {
            pulltoDo: function() {
                //初始化上拉下拉操作
                refresher.init({
                    id: "wrapper",
                    pullDownAction: vm.event.reloadNew,
                    pullUpAction: vm.event.loadMore
                });
            },
            loadMore: function() {
                if (upPermit === 0) {
                    //上拉加载
                    currentPageNo++;
                    params.pageNo = currentPageNo;
                    $.ajax({
                        headers:{'Authorization':tokenValue},
                        type:'post',
                        url:serverApiUrl+'crm/api/sale/fav/list',
                        contentType:'application/json',
                        data:JSON.stringify(params),
                        async:false,
                        dataType:"json",
                        success:function(res){
                            debugger;
                            common.hideToast();
                            if(res.data.rows.length>0){
                                var requestTmpl = doT.template($('#collectListTemple').text());
                                collectCont.append(requestTmpl(res.data.rows));
                                if (res.data.rows.length < pageSize) {
                                    refresher.onResherCompeted();
                                }
                                wrapper.refresh();
                            } else {
                                refresher.onResherCompeted();
                                wrapper.refresh();
                            }
                        },
                        error:function(e){
                            common.hideToast();
                            $('.error').show();
                            refresher.onErrorCompeted();
                            $('.pullUpLabel').text('');
                            $('.error p').text(e.message);
                            vm.event.pulltoDo();
                        }
                    });
                }else{
                    refresher.onResherCompeted();
                    wrapper.refresh();
                }
            },
            reloadNew: function() {
                //下拉刷新
                currentPageNo = 1;
                upPermit = 0;
                params.pageNo = currentPageNo;
                $.ajax({
                    headers:{'Authorization':tokenValue},
                    type:'post',
                    url:serverApiUrl+'crm/api/sale/fav/list',
                    contentType:'application/json',
                    data:JSON.stringify(params),
                    async:false,
                    dataType:"json",
                    success:function(res){
                        common.hideToast();
                        if(res.data.rows.length>0) {
                            var requestTmpl = doT.template($('#collectListTemple').text());
                            collectCont.html("").append(requestTmpl(res.data.rows));
                            if(res.data.rows.length < pageSize){
                                refresher.onResherCompeted();
                                upPermit = 1;
                            }else{
                                upPermit = 0;
                            }
                            wrapper.refresh();
                            $('.pullUpLabel').text('更多');
                        }else {
                            $('.empty').show();
                            refresher.onEmptyCompeted();
                            wrapper.refresh();
                            $('.pullUpLabel').text('');
                        }
                    },
                    error:function(e){
                        common.hideToast();
                        $('.error').show();
                        refresher.onErrorCompeted();
                        $('.pullUpLabel').text('');
                        $('.error p').text(e.message);
                        vm.event.pulltoDo();
                    }
                });
            }
        },
        page: {
            //收藏管理详情
            jumpCarDetail: function (e) {
                var id = $(e.currentTarget).data('id'),
                    params={"param":id};
                window.location.href=localhostUrl+"collectDetail/collectDetail.html?userId="+id;

                // flyMobile.data({
                //     source: 'collectDetail',
                //     action: 'collectDetail',
                //     actionType: '1',
                //     args:params,
                //     callback:false
                // });
            },

            //打电话
            jumpCall: function(e){
                flyMobile.data({
                    source: 'collectManage',
                    action: 'call',
                    actionType: '3'
                });
            }
        }
    });

    var dao = {
        //收藏列表
        getTotalCar: function(){
           common.showToast();
            $.ajax({
                headers:{'Authorization':tokenValue},
                contentType:'application/json',
                type:'post',
                url:serverApiUrl+'crm/api/sale/fav/list',
                data:JSON.stringify(params),
                async:false,
                dataType:"json",
                success:function(res){
                    common.hideToast();
                    if(res.data.rows.length>0){
                        var requestTmpl = doT.template($('#collectListTemple').text());
                        collectCont.append(requestTmpl(res.data.rows));
                        if (res.data.rows.length < pageSize) {
                            refresher.onResherCompeted();
                            upPermit = 1;
                        } else {
                            refresher.onInitCompeted();
                        }
                        vm.event.pulltoDo();
                    }else {
                        $('.empty').show();
                        refresher.onEmptyCompeted();
                        $('.pullUpLabel').text('');
                    }
                },
                error:function(e){
                    common.hideToast();
                    $('.error').show();
                    refresher.onErrorCompeted();
                    $('.pullUpLabel').text('');
                    $('.error p').text(e.message);
                    vm.event.pulltoDo();
                }
            });
        }
    };

    dao.getTotalCar();
    collectCont.on('click', '.js-call-phone', vm.page.jumpCall);

    fly.bind(document.body, vm);
});