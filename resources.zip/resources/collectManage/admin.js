/**
 * @author: xiaomei
 * @date: 2018.6.11
 * @description 收藏管理
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'lazyLoad',
    'jquery',
    'iscroll',
    'pullToRefresh'
], function (doT, flyMobile, jquery, common,lazyLoad,iscroll, pullToRefresh) {
    var pageSize = 10,
        currentPageNo = 1,
        upPermit = 0,
        collectCont=$('.js-collect-list');

    var params={
        "pageNo":1,
        "pageSize":10
    };

    var vm = window.vm = fly({
        data:{},
        event: {
            pulltoDo: function() {
                //初始化上拉下拉操作
                refresher.init({
                    id: "wrapper",
                    pullDownAction: vm.event.reloadNew,
                    pullUpAction: vm.event.loadMore
                });
            },
            loadMore: function() {
                if (upPermit === 0) {
                    //上拉加载
                    currentPageNo++;
                    params.pageNo = currentPageNo;
                    flyMobile.data({
                        source:'collectManage',
                        action:'',
                        actionType:'4',
                        path:'crm/api/sale/fav/list',
                        args:params,
                        callback:true
                    }).done(function(res){
                        if (res.statusCode == 200) {
                            if(res.data.rows.length>0){
                                var requestTmpl = doT.template($('#collectListTemple').text());
                                collectCont.append(requestTmpl(res.data.rows));
                                if (res.data.rows.length < pageSize) {
                                    refresher.onResherCompeted();
                                }
                                wrapper.refresh();
                            }else{
                                refresher.onResherCompeted();
                                wrapper.refresh();
                            }
                        }else{
                            $('.js-error').show().find('p').text(res.message);
                            refresher.onErrorCompeted();
                            $('.pullUpLabel').text('');
                            vm.event.pulltoDo();
                        }
                    });
                }else{
                    refresher.onResherCompeted();
                    wrapper.refresh();
                }
            },
            reloadNew: function() {
                //下拉刷新
                currentPageNo = 1;
                upPermit = 0;
                params.pageNo = currentPageNo;
                flyMobile.data({
                    source:'collectManage',
                    action:'',
                    actionType:'4',
                    path:'crm/api/sale/fav/list',
                    args:params,
                    callback:true
                }).done(function(res){
                    if(res.statusCode == 200){
                        if(res.data.rows.length>0){
                            var requestTmpl = doT.template($('#collectListTemple').text());
                            collectCont.html("").append(requestTmpl(res.data.rows));
                            if(res.data.length < pageSize) {
                                refresher.onResherCompeted();
                                upPermit = 1;
                            }else{
                                upPermit = 0;
                            }
                            wrapper.refresh();
                        }else {
                            $('.js-empty').show();
                            refresher.onEmptyCompeted();
                            wrapper.refresh();
                            $('.pullUpLabel').text('');
                        }
                    }else{
                        $('.js-error').show().find('p').text(res.message);
                        refresher.onErrorCompeted();
                        $('.pullUpLabel').text('');
                        vm.event.pulltoDo();
                    }
                });
            }
        },
        page: {
            //收藏管理详情
            jumpCarDetail: function(e){
                var params={"param":$(e.currentTarget).attr('data-id')};
                flyMobile.data({
                    source:'collectDetail',
                    action:'collectDetail',
                    actionType:'1',
                    args:params,
                    callback:false
                });
            },

            //打电话
            jumpCall: function(e){
                var _this=$(e.currentTarget).attr('data-type'),
                    params={"phone":_this};
                flyMobile.data({
                    source:'collectManage',
                    action:'call',
                    args:params,
                    actionType:'3',
                    callback: false
                });
            }
        }
    });
    var dao = {
        //收藏列表
        getTotalCar: function(){
           common.showToast();
            flyMobile.data({
                source:'collectManage',
                action:'',
                actionType:'4',
                path:'crm/api/sale/fav/list',
                args:params,
                callback:true
            }).done(function (res){
                common.hideToast();
                if(res.statusCode == 200){
                    if(res.data.rows.length>0){
                        var requestTmpl = doT.template($('#collectListTemple').text());
                        collectCont.append(requestTmpl(res.data.rows));
                        if(res.data.length < pageSize) {
                            refresher.onResherCompeted();
                            upPermit = 1;
                        }else{
                            upPermit = 0;
                        }
                        wrapper.refresh();
                    }else {
                        $('.js-empty').show();
                        refresher.onEmptyCompeted();
                        wrapper.refresh();
                        $('.pullUpLabel').text('');
                    }
                }else{
                    $('.js-error').show().find('p').text(res.message);
                    refresher.onErrorCompeted();
                    $('.pullUpLabel').text('');
                    vm.event.pulltoDo();
                }
            });
        }
    };

    dao.getTotalCar();
    collectCont.on('click', '.js-call-phone', vm.page.jumpCall);
    // collectCont.on('click', '.js-collect-detail', vm.page.jumpCarDetail);

    fly.bind(document.body, vm);
});