/**
 * @author: xiaomei
 * @date: 2018.8.16
 * @description 分享有礼
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'dialog'
], function (doT,flyMobile,dialog){
    var phoneNum=$('.js-phone'),
        phoneCode=$('.js-phone-code'),
        getCode=$('.js-get-code'),
        countCode=$('.js-count-code'),
        countNum=120;

    var vm = window.vm = fly({
        data:{},
        event:{},
        page:{
            //倒计时
            countDown:function(){
                if (countNum == 0) {
                    getCode.removeClass("hide");
                    countCode.addClass("hide");
                    countNum = 120;
                }else{
                    getCode.addClass("hide");
                    countCode.removeClass('hide').html("重新发送(" + countNum + ")s");
                    countNum--;
                    setTimeout(function(){
                        vm.page.countDown();
                    },1000)
                }
            },

            //发送验证码
            sendPhoneCode:function(){
                var userPhoneCont=phoneNum.val(),
                    myReg=/^[1][3,4,5,7,8][0-9]{9}$/;
                if(!$.trim(userPhoneCont)){
                    layer.msg('请输入手机号码');
                }else if (!myReg.test(userPhoneCont)) {
                    layer.msg('请输入正确的手机号码');
                }else{
                    var params={
                            "param":{
                                "mobileNo":userPhoneCont,
                                "deviceId":"f7887fdsgwef8w4848"
                            }
                        };
                    flyMobile.data({
                        source:'shareGift',
                        action:'',
                        actionType:'4',
                        args:params,
                        path:'crm/api/user/sendVerifyCode',
                        callback:true
                    }).done(function (res){
                        if (res.statusCode == 200){
                            layer.msg('发送短信成功');
                            $('.js-btn').attr('data-type',res.data);
                            vm.page.countDown();
                        } else {
                            layer.msg('发送短信失败');
                        }
                    });
                }
            },

            //成为邀请人
            becomeAnInviter:function(){
                var userPhoneCont=phoneNum.val(),
                    phoneCodeCont=phoneCode.val(),
                    codeSure=$('.js-btn').attr('data-type'),
                    myReg=/^[1][3,4,5,7,8][0-9]{9}$/;
                var params={
                    "param": {
                        "phone":userPhoneCont
                    }
                };
                if(!$.trim(userPhoneCont)){
                    layer.msg('请输入手机号码');
                }else if(!myReg.test(userPhoneCont)){
                    layer.msg('请输入正确的手机号码');
                }else if (!$.trim(phoneCodeCont) ) {
                    layer.msg('请输入验证码');
                }else if(phoneCodeCont != codeSure){
                    layer.msg('请输入正确的验证码');
                }else{
                    flyMobile.data({
                        source:'shareGift',
                        action:'',
                        actionType:'4',
                        args:params,
                        path:'',
                        callback:true
                    }).done(function(obj){
                        if (obj.statusCode == 200){

                        } else {
                            layer.msg('成为邀请人失败');
                        }
                    });
                }
            }
        }
    });

    fly.bind(document.body, vm);
});