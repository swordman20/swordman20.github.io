/**
 * @author: xiaomei
 * @date: 2018.6.7
 * @description 预约管理
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll',
    'pullToRefresh'
], function (doT, flyMobile, jquery, common,iscroll, pullToRefresh) {
    var pageSize = 10,
        currentPageNo = 1,
        upPermit = 0;

    var params={
        "pageNo":1,
        "pageSize":10
    };

    var appointCont=$('.js-collect-list');

    var vm = window.vm = fly({
        data:{},
        event: {
            pulltoDo: function() {
                //初始化上拉下拉操作
                refresher.init({
                    id: "wrapper",
                    pullDownAction: vm.event.reloadNew,
                    pullUpAction: vm.event.loadMore
                });
            },
            loadMore: function() {
                if (upPermit === 0) {
                    //上拉加载
                    currentPageNo++;
                    params.pageNo = currentPageNo;
                    flyMobile.data({
                        source:'appointAdmin',
                        action:'',
                        actionType:'4',
                        path:'crm/api/reserve/saleList',
                        args:params,
                        callback:true
                    }).done(function(res){
                        if (res.statusCode == 200){
                            if(res.data.rows.length>0){
                                var requestTmpl = doT.template($('#collectListTemple').text());
                                appointCont.append(requestTmpl(res.data.rows));
                                if (res.data.rows.length < pageSize) {
                                    refresher.onResherCompeted();
                                }
                                wrapper.refresh();
                            }else{
                                refresher.onResherCompeted();
                                wrapper.refresh();
                            }
                        }else{
                            vm.page.errorData(res);
                        }
                    });
                }else{
                    refresher.onResherCompeted();
                    wrapper.refresh();
                }
            },
            reloadNew: function() {
                //下拉刷新
                currentPageNo = 1;
                upPermit = 0;
                params.pageNo = currentPageNo;
                flyMobile.data({
                    source:'appointAdmin',
                    action:'',
                    actionType:'4',
                    path:'crm/api/reserve/saleList',
                    args:params,
                    callback:true
                }).done(function (res) {
                    if (res.statusCode == 200) {
                        if(res.data.rows.length>0){
                            var requestTmpl = doT.template($('#collectListTemple').text());
                            appointCont.html('').append(requestTmpl(res.data.rows));
                            if(res.data.rows.length < pageSize) {
                                refresher.onResherCompeted();
                                upPermit = 1;
                            }else{
                                upPermit = 0;
                            }
                            wrapper.refresh();
                        }else {
                            vm.page.emptyData();
                        }
                    }else{
                        vm.page.errorData(res);
                    }
                });
            }
        },
        page: {
            // 预约管理详情
            jumpCarDetail: function(e){
                var params={"userId":$(e.currentTarget).attr('data-id'),"carType":$(e.currentTarget).attr('data-type')};
                flyMobile.data({
                    source:'appointDetail',
                    action:'appointDetail',
                    actionType:'1',
                    args:params,
                    callback:false
                });
            },

            //错误数据
            errorData:function(e){
                $('.js-error').show().find('p').text(e.message);
                refresher.onErrorCompeted();
                $('.pullUpLabel').text('');
                vm.event.pulltoDo();
            },

            //空数据
            emptyData:function(){
                $('.js-empty').show();
                refresher.onEmptyCompeted();
                wrapper.refresh();
                $('.pullUpLabel').text('');
            },

            //电话
            jumpCall: function(e){
                var params={"phone":$(e.currentTarget).attr('data-type')};
                flyMobile.data({
                    source:'appointAdmin',
                    action:'call',
                    args:params,
                    actionType:'3',
                    callback:false
                });
            }
        }
    });
    var dao = {
        //车辆列表
        getTotalCar: function(){
           common.showToast();
            flyMobile.data({
                source:'appointAdmin',
                action:'appointAdmin',
                actionType:'4',
                path:'crm/api/reserve/saleList',
                args:params,
                callback:true
            }).done(function(res){
                common.hideToast();
                if (res.statusCode == 200){
                    if(res.data.rows.length>0){
                        var requestTmpl = doT.template($('#collectListTemple').text());
                        appointCont.append(requestTmpl(res.data.rows));
                        if (res.data.rows.length < pageSize) {
                            refresher.onResherCompeted();
                            upPermit = 1;
                        } else {
                            refresher.onInitCompeted();
                        }
                        vm.event.pulltoDo();
                    }else {
                        vm.page.emptyData();
                    }
                } else {
                    vm.page.errorData(res);
                }
            });
        }
    };
    appointCont.on('click', 'li dd .js-appoint', vm.page.jumpCarDetail);
    appointCont.on('click', 'li dd .js-appoint-tel', vm.page.jumpCall);
    dao.getTotalCar();

    fly.bind(document.body, vm);
});