/**
 * @author: xiaomei
 * @date: 2018.6.7
 * @description 预约管理
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'lazyLoad',
    'serverUrl',
    'jquery',
    'iscroll',
    'pullToRefresh'
], function (doT, flyMobile, jquery, common,lazyLoad, serverUrl, iscroll, pullToRefresh) {
    var pageSize = 10,
        currentPageNo = 1,
        upPermit = 0;

    var params={
        "pageNo":1,
        "pageSize":10
    };

    var appointCont=$('.js-collect-list');

    var vm = window.vm = fly({
        data:{},
        event: {
            pulltoDo: function() {
                //初始化上拉下拉操作
                refresher.init({
                    id: "wrapper",
                    pullDownAction: vm.event.reloadNew,
                    pullUpAction: vm.event.loadMore
                });
            },
            loadMore: function() {
                if (upPermit === 0) {
                    //上拉加载
                    currentPageNo++;
                    params.pageNo = currentPageNo;
                    $.ajax({
                        headers: {'Authorization':tokenValue},
                        type:'post',
                        url:serverApiUrl+'crm/api/reserve/saleList',
                        async:false,
                        contentType:'application/json',
                        data:JSON.stringify(params),
                        dataType:"json",
                        success:function(res){
                            common.hideToast();
                            if(res.data.rows.length>0) {
                                var requestTmpl = doT.template($('#collectListTemple').text());
                                appointCont.append(requestTmpl(res.data.rows));
                                if (res.data.rows.length < pageSize) {
                                    refresher.onResherCompeted();
                                }
                                wrapper.refresh();
                            }else{
                                refresher.onResherCompeted();
                                wrapper.refresh();
                            }
                        },
                        error:function(e){
                            common.hideToast();
                            $('.js-error').show().find('p').text(e.message);
                            refresher.onErrorCompeted();
                            $('.pullUpLabel').text('');
                            vm.event.pulltoDo();
                        }
                    });
                }else{
                    refresher.onResherCompeted();
                    wrapper.refresh();
                }
            },
            reloadNew: function() {
                //下拉刷新
                currentPageNo = 1;
                upPermit = 0;
                params.pageNo = currentPageNo;
                $.ajax({
                    headers: {'Authorization':tokenValue},
                    type:'post',
                    url:serverApiUrl+'crm/api/reserve/saleList',
                    async:false,
                    contentType:'application/json',
                    data:JSON.stringify(params),
                    dataType:"json",
                    success:function(res){
                        common.hideToast();
                        if(res.data.rows.length>0){
                            var requestTmpl = doT.template($('#collectListTemple').text());
                            appointCont.html('').append(requestTmpl(res.data.rows));
                            if(res.data.length < pageSize) {
                                refresher.onResherCompeted();
                                upPermit = 1;
                            }else{
                                upPermit = 0;
                            }
                            wrapper.refresh();
                        }else {
                            $('.empty').show();
                            refresher.onEmptyCompeted();
                            wrapper.refresh();
                            $('.pullUpLabel').text('');
                        }
                    },
                    error:function(e){
                        common.hideToast();
                        $('.js-error').show().find('p').text(e.message);
                        refresher.onErrorCompeted();
                        $('.pullUpLabel').text('');
                        vm.event.pulltoDo();
                    }
                });
            }
        },
        page: {
            // 预约管理详情
            jumpCarDetail: function (e){
                var id = $(e.currentTarget).data('id'),
                    params={"param":id};
                window.location.href=localhostUrl+"appointDetail/appointDetail.html?userId="+id;

                //IOS跳转
                // flyMobile.data({
                //     source: 'appointDetail',
                //     action: 'appointDetail',
                //     actionType: '1',
                //     args:params,
                //     callback: false
                // });
            },

            //电话
            jumpCall: function(e){
                flyMobile.data({
                    source: 'appointAdmin',
                    action: 'call',
                    actionType: '3'
                });
            }
        }
    });
    var dao = {
        //车辆列表
        getTotalCar: function(){
           common.showToast();
            $.ajax({
                headers: {'Authorization':tokenValue},
                type:'post',
                url:serverApiUrl+'crm/api/reserve/saleList',
                async:false,
                contentType:'application/json',
                data:JSON.stringify(params),
                dataType:"json",
                success:function(res){
                    common.hideToast();
                    if(res.data.rows.length>0) {
                        var requestTmpl = doT.template($('#collectListTemple').text());
                        appointCont.append(requestTmpl(res.data.rows));
                        if (res.data.rows.length < pageSize) {
                            refresher.onResherCompeted();
                            upPermit = 1;
                        } else {
                            refresher.onInitCompeted();
                        }
                        vm.event.pulltoDo();
                    }else {
                        $('.empty').show();
                        refresher.onEmptyCompeted();
                        $('.pullUpLabel').text('');
                    }
                },
                error:function(e){
                    common.hideToast();
                    $('.js-error').show().find('p').text(e.message);
                    refresher.onErrorCompeted();
                    $('.pullUpLabel').text('');
                    vm.event.pulltoDo();
                }
            });
        }
    };

    // 打电话
    $('.collect-list').on('click', '.phone', vm.page.jumpCall);
    dao.getTotalCar();

    fly.bind(document.body, vm);
});