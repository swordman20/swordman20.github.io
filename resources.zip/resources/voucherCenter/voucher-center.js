/**
 * @author: wxm
 * @date: 2018.6.4
 * @description 卡券中心
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll'
], function (doT, flyMobile, jquery, common,iscroll){

    var voucherCenter=$('.js-voucher'),
        noData=$('.js-error');

    var userLogin=false;

    //判断用户信息
    flyMobile.data({
        source:'',
        action:'',
        actionType:'7',
        path:'',
        callback:true
    }).done(function(obj){
        //判断是否登录
        var judgeLogin=obj.token;
        if(typeof judgeLogin == "undefined" || judgeLogin == null || judgeLogin == ""){
            userLogin=false;
        }else{
            userLogin=true;
        }
    });

    var vm = window.vm = fly({
        data:{},
        event:{},
        page: {
            // 立即领取
            getVoucher: function(e){
                var params = {"param":$(e.currentTarget).data('id')};
                if(userLogin==false){
                    flyMobile.data({
                        source: 'myIndex',
                        action: 'jumpLogin',
                        actionType: '3',
                        callback: false
                    });
                }else{
                    flyMobile.data({
                        source:'voucherCenter',
                        action:'',
                        actionType:'4',
                        path:'coupon/api/coupon/receive',
                        args:params,
                        callback:true
                    }).done(function(res){
                        if(res.statusCode=='200'){
                            common.toast("领取" + res.message, '', '', '');
                            setTimeout(function(){
                                window.location.reload();
                            },800);
                        }else{
                            common.toast("领取" + res.message, '', '', '');
                        }
                    });
                }
            }
        }
    });

    var dao = {
        //领券列表
        getTotalCar: function(){
            common.showToast();
            flyMobile.data({
                source:'voucherCenter',
                action:'',
                actionType:'4',
                path:'coupon/api/coupon/couponList',
                callback:true
            }).done(function(res){
                common.hideToast();
                if(res.statusCode == 200){
                    if(res.data.length>0){
                        var requestTmpl = doT.template($('#myVoucherTemple').text());
                        voucherCenter.append(requestTmpl(res.data));
                    }else{
                        noData.show();
                    }
                } else {
                    noData.show();
                    noData.find('p').text(res.message);
                }
            })
        }
    };

    voucherCenter.on('click','li .js-receive',vm.page.getVoucher);
    dao.getTotalCar();

    fly.bind(document.body, vm);
});