/**
 * @author: wxm
 * @date: 2018.6.4
 * @description 卡券中心
 */
require.config(requireConfig);
require([
    'doT',
    'flyMobile',
    'fly',
    'common',
    'jquery',
    'iscroll'
], function (doT,flyMobile,jquery,common,iscroll){

    var voucherCenter=$('.js-voucher');

    var vm = window.vm = fly({
        data:{},
        event:{},
        page:{
            // 立即领取
            getVoucher: function (e){
                var params = {"param":$(e.currentTarget).data('id')};
                $.ajax({
                    headers:{'Authorization':tokenValue},
                    type:'post',
                    url:serverApiUrl+'coupon/api/coupon/receive',
                    async:false,
                    contentType:'application/json',
                    data:JSON.stringify(params),
                    dataType:"json",
                    success:function(res){
                        common.toast("领取" + res.message, '', '', '');
                        setTimeout(function(){
                            window.location.reload();
                        },800)
                    },
                    error:function(e){
                        common.toast("领取" + e.message, '', '', '');
                    }
                });
            }
        }
    });

    var dao = {
        //领券列表
        getTotalCar: function(){
            var errorCont=$('.js-error');
            common.showToast();
            $.ajax({
                type:'post',
                url:serverApiUrl+'coupon/api/coupon/couponList',
                async:false,
                dataType:"json",
                success:function(res){
                    common.hideToast();
                    if(res.data.length>0){
                        var requestTmpl = doT.template($('#myVoucherTemple').text());
                        voucherCenter.append(requestTmpl(res.data));
                    }else{
                        errorCont.removeClass('hide');
                    }
                },
                error:function(e){
                    common.hideToast();
                    errorCont.removeClass('hide').find('p').text(e.message);
                }
            });
        }
    };

    voucherCenter.on('click','li .js-receive',vm.page.getVoucher);
    dao.getTotalCar();

    fly.bind(document.body,vm);
});